<?php
include 'db.php'; // Include database connection

// Fetching services from the database
$query = "SELECT * FROM services";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services - Infinity Salon</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        :root {
            --primary: #ff6b6b;
            --secondary: #794afa;
            --secondary-dark: #453c5c;
            --white: #ffffff;
            --grey: #f2f2f2;
            --dark: #2d2d2d;
            --light-bg: #f9f9ff;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: var(--light-bg);
            color: var(--dark);
            line-height: 1.6;
        }

        .Services {
            padding: 5rem 1.5rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        .section_title {
            text-align: center;
            margin-bottom: 3rem;
        }

        .section_title h3 {
            font-size: 1.2rem;
            color: var(--primary);
            text-transform: uppercase;
            letter-spacing: 3px;
            margin-bottom: 0.5rem;
        }

        .section_title h2 {
            font-size: 2.5rem;
            color: var(--secondary-dark);
            position: relative;
            display: inline-block;
            padding-bottom: 1rem;
        }

        .section_title h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: var(--primary);
            border-radius: 3px;
        }

        .Service_Wrap {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 2rem;
        }

        .Service_Item {
            background: var(--white);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }

        .Service_Item:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.12);
        }

        .Service_Image {
            height: 220px;
            overflow: hidden;
        }

        .Service_Image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .Service_Item:hover .Service_Image img {
            transform: scale(1.05);
        }

        .Service_Content {
            padding: 1.8rem;
        }

        .Service_Content h2 {
            font-size: 1.4rem;
            color: var(--secondary-dark);
            margin-bottom: 1rem;
            position: relative;
            padding-bottom: 0.8rem;
        }

        .Service_Content h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 2px;
            background: var(--primary);
        }

        .Service_Content p {
            color: #666;
            margin-bottom: 1.2rem;
            font-size: 0.95rem;
        }

        .price {
            font-weight: 700;
            color: var(--primary);
            font-size: 1.2rem;
            display: flex;
            align-items: center;
        }

        .price::before {
            content: '\f155';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            margin-right: 8px;
            font-size: 1rem;
        }

        @media (max-width: 768px) {
            .Service_Wrap {
                grid-template-columns: 1fr;
            }
            
            .section_title h2 {
                font-size: 2rem;
            }
        }

        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .Service_Item {
            animation: fadeIn 0.6s ease forwards;
            opacity: 0;
        }

        .Service_Item:nth-child(1) { animation-delay: 0.1s; }
        .Service_Item:nth-child(2) { animation-delay: 0.2s; }
        .Service_Item:nth-child(3) { animation-delay: 0.3s; }
        .Service_Item:nth-child(4) { animation-delay: 0.4s; }
        .Service_Item:nth-child(5) { animation-delay: 0.5s; }
        .Service_Item:nth-child(6) { animation-delay: 0.6s; }
    </style>
</head>
<body>
    <section class="Services">
        <div class="Service_title section_title">
            <h3>Professional Services</h3>
            <h2>We are Expert in</h2>
        </div>
        <div class="Service_Wrap">
            <!-- Loop to display services -->
            <?php while ($service = $result->fetch_assoc()): ?>
                <div class="Service_Item">
                    <div class="Service_Image">
                        <?php if (!empty($service['image_path'])): ?>
                            <img src="<?php echo htmlspecialchars($service['image_path']); ?>" alt="<?php echo htmlspecialchars($service['name']); ?>">
                        <?php else: ?>
                            <img src="uploads/default-service.png" alt="Default Service Image">
                        <?php endif; ?>
                    </div>
                    <div class="Service_Content">
                        <h2><?php echo htmlspecialchars($service['name']); ?></h2>
                        <p><?php echo htmlspecialchars($service['description']); ?></p>
                        <p class="price">Rs <?php echo number_format($service['price'], 2); ?></p>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </section>
</body>
</html>