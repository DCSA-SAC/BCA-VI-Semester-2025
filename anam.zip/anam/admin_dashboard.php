<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Infinity Salon</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #d4a373;
            --primary-dark: #b58a5e;
            --secondary: #fefae0;
            --dark: #333;
            --light: #f8f9fa;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --border-radius: 8px;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--light-gray);
            color: var(--dark);
            line-height: 1.6;
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--dark);
            color: var(--white);
            padding: 2rem 0;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            height: 100%;
            z-index: 100;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
        }

        .sidebar-header h2 {
            color: var(--primary);
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
        }

        .sidebar-header p {
            color: var(--secondary);
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .admin-profile {
            display: flex;
            align-items: center;
            padding: 1.5rem 2rem;
            margin-bottom: 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .admin-profile img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 1rem;
            border: 2px solid var(--primary);
        }

        .admin-info h3 {
            font-size: 1.1rem;
            margin-bottom: 0.2rem;
        }

        .admin-info p {
            font-size: 0.8rem;
            opacity: 0.7;
        }

        .nav-menu {
            padding: 1rem 0;
        }

        .nav-menu ul {
            list-style: none;
        }

        .nav-menu li {
            margin-bottom: 0.5rem;
        }

        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 0.8rem 2rem;
            color: var(--white);
            text-decoration: none;
            transition: var(--transition);
            font-size: 0.95rem;
        }

        .nav-menu a:hover, .nav-menu a.active {
            background: rgba(255, 255, 255, 0.1);
            border-left: 4px solid var(--primary);
        }

        .nav-menu i {
            margin-right: 1rem;
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--white);
            padding: 1.5rem 2rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
        }

        .header h1 {
            color: var(--dark);
            font-size: 1.8rem;
            font-weight: 600;
        }

        .header .welcome-message {
            display: flex;
            align-items: center;
        }

        .header .welcome-message i {
            margin-right: 0.5rem;
            color: var(--primary);
        }

        /* Dashboard Cards */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .card {
            background: var(--white);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .card-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--white);
        }

        .card-icon.services {
            background: linear-gradient(135deg, #2a9d8f, #1d7874);
        }

        .card-icon.gallery {
            background: linear-gradient(135deg, #d4a373, #b58a5e);
        }

        .card-icon.users {
            background: linear-gradient(135deg, #457b9d, #1d3557);
        }

        .card-icon.appointments {
            background: linear-gradient(135deg, #e63946, #c1121f);
        }

        .card h3 {
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
            color: var(--dark);
        }

        .card p {
            color: var(--gray);
            font-size: 0.9rem;
        }

        /* Quick Actions */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .action-btn {
            background: var(--white);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            text-align: center;
            box-shadow: var(--shadow);
            transition: var(--transition);
            cursor: pointer;
            border: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
        }

        .action-btn:hover {
            background: var(--primary);
            color: var(--white);
            transform: translateY(-3px);
        }

        .action-btn i {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--primary);
        }

        .action-btn:hover i {
            color: var(--white);
        }

        .action-btn span {
            font-weight: 500;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 240px;
            }
            .main-content {
                margin-left: 240px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding: 1rem 0;
            }
            .main-content {
                margin-left: 0;
            }
            .dashboard-cards, .quick-actions {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 576px) {
            .dashboard-cards, .quick-actions {
                grid-template-columns: 1fr;
            }
            .header {
                flex-direction: column;
                align-items: flex-start;
            }
            .header h1 {
                margin-bottom: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Infinity Salon</h2>
                <p>Admin Dashboard</p>
            </div>

            <div class="admin-profile">
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['admin']); ?>&background=random" alt="Admin">
                <div class="admin-info">
                    <h3><?php echo htmlspecialchars($_SESSION['admin']); ?></h3>
                    <p>Administrator</p>
                </div>
            </div>

            <nav class="nav-menu">
                <ul>
                    <li><a href="admin_dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="admin_services.php"><i class="fas fa-spa"></i> Services</a></li>
                    <li><a href="admin_gallery.php"><i class="fas fa-images"></i> Gallery</a></li>
                    
                    <li><a href="admin_logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <div class="header">
                <h1>Dashboard Overview</h1>
                <div class="welcome-message">
                    <i class="fas fa-user-circle"></i>
                    <span>Welcome back, <?php echo htmlspecialchars($_SESSION['admin']); ?></span>
                </div>
            </div>

            <!-- Dashboard Cards -->
            <div class="dashboard-cards">
                <div class="card">
                    <div class="card-header">
                        <div>
                            <p>Total Services</p>
                            <h3>24</h3>
                        </div>
                        <div class="card-icon services">
                            <i class="fas fa-spa"></i>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <div>
                            <p>Gallery Items</p>
                            <h3>48</h3>
                        </div>
                        <div class="card-icon gallery">
                            <i class="fas fa-images"></i>
                        </div>
                    </div>
                </div>

            <br>

            <!-- Quick Actions -->
            <h2 style="margin-bottom: 1rem; color: var(--dark);">Quick Actions</h2>
            <div class="quick-actions">
                <button class="action-btn" onclick="window.location.href='admin_services.php?action=add'">
                    <i class="fas fa-plus-circle"></i>
                    <span>Add New Service</span>
                </button>

                <button class="action-btn" onclick="window.location.href='admin_gallery.php?action=add'">
                    <i class="fas fa-image"></i>
                    <span>Add Gallery Image</span>
                </button>


            </div>
        </main>
    </div>

    <script>
        // Add active class to current menu item
        document.addEventListener('DOMContentLoaded', function() {
            const currentPage = window.location.pathname.split('/').pop();
            const menuItems = document.querySelectorAll('.nav-menu a');
            
            menuItems.forEach(item => {
                if (item.getAttribute('href') === currentPage) {
                    item.classList.add('active');
                }
            });
        });
    </script>
</body>
</html>