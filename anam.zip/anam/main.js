function redirectToLogin() {
    window.location.href = "auth/login.html";
}

function viewMoreGallery() {
    window.location.href = "Gallery.html";
}
window.onload = function () {
    new Splide('.Photo_Gallery_Slide', {
        type: 'loop', drag: 'free',
        focus: 'center', gap: '0.8rem', perPage: 5, pagination: false, autoScroll: { speed: 0.7 },
    }).mount({
        AutoScroll: window.splide.Extensions.AutoScroll
    });
}
