<?php
session_start();
include 'db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['image'])) {
    $title = isset($_POST['title']) ? trim($_POST['title']) : 'Untitled';
    $image = $_FILES['image'];
    
    // Validate image
    $allowed_types = ['image/jpeg', 'image/png', 'image/webp'];
    $max_size = 2 * 1024 * 1024; // 2MB
    
    if (!in_array($image['type'], $allowed_types)) {
        $error = "Only JPG, PNG, and WEBP files are allowed.";
    } elseif ($image['size'] > $max_size) {
        $error = "Image size must be less than 2MB.";
    } else {
        $target_dir = "uploads/gallery/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $file_ext = pathinfo($image['name'], PATHINFO_EXTENSION);
        $file_name = uniqid('img_') . '.' . $file_ext;
        $target_file = $target_dir . $file_name;
        
        if (move_uploaded_file($image['tmp_name'], $target_file)) {
            $query = "INSERT INTO gallery (title, image_path) VALUES (?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ss", $title, $target_file);
            
            if ($stmt->execute()) {
                $success = "Image uploaded successfully!";
                $_SESSION['success'] = $success;
                header("Location: gallery.php");
                exit;
            } else {
                // Delete the uploaded file if DB insert fails
                if (file_exists($target_file)) {
                    unlink($target_file);
                }
                $error = "Failed to add image to database.";
            }
        } else {
            $error = "Failed to upload image.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Gallery Image | Infinity Salon</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #d4a373;
            --primary-dark: #b58a5e;
            --secondary: #fefae0;
            --dark: #333;
            --light: #f8f9fa;
            --light-gray: #e9ecef;
            --white: #ffffff;
            --error: #e63946;
            --success: #2a9d8f;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            --border-radius: 12px;
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: var(--dark);
            padding: 2rem;
        }

        .upload-container {
            background: var(--white);
            width: 100%;
            max-width: 600px;
            padding: 2.5rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .upload-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 6px;
            background: linear-gradient(90deg, var(--primary), var(--success));
        }

        h2 {
            font-size: 1.8rem;
            margin-bottom: 1.5rem;
            color: var(--dark);
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.8rem;
        }

        .back-btn {
            position: absolute;
            top: 1.5rem;
            left: 1.5rem;
            color: var(--dark);
            font-size: 1.2rem;
            transition: var(--transition);
        }

        .back-btn:hover {
            color: var(--primary);
            transform: translateX(-3px);
        }

        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: var(--border-radius);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.8rem;
        }

        .alert-error {
            background: rgba(230, 57, 70, 0.1);
            color: var(--error);
            border: 1px solid rgba(230, 57, 70, 0.3);
        }

        .upload-form {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        .form-group {
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--dark);
        }

        .form-control {
            width: 100%;
            padding: 1rem;
            border: 1px solid #e0e0e0;
            border-radius: var(--border-radius);
            font-size: 1rem;
            transition: var(--transition);
            background-color: var(--light);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(212, 163, 115, 0.2);
        }

        .file-upload {
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 2rem;
            border: 2px dashed #d1d5db;
            border-radius: var(--border-radius);
            background: var(--light);
            cursor: pointer;
            transition: var(--transition);
        }

        .file-upload:hover {
            border-color: var(--primary);
            background: rgba(212, 163, 115, 0.05);
        }

        .file-upload i {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }

        .file-upload p {
            margin-bottom: 0.5rem;
            color: var(--dark);
        }

        .file-upload small {
            color: var(--gray);
        }

        #fileInput {
            display: none;
        }

        #fileName {
            margin-top: 1rem;
            font-size: 0.9rem;
            color: var(--primary-dark);
            font-weight: 500;
        }

        #imagePreview {
            max-width: 100%;
            max-height: 300px;
            border-radius: var(--border-radius);
            margin-top: 1rem;
            display: none;
            border: 1px solid #eee;
            box-shadow: var(--shadow);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 1rem 2rem;
            background: var(--primary);
            color: var(--white);
            border: none;
            border-radius: var(--border-radius);
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 4px 10px rgba(212, 163, 115, 0.3);
            margin-top: 1rem;
            width: 100%;
        }

        .btn:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(212, 163, 115, 0.4);
        }

        .btn i {
            font-size: 1rem;
        }

        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .upload-container {
            animation: fadeIn 0.5s ease-out forwards;
        }

        /* Responsive */
        @media (max-width: 768px) {
            body {
                padding: 1rem;
            }
            
            .upload-container {
                padding: 2rem 1.5rem;
            }
            
            h2 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="upload-container">
        <a href="gallery.php" class="back-btn">
            <i class="fas fa-arrow-left"></i>
        </a>
        
        <h2>
            <i class="fas fa-image"></i> Add New Gallery Image
        </h2>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <form class="upload-form" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Image Title</label>
                <input type="text" id="title" name="title" class="form-control" placeholder="Enter image title" maxlength="100">
            </div>
            
            <div class="form-group">
                <label>Upload Image</label>
                <div class="file-upload" onclick="document.getElementById('fileInput').click()">
                    <i class="fas fa-cloud-upload-alt"></i>
                    <p>Click to browse or drag & drop</p>
                    <small>JPG, PNG, or WEBP (Max 2MB)</small>
                    <span id="fileName"></span>
                    <img id="imagePreview" alt="Image Preview">
                </div>
                <input type="file" id="fileInput" name="image" accept="image/jpeg, image/png, image/webp" required>
            </div>
            
            <button type="submit" class="btn">
                <i class="fas fa-upload"></i> Upload Image
            </button>
        </form>
    </div>

    <script>
        // File input change handler
        document.getElementById('fileInput').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const fileName = document.getElementById('fileName');
            const preview = document.getElementById('imagePreview');
            
            if (file) {
                fileName.textContent = file.name;
                
                // Show preview if image
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(event) {
                        preview.src = event.target.result;
                        preview.style.display = 'block';
                    }
                    reader.readAsDataURL(file);
                } else {
                    preview.style.display = 'none';
                }
            } else {
                fileName.textContent = '';
                preview.style.display = 'none';
            }
        });

        // Drag and drop functionality
        const uploadArea = document.querySelector('.file-upload');
        
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = 'var(--primary)';
            uploadArea.style.backgroundColor = 'rgba(212, 163, 115, 0.1)';
        });
        
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.style.borderColor = '#d1d5db';
            uploadArea.style.backgroundColor = 'var(--light)';
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = '#d1d5db';
            uploadArea.style.backgroundColor = 'var(--light)';
            
            if (e.dataTransfer.files.length) {
                document.getElementById('fileInput').files = e.dataTransfer.files;
                const event = new Event('change');
                document.getElementById('fileInput').dispatchEvent(event);
            }
        });
    </script>
</body>
</html>