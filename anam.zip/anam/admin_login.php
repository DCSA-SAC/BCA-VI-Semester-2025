<?php
session_start();

// Configuration - Move these to a config file in production
$admin_username = "admin";
$admin_password = "123"; // In production, use password_hash() and verify with password_verify()

// Redirect if already logged in
if (isset($_SESSION['admin'])) {
    header("Location: admin_dashboard.php");
    exit;
}

// Handle login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Basic validation
    if (empty($username) || empty($password)) {
        $error = "Please enter both username and password";
    } elseif ($username === $admin_username && $password === $admin_password) {
        $_SESSION['admin'] = $username;
        $_SESSION['login_time'] = time();
        
        // Regenerate session ID to prevent fixation
        session_regenerate_id(true);
        
        header("Location: admin_dashboard.php");
        exit;
    } else {
        $error = "Invalid username or password";
        // Log failed attempts in production
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Infinity Salon | Admin Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #d4a373;
            --primary-dark: #b58a5e;
            --secondary: #fefae0;
            --dark: #333;
            --light: #f8f9fa;
            --white: #ffffff;
            --error: #e63946;
            --success: #2a9d8f;
            --shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: var(--dark);
        }

        .login-container {
            background: var(--white);
            width: 100%;
            max-width: 420px;
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: var(--shadow);
            text-align: center;
            position: relative;
            overflow: hidden;
            transform: translateY(0);
            transition: var(--transition);
        }

        .login-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }

        .login-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 6px;
            background: linear-gradient(90deg, var(--primary), var(--success));
        }

        .logo {
            width: 80px;
            height: 80px;
            margin: 0 auto 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: var(--white);
            font-size: 2rem;
            border-radius: 50%;
            box-shadow: 0 4px 10px rgba(212, 163, 115, 0.4);
        }

        h2 {
            margin-bottom: 1.5rem;
            color: var(--dark);
            font-weight: 600;
            font-size: 1.8rem;
        }

        .error {
            color: var(--error);
            background: rgba(230, 57, 70, 0.1);
            padding: 0.8rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 1.2rem;
        }

        .input-group {
            position: relative;
        }

        input {
            width: 100%;
            padding: 1rem 1rem 1rem 3rem;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            font-size: 0.95rem;
            transition: var(--transition);
            background-color: var(--light);
        }

        input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(212, 163, 115, 0.2);
        }

        .input-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--primary);
            font-size: 1.1rem;
        }

        button {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: var(--white);
            border: none;
            padding: 1rem;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            margin-top: 0.5rem;
            box-shadow: 0 4px 10px rgba(212, 163, 115, 0.4);
        }

        button:hover {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(212, 163, 115, 0.5);
        }

        .forgot-link {
            margin-top: 1rem;
            font-size: 0.9rem;
            color: var(--dark);
            text-decoration: none;
            transition: var(--transition);
            display: inline-block;
        }

        .forgot-link:hover {
            color: var(--primary);
        }

        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .login-container {
            animation: fadeIn 0.6s ease-out forwards;
        }

        /* Responsive */
        @media (max-width: 480px) {
            .login-container {
                padding: 2rem 1.5rem;
                margin: 0 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <i class="fas fa-spa"></i>
        </div>
        <h2>Admin Login</h2>
        
        <?php if (isset($error)): ?>
            <div class="error">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="input-group">
                <i class="fas fa-user input-icon"></i>
                <input type="text" name="username" placeholder="Username" required autofocus>
            </div>
            
            <div class="input-group">
                <i class="fas fa-lock input-icon"></i>
                <input type="password" name="password" placeholder="Password" required>
            </div>
            
            <button type="submit">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
            
            <a href="#" class="forgot-link">Forgot password?</a>
        </form>
    </div>

    <script>
        // Add focus effects
        document.querySelectorAll('input').forEach(input => {
            input.addEventListener('focus', function() {
                this.previousElementSibling.style.color = 'var(--primary-dark)';
            });
            
            input.addEventListener('blur', function() {
                this.previousElementSibling.style.color = 'var(--primary)';
            });
        });

        // Prevent form resubmission on refresh
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>