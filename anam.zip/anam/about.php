<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Discover Infinity Salon - your premier destination for hair styling, grooming, and beauty services with expert stylists and luxurious experience.">
  <title>About Us | Infinity Salon - Where Beauty Meets Excellence</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary-color: #e91e63;
      --primary-dark: #c2185b;
      --primary-light: #f8bbd0;
      --secondary-color: #ff9800;
      --text-dark: #333;
      --text-medium: #555;
      --text-light: #777;
      --bg-light: #fff9fb;
      --bg-lighter: #fff0f6;
      --white: #ffffff;
      --shadow-sm: 0 4px 6px rgba(0, 0, 0, 0.05);
      --shadow-md: 0 6px 12px rgba(0, 0, 0, 0.1);
      --shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.15);
      --transition: all 0.3s ease-in-out;
      --border-radius: 12px;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Poppins', sans-serif;
      line-height: 1.6;
      color: var(--text-medium);
      background-color: var(--white);
      overflow-x: hidden;
    }

    h1, h2, h3 {
      font-family: 'Playfair Display', serif;
      font-weight: 600;
      color: var(--text-dark);
      line-height: 1.2;
    }

    section {
      padding: 6rem 1.5rem;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 1.5rem;
    }

    /* About Section */
    .about-section {
      background: linear-gradient(135deg, var(--bg-light), var(--white));
      position: relative;
      overflow: hidden;
    }

    .about-section::before {
      content: '';
      position: absolute;
      top: -50px;
      right: -50px;
      width: 200px;
      height: 200px;
      background-color: var(--primary-light);
      border-radius: 50%;
      opacity: 0.3;
      z-index: 0;
    }

    .about-content {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 3rem;
      position: relative;
      z-index: 1;
    }

    .about-text {
      flex: 1 1 50%;
      min-width: 300px;
    }

    .about-text h1 {
      font-size: clamp(2.5rem, 5vw, 3.5rem);
      color: var(--primary-color);
      margin-bottom: 1.5rem;
      position: relative;
      display: inline-block;
    }

    .about-text h1::after {
      content: '';
      position: absolute;
      bottom: -10px;
      left: 0;
      width: 80px;
      height: 4px;
      background-color: var(--secondary-color);
      border-radius: 2px;
    }

    .about-text p {
      font-size: 1.1rem;
      color: var(--text-medium);
      margin-bottom: 1.5rem;
    }

    .about-features {
      list-style: none;
      margin: 2rem 0;
    }

    .about-features li {
      margin-bottom: 1rem;
      padding-left: 2rem;
      position: relative;
      font-weight: 500;
    }

    .about-features li::before {
      content: '✓';
      position: absolute;
      left: 0;
      top: 0;
      color: var(--primary-color);
      font-weight: bold;
      font-size: 1.2rem;
    }

    .cta-button {
      display: inline-block;
      background-color: var(--primary-color);
      color: var(--white);
      padding: 0.8rem 2rem;
      border-radius: 50px;
      text-decoration: none;
      font-weight: 500;
      transition: var(--transition);
      margin-top: 1rem;
      border: 2px solid var(--primary-color);
    }

    .cta-button:hover {
      background-color: transparent;
      color: var(--primary-color);
      transform: translateY(-3px);
      box-shadow: var(--shadow-md);
    }

    .about-image {
      flex: 1 1 40%;
      min-width: 300px;
      position: relative;
    }

    .about-image img {
      width: 100%;
      border-radius: var(--border-radius);
      box-shadow: var(--shadow-lg);
      transition: var(--transition);
      height: auto;
      max-height: 500px;
      object-fit: cover;
    }

    .about-image:hover img {
      transform: scale(1.02);
    }

    .about-image::after {
      content: '';
      position: absolute;
      bottom: -20px;
      right: -20px;
      width: 100%;
      height: 100%;
      border: 3px solid var(--primary-color);
      border-radius: var(--border-radius);
      z-index: -1;
      transition: var(--transition);
    }

    .about-image:hover::after {
      bottom: -15px;
      right: -15px;
    }

    /* Mission Section */
    .mission-section {
      background-color: var(--bg-lighter);
      text-align: center;
      position: relative;
    }

    .mission-section::before {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 20px;
      background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
      opacity: 0.2;
    }

    .mission-section h2 {
      font-size: clamp(2rem, 4vw, 2.8rem);
      color: var(--primary-dark);
      margin-bottom: 2rem;
      position: relative;
      display: inline-block;
    }

    .mission-section h2::after {
      content: '';
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
      width: 100px;
      height: 4px;
      background-color: var(--secondary-color);
      border-radius: 2px;
    }

    .mission-section p {
      font-size: 1.1rem;
      max-width: 800px;
      margin: 0 auto;
    }

    /* Team Section */
    .team-section {
      background-color: var(--white);
      text-align: center;
    }

    .team-section h2 {
      font-size: clamp(2rem, 4vw, 2.8rem);
      color: var(--primary-dark);
      margin-bottom: 1rem;
    }

    .team-section .subtitle {
      color: var(--text-light);
      margin-bottom: 3rem;
      font-size: 1.1rem;
    }

    .team-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 2rem;
      margin-top: 2rem;
    }

    .team-member {
      background-color: var(--white);
      border-radius: var(--border-radius);
      overflow: hidden;
      box-shadow: var(--shadow-sm);
      transition: var(--transition);
      position: relative;
    }

    .team-member:hover {
      transform: translateY(-10px);
      box-shadow: var(--shadow-lg);
    }

    .member-image {
      height: 300px;
      overflow: hidden;
    }

    .member-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: var(--transition);
    }

    .team-member:hover .member-image img {
      transform: scale(1.05);
    }

    .member-info {
      padding: 1.5rem;
    }

    .member-info h3 {
      color: var(--primary-dark);
      font-size: 1.3rem;
      margin-bottom: 0.5rem;
    }

    .member-info p {
      color: var(--text-light);
      font-size: 0.9rem;
    }

    .social-links {
      display: flex;
      justify-content: center;
      gap: 1rem;
      margin-top: 1rem;
    }

    .social-links a {
      color: var(--primary-color);
      font-size: 1.2rem;
      transition: var(--transition);
    }

    .social-links a:hover {
      color: var(--primary-dark);
      transform: translateY(-3px);
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      section {
        padding: 4rem 1rem;
      }
      
      .about-content {
        flex-direction: column;
        text-align: center;
      }
      
      .about-text h1::after {
        left: 50%;
        transform: translateX(-50%);
      }
      
      .about-features li {
        text-align: left;
      }
      
      .about-image::after {
        display: none;
      }
      
      .team-grid {
        grid-template-columns: 1fr;
      }
    }

    /* Animation */
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .fade-in {
      animation: fadeIn 1s ease-out forwards;
    }

    .delay-1 { animation-delay: 0.2s; }
    .delay-2 { animation-delay: 0.4s; }
    .delay-3 { animation-delay: 0.6s; }
  </style>
</head>
<body>

<!-- About Section -->
<section class="about-section">
  <div class="container">
    <div class="about-content">
      <div class="about-text fade-in">
        <h1>About Infinity Salon</h1>
        <p>Welcome to Infinity Salon, where beauty meets innovation and every visit is a transformative experience. Established over a decade ago, we've grown from a small boutique to Pune's premier beauty destination, renowned for our exceptional service and artistic excellence.</p>
        <p>Our philosophy centers on enhancing your natural beauty while providing a sanctuary where you can relax, rejuvenate, and rediscover your confidence. Each member of our team is carefully selected for their expertise, creativity, and dedication to client satisfaction.</p>
        
        <ul class="about-features">
          <li class="fade-in delay-1">10+ years of award-winning beauty expertise</li>
          <li class="fade-in delay-1">Customized beauty consultations for every client</li>
          <li class="fade-in delay-2">Luxurious, hygienic environment with premium products</li>
          <li class="fade-in delay-2">Continuing education in the latest techniques</li>
          <li class="fade-in delay-3">10,000+ satisfied clients and counting</li>
        </ul>
        
      </div>
      
      <div class="about-image fade-in delay-1">
        <!-- High-quality salon interior image from Unsplash -->
        <img src="https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1280&q=80" 
             alt="Luxurious interior of Infinity Salon showing modern styling stations, comfortable seating, and elegant decor" 
             loading="lazy">
      </div>
    </div>
  </div>
</section>

<!-- Mission Section -->
<section class="mission-section">
  <div class="container">
    <h2 class="fade-in">Our Vision & Values</h2>
    <p class="fade-in delay-1">At Infinity Salon, we're committed to more than just beauty services - we're creating a movement of self-confidence and empowerment. Our vision is to be the most trusted beauty destination in India, known for our innovative techniques, sustainable practices, and exceptional client care. We believe true beauty comes from feeling valued, heard, and pampered in an environment that celebrates individuality.</p>
  </div>
</section>

<!-- Team Section -->
<section class="team-section">
  <div class="container">
    <h2 class="fade-in">Meet Our Master Stylists</h2>
    <p class="subtitle fade-in delay-1">Our award-winning team brings international experience and artistic passion to every service</p>
    
    <div class="team-grid">
      <div class="team-member fade-in">
        <div class="member-image">
          <!-- High-quality stylist image from Unsplash -->
          <img src="https://images.unsplash.com/photo-1559599101-f09722fb4948?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1280&q=80" 
               alt="Riya Sharma, our Hair Styling Expert working on a client's hair" 
               loading="lazy">
        </div>
        <div class="member-info">
          <h3>Riya Sharma</h3>
          <p>Creative Director & Hair Artist</p>
          <p class="bio">With 12 years in London and Milan, Riya specializes in precision cutting and balayage.</p>
          <div class="social-links">
            <a href="#" aria-label="Instagram profile of Riya Sharma">📸</a>
            <a href="#" aria-label="Professional profile of Riya Sharma">👔</a>
          </div>
        </div>
      </div>
      
      <div class="team-member fade-in delay-1">
        <div class="member-image">
          <!-- High-quality barber image from Unsplash -->
          <img src="https://images.unsplash.com/photo-1585747860715-2ba37e788b70?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1280&q=80" 
               alt="Kunal Mehta, our Men's Grooming Specialist giving a haircut" 
               loading="lazy">
        </div>
        <div class="member-info">
          <h3>Kunal Mehta</h3>
          <p>Men's Grooming Specialist</p>
          <p class="bio">Barbering champion with expertise in modern and classic men's styles and beard care.</p>
          <div class="social-links">
            <a href="#" aria-label="Instagram profile of Kunal Mehta">📸</a>
            <a href="#" aria-label="Professional profile of Kunal Mehta">👔</a>
          </div>
        </div>
      </div>
      
      <div class="team-member fade-in delay-2">
        <div class="member-image">
          <!-- High-quality makeup artist image from Unsplash -->
          <img src="https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1280&q=80" 
               alt="Simran Kaur, our Bridal Specialist applying makeup" 
               loading="lazy">
        </div>
        <div class="member-info">
          <h3>Simran Kaur</h3>
          <p>Makeup & Bridal Artist</p>
          <p class="bio">Transformed 500+ brides with her signature "natural glam" aesthetic and attention to detail.</p>
          <div class="social-links">
            <a href="#" aria-label="Instagram profile of Simran Kaur">📸</a>
            <a href="#" aria-label="Professional profile of Simran Kaur">👔</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Testimonials Section -->
<section class="mission-section" style="background-color: var(--white);">
  <div class="container">
    <h2 class="fade-in">Client Experiences</h2>
    <div class="team-grid" style="grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));">
      <div class="team-member fade-in" style="text-align: left;">
        <div class="member-image" style="height: 200px;">
          <!-- Happy client image from Unsplash -->
          <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1280&q=80" 
               alt="Happy client Sarah after her makeover at Infinity Salon" 
               loading="lazy">
        </div>
        <div class="member-info">
          <h3>Sarah K.</h3>
          <p style="color: var(--text-medium); font-style: italic;">"The best salon experience I've ever had! Riya transformed my hair exactly how I envisioned it. The attention to detail is unmatched."</p>
          <div style="color: var(--secondary-color); margin-top: 1rem;">★★★★★</div>
        </div>
      </div>
      
      <div class="team-member fade-in delay-1" style="text-align: left;">
        <div class="member-image" style="height: 200px;">
          <!-- Happy client image from Unsplash -->
          <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1280&q=80" 
               alt="Client Raj after his grooming session with Kunal" 
               loading="lazy">
        </div>
        <div class="member-info">
          <h3>Raj P.</h3>
          <p style="color: var(--text-medium); font-style: italic;">"Kunal is a true artist! My haircut and beard trim get compliments every time. The salon's ambiance is so relaxing too."</p>
          <div style="color: var(--secondary-color); margin-top: 1rem;">★★★★★</div>
        </div>
      </div>
    </div>
  </div>
</section>

<script>
  // Simple intersection observer for animations
  document.addEventListener('DOMContentLoaded', function() {
    const fadeElements = document.querySelectorAll('.fade-in');
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = 1;
          entry.target.style.transform = 'translateY(0)';
        }
      });
    }, { threshold: 0.1 });
    
    fadeElements.forEach(el => {
      el.style.opacity = 0;
      el.style.transform = 'translateY(20px)';
      el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
      observer.observe(el);
    });
  });
</script>

</body>
</html>