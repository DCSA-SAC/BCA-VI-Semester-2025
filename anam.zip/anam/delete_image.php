<?php
session_start();
include 'db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin_dashboard.php");
    exit;
}

$id = $_GET['id'];
$query = "SELECT image_path FROM gallery WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$image = $result->fetch_assoc();

if ($image) {
    unlink($image['image_path']); // Delete the file from the server
    $query = "DELETE FROM gallery WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: gallery.php");
        exit;
    } else {
        echo "Failed to delete image.";
    }
} else {
    echo "Image not found.";
}
?>