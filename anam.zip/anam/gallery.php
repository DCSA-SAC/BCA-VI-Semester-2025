<?php
include 'db.php'; // Include database connection

// Fetching gallery images from the database
$query = "SELECT * FROM gallery ORDER BY created_at DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery - Infinity Salon</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/css/lightgallery.min.css">
    <style>
        :root {
            --primary: #d4a373;
            --primary-dark: #b58a5e;
            --secondary: #fefae0;
            --dark: #333;
            --light: #f8f9fa;
            --white: #ffffff;
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            --border-radius: 12px;
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: var(--light);
            color: var(--dark);
            line-height: 1.6;
        }

        .Photo_Gallery {
            padding: 5rem 2rem;
            max-width: 1400px;
            margin: 0 auto;
        }

        .Photo_Gallery_title {
            text-align: center;
            margin-bottom: 3rem;
        }

        .Photo_Gallery_title h3 {
            font-size: 1.2rem;
            color: var(--primary);
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 1rem;
        }

        .Photo_Gallery_title h2 {
            font-size: 2.5rem;
            font-weight: 600;
            position: relative;
            display: inline-block;
            padding-bottom: 1rem;
        }

        .Photo_Gallery_title h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: var(--primary);
        }

        .gallery {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
        }

        .Photo_Gallery_Image {
            position: relative;
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: var(--transition);
            aspect-ratio: 1/1;
            cursor: pointer;
        }

        .Photo_Gallery_Image:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }

        .Photo_Gallery_Image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: var(--transition);
        }

        .Photo_Gallery_Image:hover img {
            transform: scale(1.05);
        }

        .Photo_Gallery_Image::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(to top, rgba(0,0,0,0.5), transparent);
            opacity: 0;
            transition: var(--transition);
            z-index: 1;
        }

        .Photo_Gallery_Image:hover::before {
            opacity: 1;
        }

        .Photo_Gallery_Image::after {
            content: '\f06e'; /* Font Awesome search icon */
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: var(--white);
            font-size: 2rem;
            opacity: 0;
            transition: var(--transition);
            z-index: 2;
        }

        .Photo_Gallery_Image:hover::after {
            opacity: 1;
        }

        /* Lightbox Overrides */
        .lg-backdrop {
            background-color: rgba(0, 0, 0, 0.9);
        }

        .lg-toolbar {
            background-color: transparent;
        }

        .lg-actions .lg-next, .lg-actions .lg-prev {
            color: var(--white);
            background-color: rgba(212, 163, 115, 0.7);
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .gallery {
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            }
        }

        @media (max-width: 768px) {
            .Photo_Gallery {
                padding: 3rem 1.5rem;
            }
            
            .Photo_Gallery_title h2 {
                font-size: 2rem;
            }
        }

        @media (max-width: 576px) {
            .gallery {
                grid-template-columns: 1fr;
            }
            
            .Photo_Gallery_title h2 {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <section class="Photo_Gallery">
        <div class="Photo_Gallery_title section_title">
            <h3>Photo Gallery</h3>
            <h2>Inside Look at Our Salon</h2>
            <p class="gallery-subtitle">Explore our beautiful workspace and talented team in action</p>
        </div>
        <div class="gallery" id="lightgallery">
            <!-- Loop to display gallery images -->
            <?php while ($image = $result->fetch_assoc()): ?>
                <a href="<?php echo htmlspecialchars($image['image_path']); ?>" class="Photo_Gallery_Image section_Image" data-sub-html="<h4>Infinity Salon</h4><p><?php echo htmlspecialchars($image['title'] ?? 'Our beautiful salon space'); ?></p>">
                    <img src="<?php echo htmlspecialchars($image['image_path']); ?>" alt="Infinity Salon Gallery Image">
                </a>
            <?php endwhile; ?>
        </div>
    </section>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.7.1/lightgallery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lg-zoom/2.7.1/lg-zoom.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lg-fullscreen/2.7.1/lg-fullscreen.min.js"></script>
    <script>
        // Initialize lightGallery
        document.addEventListener('DOMContentLoaded', () => {
            lightGallery(document.getElementById('lightgallery'), {
                selector: '.Photo_Gallery_Image',
                download: false,
                zoom: true,
                counter: true,
                getCaptionFromTitleOrAlt: false
            });
            
            // Add subtle animation to gallery items
            const galleryItems = document.querySelectorAll('.Photo_Gallery_Image');
            galleryItems.forEach((item, index) => {
                item.style.opacity = '0';
                item.style.transform = 'translateY(20px)';
                item.style.animation = `fadeInUp 0.5s ease-out forwards ${index * 0.1}s`;
            });
        });

        // Add keyframes dynamically
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>