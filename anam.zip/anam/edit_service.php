<?php
session_start();
include 'db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin_dashboard.php");
    exit;
}

$id = $_GET['id'];
$query = "SELECT * FROM services WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$service = $result->fetch_assoc();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    
    // Handle image upload
    $image_path = $service['image_path']; // Keep existing image by default
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/services/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_name = uniqid() . '_' . basename($_FILES['image']['name']);
        $target_file = $upload_dir . $file_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        
        // Check if image file is a actual image
        $check = getimagesize($_FILES['image']['tmp_name']);
        if ($check === false) {
            $error = "File is not an image.";
        }
        
        // Check file size (max 2MB)
        elseif ($_FILES['image']['size'] > 2000000) {
            $error = "Sorry, your file is too large (max 2MB).";
        }
        
        // Allow certain file formats
        elseif (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
            $error = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        }
        
        // If everything is ok, try to upload file
        elseif (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            // Delete old image if it exists
            if (!empty($service['image_path']) && file_exists($service['image_path'])) {
                unlink($service['image_path']);
            }
            $image_path = $target_file;
        } else {
            $error = "Sorry, there was an error uploading your file.";
        }
    }
    
    if (empty($error)) {
        $query = "UPDATE services SET name = ?, description = ?, price = ?, image_path = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssdsi", $name, $description, $price, $image_path, $id);

        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Service updated successfully!";
            header("Location: services.php");
            exit;
        } else {
            $error = "Failed to update service. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Service | Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
            --danger-color: #ff3333;
            --border-color: #e0e0e0;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7fb;
            color: var(--dark-color);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }
        
        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .header {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .header h2 {
            color: var(--primary-color);
            margin: 0;
            font-size: 28px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .header h2 i {
            font-size: 24px;
        }
        
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            color: var(--primary-color);
            text-decoration: none;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .back-link:hover {
            text-decoration: underline;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }
        
        input[type="text"],
        input[type="number"],
        textarea,
        input[type="file"] {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }
        
        input[type="text"]:focus,
        input[type="number"]:focus,
        textarea:focus,
        input[type="file"]:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
        }
        
        textarea {
            min-height: 120px;
            resize: vertical;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        
        .btn:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .btn i {
            font-size: 14px;
        }
        
        .error {
            color: var(--danger-color);
            background-color: rgba(255, 51, 51, 0.1);
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 4px solid var(--danger-color);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .image-preview {
            margin-bottom: 25px;
        }
        
        .current-image {
            max-width: 200px;
            max-height: 200px;
            border-radius: 6px;
            border: 1px solid var(--border-color);
            margin-top: 10px;
            display: block;
        }
        
        .no-image {
            display: inline-block;
            padding: 15px;
            background-color: #f0f0f0;
            border-radius: 6px;
            color: #999;
        }
        
        .file-upload {
            position: relative;
            overflow: hidden;
            display: inline-block;
        }
        
        .file-upload-btn {
            background-color: #f0f0f0;
            color: #555;
            padding: 10px 15px;
            border-radius: 6px;
            cursor: pointer;
            border: 1px dashed #ccc;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            width: 100%;
            justify-content: center;
        }
        
        .file-upload-btn:hover {
            background-color: #e0e0e0;
            border-color: #aaa;
        }
        
        .file-upload input[type="file"] {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        
        .file-name {
            margin-top: 8px;
            font-size: 14px;
            color: #666;
        }
        
        @media (max-width: 768px) {
            .container {
                margin: 20px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="services.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Services
        </a>
        
        <div class="header">
            <h2><i class="fas fa-edit"></i> Edit Service</h2>
        </div>
        
        <?php if (!empty($error)): ?>
            <div class="error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Service Name</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($service['name']); ?>" placeholder="Enter service name" required>
            </div>
            
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" placeholder="Enter service description" required><?php echo htmlspecialchars($service['description']); ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="price">Price ($)</label>
                <input type="number" id="price" name="price" step="0.01" min="0" value="<?php echo htmlspecialchars($service['price']); ?>" placeholder="Enter price" required>
            </div>
            
            <div class="form-group">
                <label>Service Image</label>
                <?php if (!empty($service['image_path'])): ?>
                    <div class="image-preview">
                        <img src="<?php echo htmlspecialchars($service['image_path']); ?>" alt="Current service image" class="current-image">
                        <p class="file-name">Current image: <?php echo basename($service['image_path']); ?></p>
                    </div>
                <?php else: ?>
                    <div class="no-image">No image currently set for this service</div>
                <?php endif; ?>
                
                <div class="file-upload">
                    <label class="file-upload-btn">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <span>Choose new image (Max 2MB)</span>
                        <input type="file" name="image" id="image" accept="image/*">
                    </label>
                    <div id="file-selected-name" class="file-name"></div>
                </div>
                <small>Accepted formats: JPG, JPEG, PNG, GIF</small>
            </div>
            
            <button type="submit" class="btn">
                <i class="fas fa-save"></i> Update Service
            </button>
        </form>
    </div>

    <script>
        // Show selected file name
        document.getElementById('image').addEventListener('change', function(e) {
            const fileName = e.target.files[0] ? e.target.files[0].name : 'No file selected';
            document.getElementById('file-selected-name').textContent = 'Selected: ' + fileName;
        });
    </script>
</body>
</html>