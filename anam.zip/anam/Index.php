<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Infinity Hair Salon | Premium Hair Services & Styling</title>
    <meta name="description" content="Premium hair salon offering cutting, coloring, and styling services with expert stylists. Book your appointment today for a luxurious hair experience.">
    <meta name="keywords" content="hair salon, hair styling, haircut, hair color, balayage, keratin treatment, bridal hairstyles, hair extensions">
    
    <!-- Favicon -->
    <link rel="icon" href="https://img.icons8.com/fluency/48/000000/scissors.png" type="image/png">
    
    <!-- Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Splide JS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/css/splide.min.css">
    
    <!-- AOS Animation -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <style>
        :root {
            --primary: #d4af37; /* Gold color for luxury feel */
            --primary-dark: #b38b2d;
            --secondary: #2b2d42;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            --shadow-sm: 0 2px 4px rgba(0, 0, 0, 0.1);
            --shadow-md: 0 4px 8px rgba(0, 0, 0, 0.15);
            --shadow-lg: 0 8px 16px rgba(0, 0, 0, 0.2);
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
            --radius-xl: 24px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            color: var(--dark);
            background-color: var(--light);
            line-height: 1.6;
            overflow-x: hidden;
        }

        h1, h2, h3, h4 {
            font-family: 'Playfair Display', serif;
            font-weight: 600;
            line-height: 1.2;
        }

        a {
            text-decoration: none;
            color: inherit;
            transition: var(--transition);
        }

        img {
            max-width: 100%;
            height: auto;
            display: block;
        }

        ul {
            list-style: none;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .section {
            padding: 100px 0;
            position: relative;
        }

        .section-title {
            text-align: center;
            margin-bottom: 60px;
        }

        .section-title .subtitle {
            display: inline-block;
            color: var(--primary);
            font-size: 18px;
            font-weight: 500;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
        }

        .section-title .subtitle::after {
            content: '';
            position: absolute;
            width: 50px;
            height: 2px;
            background: var(--primary);
            bottom: -8px;
            left: 50%;
            transform: translateX(-50%);
        }

        .section-title h2 {
            font-size: 42px;
            color: var(--secondary);
            margin-bottom: 20px;
        }

        .section-title p {
            max-width: 700px;
            margin: 0 auto;
            color: var(--gray);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 12px 28px;
            border-radius: var(--radius-xl);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: var(--transition);
            border: none;
            cursor: pointer;
            font-size: 14px;
            white-space: nowrap;
        }

        .btn-primary {
            background: var(--primary);
            color: var(--secondary);
            box-shadow: var(--shadow-sm);
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            color: white;
        }

        .btn-outline {
            border: 2px solid var(--primary);
            color: var(--primary);
            background: transparent;
        }

        .btn-outline:hover {
            background: var(--primary);
            color: white;
        }

        /* Header & Navigation */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            transition: var(--transition);
            padding: 20px 0;
            background: rgba(255, 255, 255, 0.95);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .header.scrolled {
            padding: 15px 0;
            background: rgba(255, 255, 255, 0.98);
            box-shadow: var(--shadow-md);
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 28px;
            font-weight: 700;
            color: var(--secondary);
            font-family: 'Playfair Display', serif;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo span {
            color: var(--primary);
        }

        .logo-icon {
            color: var(--primary);
            font-size: 32px;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .nav-menu li a {
            font-weight: 500;
            font-size: 16px;
            position: relative;
            padding: 5px 0;
        }

        .nav-menu li a::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            background: var(--primary);
            bottom: 0;
            left: 0;
            transition: var(--transition);
        }

        .nav-menu li a:hover::after,
        .nav-menu li a.active::after {
            width: 100%;
        }

        .nav-menu li a:hover {
            color: var(--primary);
        }

        .menu-toggle {
            display: none;
            font-size: 24px;
            cursor: pointer;
            z-index: 1001;
            color: var(--secondary);
        }

        /* Hero Section */
        .hero {
            min-height: 100vh;
            display: flex;
            align-items: center;
            padding: 150px 0 100px;
            background: linear-gradient(135deg, rgba(43, 45, 66, 0.9) 0%, rgba(43, 45, 66, 0.8) 100%), url('https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1684&q=80') no-repeat center center/cover;
            color: white;
            position: relative;
            overflow: hidden;
        }

        .hero::before {
            content: '';
            position: absolute;
            bottom: -50px;
            left: 0;
            width: 100%;
            height: 100px;
            background: url('data:image/svg+xml;utf8,<svg viewBox="0 0 1200 120" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none"><path d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" opacity=".25" fill="%23f8f9fa"/><path d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z" opacity=".5" fill="%23f8f9fa"/><path d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z" fill="%23f8f9fa"/></svg>') no-repeat center bottom/cover;
            z-index: 1;
        }

        .hero-content {
            max-width: 600px;
        }

        .hero-subtitle {
            font-size: 18px;
            color: var(--primary);
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 3px;
            font-weight: 500;
        }

        .hero-title {
            font-size: 64px;
            margin-bottom: 25px;
            line-height: 1.1;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }

        .hero-text {
            font-size: 18px;
            margin-bottom: 40px;
            opacity: 0.9;
        }

        .hero-features {
            margin: 30px 0;
        }

        .hero-features li {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            font-size: 18px;
        }

        .hero-features li::before {
            content: '✓';
            color: var(--primary);
            font-weight: bold;
            margin-right: 10px;
            font-size: 20px;
        }

        .hero-btns {
            display: flex;
            gap: 20px;
            margin-top: 40px;
        }

        .hero-image {
            position: absolute;
            right: 0;
            bottom: 0;
            width: 50%;
            max-width: 700px;
            z-index: 1;
        }

        .hero-image img {
            width: 100%;
            height: auto;
            object-fit: contain;
            filter: drop-shadow(0 10px 20px rgba(0, 0, 0, 0.3));
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }

        /* About Section */
        .about {
            background: white;
            position: relative;
        }

        .about-content {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 60px;
            align-items: center;
        }

        .about-images {
            position: relative;
            height: 500px;
        }

        .about-img-main {
            position: absolute;
            width: 70%;
            height: 80%;
            border-radius: var(--radius-lg);
            overflow: hidden;
            box-shadow: var(--shadow-lg);
            z-index: 2;
        }

        .about-img-main img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: var(--transition);
        }

        .about-img-main:hover img {
            transform: scale(1.05);
        }

        .about-img-secondary {
            position: absolute;
            width: 50%;
            height: 60%;
            right: 0;
            bottom: 0;
            border-radius: var(--radius-lg);
            overflow: hidden;
            box-shadow: var(--shadow-lg);
            z-index: 1;
            border: 5px solid white;
        }

        .about-img-secondary img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: var(--transition);
        }

        .about-img-secondary:hover img {
            transform: scale(1.05);
        }

        .about-experience {
            position: absolute;
            bottom: -30px;
            left: -30px;
            background: var(--primary);
            color: var(--secondary);
            padding: 30px;
            border-radius: var(--radius-md);
            text-align: center;
            z-index: 3;
            box-shadow: var(--shadow-md);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        .about-experience h3 {
            font-size: 48px;
            margin-bottom: 5px;
        }

        .about-features {
            margin: 30px 0;
        }

        .about-features li {
            display: flex;
            margin-bottom: 15px;
            font-weight: 500;
            padding: 15px;
            background: rgba(212, 175, 55, 0.1);
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .about-features li:hover {
            background: rgba(212, 175, 55, 0.2);
            transform: translateX(5px);
        }

        .about-features li span {
            color: var(--primary);
            font-weight: 700;
            margin-right: 10px;
            font-size: 18px;
        }

        /* Services Section */
        .services {
            background: var(--light-gray);
        }

        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .service-card {
            background: white;
            border-radius: var(--radius-md);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            text-align: center;
            padding: 40px 30px;
            position: relative;
            overflow: hidden;
        }

        .service-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: var(--primary);
            transform: scaleX(0);
            transform-origin: left;
            transition: var(--transition);
        }

        .service-card:hover::before {
            transform: scaleX(1);
        }

        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-lg);
        }

        .service-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 25px;
            background: var(--primary);
            color: var(--secondary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .service-card h3 {
            margin-bottom: 15px;
            font-size: 22px;
        }

        .service-card p {
            margin-bottom: 20px;
        }

        /* Gallery Section */
        .gallery {
            background: white;
        }

        .gallery-slider {
            margin: 0 auto;
            max-width: 1200px;
        }

        .gallery-slide {
            padding: 0 15px;
            transition: var(--transition);
        }

        .gallery-slide img {
            border-radius: var(--radius-md);
            width: 100%;
            height: 400px;
            object-fit: cover;
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
        }

        .gallery-slide:hover {
            transform: translateY(-5px);
        }

        .gallery-slide:hover img {
            transform: scale(1.02);
            box-shadow: var(--shadow-md);
        }

        /* Testimonials Section */
        .testimonials {
            background: linear-gradient(rgba(43, 45, 66, 0.9), rgba(43, 45, 66, 0.9)), url('https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80') no-repeat center center/cover;
            color: white;
        }

        .testimonials .section-title h2,
        .testimonials .section-title p {
            color: white;
        }

        .testimonial-slider {
            max-width: 800px;
            margin: 0 auto;
        }

        .testimonial-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: var(--radius-md);
            padding: 40px;
            text-align: center;
            margin: 0 20px;
            border: 1px solid rgba(212, 175, 55, 0.3);
            transition: var(--transition);
        }

        .testimonial-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        .testimonial-text {
            font-size: 18px;
            font-style: italic;
            margin-bottom: 30px;
            position: relative;
        }

        .testimonial-text::before,
        .testimonial-text::after {
            content: '"';
            font-size: 60px;
            color: var(--primary);
            opacity: 0.3;
            position: absolute;
        }

        .testimonial-text::before {
            top: -30px;
            left: -20px;
        }

        .testimonial-text::after {
            bottom: -50px;
            right: -20px;
        }

        .testimonial-author {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }

        .testimonial-author img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--primary);
        }

        .author-info h4 {
            margin-bottom: 5px;
            font-size: 18px;
        }

        .author-info p {
            opacity: 0.8;
            font-size: 14px;
        }

        .testimonial-rating {
            color: var(--primary);
            margin-top: 5px;
            font-size: 14px;
        }

        /* Contact Section */
        .contact-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-top: 60px;
        }

        .contact-card {
            background: white;
            border-radius: var(--radius-md);
            padding: 30px;
            text-align: center;
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            border-bottom: 3px solid transparent;
        }

        .contact-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-md);
            border-bottom-color: var(--primary);
        }

        .contact-icon {
            width: 70px;
            height: 70px;
            margin: 0 auto 20px;
            background: var(--primary);
            color: var(--secondary);
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .contact-card h3 {
            margin-bottom: 15px;
            font-size: 20px;
        }

        .contact-card p, 
        .contact-card a {
            color: var(--gray);
            margin-bottom: 5px;
            display: block;
        }

        .contact-card a:hover {
            color: var(--primary);
        }

        /* Appointment Banner */
        .appointment-banner {
            background: linear-gradient(135deg, var(--secondary) 0%, var(--dark) 100%);
            color: white;
            padding: 60px 0;
            margin: 80px 0;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .appointment-banner::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><path fill="rgba(212, 175, 55, 0.05)" d="M0,0 L100,0 L100,100 L0,100 Z" /></svg>');
            background-size: cover;
            opacity: 0.5;
        }

        .appointment-banner h2 {
            font-size: 36px;
            margin-bottom: 20px;
            position: relative;
        }

        .appointment-banner p {
            max-width: 700px;
            margin: 0 auto 30px;
            font-size: 18px;
            opacity: 0.9;
            position: relative;
        }

        /* Footer */
        .footer {
            background: var(--secondary);
            color: white;
            padding: 80px 0 30px;
            position: relative;
        }

        .footer::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 10px;
            background: var(--primary);
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 60px;
        }

        .footer-logo {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 20px;
            font-family: 'Playfair Display', serif;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .footer-logo span {
            color: var(--primary);
        }

        .footer-about p {
            margin-bottom: 20px;
            opacity: 0.8;
        }

        .social-links {
            display: flex;
            gap: 15px;
        }

        .social-links a {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            transition: var(--transition);
            color: white;
        }

        .social-links a:hover {
            background: var(--primary);
            transform: translateY(-3px);
            color: var(--secondary);
        }

        .footer-links h3 {
            font-size: 20px;
            margin-bottom: 25px;
            position: relative;
            padding-bottom: 10px;
        }

        .footer-links h3::after {
            content: '';
            position: absolute;
            width: 40px;
            height: 2px;
            background: var(--primary);
            bottom: 0;
            left: 0;
        }

        .footer-links ul li {
            margin-bottom: 12px;
        }

        .footer-links ul li a {
            opacity: 0.8;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .footer-links ul li a i {
            color: var(--primary);
            font-size: 12px;
            transition: var(--transition);
        }

        .footer-links ul li a:hover {
            opacity: 1;
            color: var(--primary);
            padding-left: 5px;
        }

        .footer-links ul li a:hover i {
            transform: translateX(3px);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-bottom p {
            opacity: 0.7;
            font-size: 14px;
        }

        /* Back to Top Button */
        .back-to-top {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: var(--primary);
            color: var(--secondary);
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            box-shadow: var(--shadow-md);
            z-index: 999;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
        }

        .back-to-top.active {
            opacity: 1;
            visibility: visible;
        }

        .back-to-top:hover {
            background: var(--primary-dark);
            color: white;
            transform: translateY(-5px);
        }

        /* Responsive Styles */
        @media (max-width: 1200px) {
            .hero-title {
                font-size: 54px;
            }
            
            .about-images {
                height: 450px;
            }
        }

        @media (max-width: 992px) {
            .hero {
                padding: 120px 0 80px;
                text-align: center;
            }
            
            .hero-content {
                max-width: 100%;
                margin: 0 auto;
            }
            
            .hero-title {
                font-size: 48px;
            }
            
            .hero-features {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 15px;
            }
            
            .hero-features li {
                margin-bottom: 0;
            }
            
            .hero-btns {
                justify-content: center;
            }
            
            .hero-image {
                display: none;
            }
            
            .about-content {
                grid-template-columns: 1fr;
            }
            
            .about-images {
                height: 400px;
                max-width: 600px;
                margin: 0 auto 60px;
            }

            .appointment-banner h2 {
                font-size: 32px;
            }
        }

        @media (max-width: 768px) {
            .menu-toggle {
                display: block;
            }
            
            .nav-menu {
                position: fixed;
                top: 0;
                right: -100%;
                width: 80%;
                max-width: 350px;
                height: 100vh;
                background: white;
                flex-direction: column;
                align-items: flex-start;
                padding: 100px 40px 40px;
                box-shadow: -5px 0 15px rgba(0, 0, 0, 0.1);
                transition: var(--transition);
                z-index: 1000;
            }
            
            .nav-menu.active {
                right: 0;
            }
            
            .nav-menu li {
                width: 100%;
            }
            
            .nav-menu li a {
                display: block;
                padding: 15px 0;
                border-bottom: 1px solid var(--light-gray);
            }
            
            .section {
                padding: 80px 0;
            }
            
            .section-title h2 {
                font-size: 36px;
            }
            
            .hero-title {
                font-size: 42px;
            }
            
            .about-images {
                height: 350px;
            }
            
            .about-experience {
                padding: 20px;
            }
            
            .about-experience h3 {
                font-size: 36px;
            }

            .appointment-banner {
                padding: 40px 0;
            }

            .appointment-banner h2 {
                font-size: 28px;
            }
        }

        @media (max-width: 576px) {
            .hero {
                padding: 100px 0 60px;
            }
            
            .hero-title {
                font-size: 36px;
            }
            
            .hero-subtitle {
                font-size: 16px;
            }
            
            .hero-text {
                font-size: 16px;
            }
            
            .hero-btns {
                flex-direction: column;
                gap: 15px;
            }
            
            .btn {
                width: 100%;
            }
            
            .section-title h2 {
                font-size: 32px;
            }
            
            .about-images {
                height: 300px;
            }
            
            .about-experience {
                bottom: -20px;
                left: -20px;
                padding: 15px;
            }
            
            .about-experience h3 {
                font-size: 30px;
            }

            .appointment-banner h2 {
                font-size: 24px;
            }

            .appointment-banner p {
                font-size: 16px;
            }
        }
    </style>
</head>

<body>
    <!-- Header -->
    <header class="header" id="header">
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <i class="fas fa-cut logo-icon"></i>
                    Infinity<span>Salon</span>
                </a>
                
                <div class="menu-toggle" id="menu-toggle">
                    <i class="ri-menu-line"></i>
                </div>
                
                <ul class="nav-menu" id="nav-menu">
                    <li><a href="index.php" class="active">Home</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="about.php">about us</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="staff-details.html">Our Team</a></li>
                    <li><a href="Feedback.php">Feedback</a></li>
                    <?php if (isset($_SESSION['user'])): ?>
                        <li><a href="book-appointment.php" class="btn btn-primary">Book Now</a></li>
                        <li><a href="logout.php" style="color: var(--primary);"><i class="ri-logout-box-r-line"></i> Logout</a></li>
                    <?php else: ?>
                        <li><a href="login.php"><i class="ri-login-box-line"></i> Login</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero" id="home">
        <div class="container">
            <div class="hero-content" data-aos="fade-up">
                <p class="hero-subtitle">Welcome to Infinity Salon</p>
                <h1 class="hero-title">Experience Luxury Hair Care</h1>
                <p class="hero-text">
                    Where beauty meets perfection. Our expert stylists create personalized looks that enhance 
                    your natural beauty and reflect your unique personality.
                </p>
                
                <ul class="hero-features">
                    <li>Premium Quality Hair Products</li>
                    <li>Certified Stylists with 15+ Years Experience</li>
                    <li>Personalized Hair Care Solutions</li>
                    <li>Luxurious Salon Environment</li>
                </ul>
                
                <div class="hero-btns">
                <?php if (isset($_SESSION['user'])): ?>
                    <a href="book-appointment.php" class="btn btn-primary">
                        <i class="ri-calendar-line"></i> Book Appointment
                    </a>
                    <?php else: ?>
                    <a href="login.php"><i class="ri-login-box-line"></i> Login</a>
                    <?php endif; ?>
                    <a href="services.php" class="btn btn-outline">
                        <i class="ri-service-line"></i> Our Services
                    </a>
                </div>
            </div>
            
            <div class="hero-image" data-aos="fade-left">
                <img src="https://images.unsplash.com/photo-1519699047748-de8e457a634e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=880&q=80" alt="Stylist working on client's hair">
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="section about" id="about">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <p class="subtitle">About Us</p>
                <h2>Luxury Salon Where You Will Feel Unique</h2>
                <p>Experience the ultimate hair transformation at our premium salon. We combine creativity, expertise, and the latest trends to bring out your best look.</p>
            </div>
            
            <div class="about-content">
                <div class="about-images" data-aos="fade-right">
                    <div class="about-img-main">
                        <img src="https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=880&q=80" alt="Salon interior">
                    </div>
                    <div class="about-img-secondary">
                        <img src="https://images.unsplash.com/photo-1580618672591-eb180b1a973f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1469&q=80" alt="Stylist working">
                    </div>
                    <div class="about-experience" data-aos="zoom-in">
                        <h3>18+</h3>
                        <p>Years of Excellence</p>
                    </div>
                </div>
                
                <div class="about-text" data-aos="fade-left">
                    <h2>Our Story</h2>
                    <p>Founded in 2003, Infinity Salon has been the go-to destination for premium hair services in our community. Our founder, Sarah Johnson, envisioned a space where clients could receive top-notch services in a relaxing, luxurious environment.</p>
                    
                    <ul class="about-features">
                        <li><span>01.</span> The hair cutting and styling with 18 years of experience</li>
                        <li><span>02.</span> Update the latest technology and trends in the world</li>
                        <li><span>03.</span> Using the best products from the top providers</li>
                        <li><span>04.</span> Personalized consultation for every client</li>
                        <li><span>05.</span> Continuous education and training for our team</li>
                    </ul>
                    
                    <a href="about.php" class="btn btn-primary">
                        <i class="ri-information-line"></i> Learn More
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section class="section services" id="services">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <p class="subtitle">Our Services</p>
                <h2>Professional Hair Services</h2>
                <p>We offer a wide range of premium hair services to meet all your styling needs.</p>
            </div>
            
            <div class="services-grid">
                <div class="service-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="service-icon">
                        <i class="ri-scissors-line"></i>
                    </div>
                    <h3>Cutting & Styling</h3>
                    <p>Get the perfect haircut and style that suits your personality. Our expert stylists ensure precision and creativity in every cut.</p>
                    <a href="services.php#cutting" class="btn btn-outline" style="margin-top: 20px;">
                        <i class="ri-arrow-right-line"></i> Learn More
                    </a>
                </div>
                
                <div class="service-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="service-icon">
                        <i class="ri-palette-line"></i>
                    </div>
                    <h3>Hair Coloring</h3>
                    <p>Enhance your look with vibrant, long-lasting hair colors. From natural shades to bold transformations, we use top-quality products.</p>
                    <a href="services.php#coloring" class="btn btn-outline" style="margin-top: 20px;">
                        <i class="ri-arrow-right-line"></i> Learn More
                    </a>
                </div>
                
                <div class="service-card" data-aos="fade-up" data-aos-delay="300">
                    <div class="service-icon">
                        <i class="ri-spa-line"></i>
                    </div>
                    <h3>Hair Treatments</h3>
                    <p>Revitalize your hair with deep-conditioning treatments, keratin therapy, and scalp nourishment for stronger, healthier strands.</p>
                    <a href="services.php#treatments" class="btn btn-outline" style="margin-top: 20px;">
                        <i class="ri-arrow-right-line"></i> Learn More
                    </a>
                </div>
                
                <div class="service-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="service-icon">
                        <i class="ri-women-line"></i>
                    </div>
                    <h3>Bridal Styling</h3>
                    <p>Make your special day perfect with our bridal hair and makeup services. We create timeless looks that complement your wedding style.</p>
                    <a href="services.php#bridal" class="btn btn-outline" style="margin-top: 20px;">
                        <i class="ri-arrow-right-line"></i> Learn More
                    </a>
                </div>
                
                <div class="service-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="service-icon">
                        <i class="ri-hair-line"></i>
                    </div>
                    <h3>Hair Extensions</h3>
                    <p>Add length and volume with our premium hair extensions. We offer various methods to match your hair type and desired look.</p>
                    <a href="services.php#extensions" class="btn btn-outline" style="margin-top: 20px;">
                        <i class="ri-arrow-right-line"></i> Learn More
                    </a>
                </div>
                
                <div class="service-card" data-aos="fade-up" data-aos-delay="300">
                    <div class="service-icon">
                        <i class="ri-heart-line"></i>
                    </div>
                    <h3>Special Occasion</h3>
                    <p>Get red-carpet ready with our special occasion styling. Perfect for proms, parties, or any event where you want to shine.</p>
                    <a href="services.php#occasion" class="btn btn-outline" style="margin-top: 20px;">
                        <i class="ri-arrow-right-line"></i> Learn More
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Appointment Banner -->
    <section class="appointment-banner">
        <div class="container">
            <h2 data-aos="fade-up">Ready for Your Hair Transformation?</h2>
            <p data-aos="fade-up" data-aos-delay="100">Book your appointment today and experience the Infinity Salon difference. Our team is ready to help you achieve your dream look.</p>
            <div data-aos="fade-up" data-aos-delay="200">
            <?php if (isset($_SESSION['user'])): ?>
                    <a href="book-appointment.php" class="btn btn-primary">
                        <i class="ri-calendar-line"></i> Book Appointment
                    </a>
                    <?php else: ?>
                    <a href="login.php"><i class="btn btn-primary">Login for Book Now</i> </a>
                    <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Gallery Section -->
    <section class="section gallery" id="gallery">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <p class="subtitle">Our Works</p>
                <h2>Hair Transformation Gallery</h2>
                <p>Browse through our collection of stunning hair makeovers and styles.</p>
            </div>
            
            <div class="gallery-slider splide" data-aos="fade-up">
                <div class="splide__track">
                    <ul class="splide__list">
                        <li class="splide__slide gallery-slide">
                            <img src="https://images.unsplash.com/photo-1513201099705-a9746e1e201f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80" alt="Hair coloring transformation">
                        </li>
                        <li class="splide__slide gallery-slide">
                            <img src="https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=880&q=80" alt="Haircut transformation">
                        </li>
                        <li class="splide__slide gallery-slide">
                            <img src="https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80" alt="Styling service">
                        </li>
                        <li class="splide__slide gallery-slide">
                            <img src="https://images.unsplash.com/photo-1559599101-f09722fb4948?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1469&q=80" alt="Bridal hairstyle">
                        </li>
                        <li class="splide__slide gallery-slide">
                            <img src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" alt="Men's haircut">
                        </li>
                        <li class="splide__slide gallery-slide">
                            <img src="https://images.unsplash.com/photo-1600334129128-685c5582fd35?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" alt="Hair treatment">
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="section testimonials" id="testimonials">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <p class="subtitle">Testimonials</p>
                <h2>What Our Clients Say</h2>
                <p>Hear from our satisfied clients about their experiences at Infinity Salon.</p>
            </div>
            
            <div class="testimonial-slider splide" data-aos="fade-up">
                <div class="splide__track">
                    <ul class="splide__list">
                        <li class="splide__slide">
                            <div class="testimonial-card">
                                <p class="testimonial-text">I've been coming to Infinity Salon for years and wouldn't trust anyone else with my hair. The stylists are true artists who always understand exactly what I want.</p>
                                <div class="testimonial-author">
                                    <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Jessica Parker">
                                    <div class="author-info">
                                        <h4>Jessica Parker</h4>
                                        <p>Regular Client</p>
                                        <div class="testimonial-rating">
                                            <i class="ri-star-fill"></i>
                                            <i class="ri-star-fill"></i>
                                            <i class="ri-star-fill"></i>
                                            <i class="ri-star-fill"></i>
                                            <i class="ri-star-fill"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="splide__slide">
                            <div class="testimonial-card">
                                <p class="testimonial-text">The balayage highlights I got at Infinity Salon are absolutely stunning! They took the time to consult with me and created exactly the look I was hoping for.</p>
                                <div class="testimonial-author">
                                    <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Michael Chen">
                                    <div class="author-info">
                                        <h4>Michael Chen</h4>
                                        <p>New Client</p>
                                        <div class="testimonial-rating">
                                            <i class="ri-star-fill"></i>
                                            <i class="ri-star-fill"></i>
                                            <i class="ri-star-fill"></i>
                                            <i class="ri-star-fill"></i>
                                            <i class="ri-star-fill"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="splide__slide">
                            <div class="testimonial-card">
                                <p class="testimonial-text">From the moment I walked in, I felt pampered. The scalp massage during the wash was heavenly, and my haircut is the best I've ever had. Worth every penny!</p>
                                <div class="testimonial-author">
                                    <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="Sarah Johnson">
                                    <div class="author-info">
                                        <h4>Sarah Johnson</h4>
                                        <p>First-time Client</p>
                                        <div class="testimonial-rating">
                                            <i class="ri-star-fill"></i>
                                            <i class="ri-star-fill"></i>
                                            <i class="ri-star-fill"></i>
                                            <i class="ri-star-fill"></i>
                                            <i class="ri-star-half-fill"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="section contact" id="contact">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <p class="subtitle">Contact Us</p>
                <h2>Get In Touch</h2>
                <p>We'd love to hear from you. Book your appointment or ask us any questions.</p>
            </div>
            
            <div class="contact-info">
                <div class="contact-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="contact-icon">
                        <i class="ri-map-pin-line"></i>
                    </div>
                    <h3>Our Location</h3>
                    <p>Near Russel Chowk, behind Maruti Hotel</p>
                    <p>Napier Town, Jabalpur</p>
                    <p>Madhya Pradesh, 482001</p>
                    <a href="https://maps.google.com" target="_blank" class="btn btn-outline" style="margin-top: 15px;">
                        <i class="ri-map-2-line"></i> View on Map
                    </a>
                </div>
                
                <div class="contact-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="contact-icon">
                        <i class="ri-phone-line"></i>
                    </div>
                    <h3>Contact Info</h3>
                    <a href="tel:+918962689555"><i class="ri-phone-fill"></i> +91 8962689555</a>
                    <a href="mailto:infinitysalon@gmail.com"><i class="ri-mail-fill"></i> infinitysalon@gmail.com</a>
                    <div class="social-links" style="justify-content: center; margin-top: 20px;">
                        <a href="#"><i class="ri-facebook-fill"></i></a>
                        <a href="#"><i class="ri-instagram-line"></i></a>
                        <a href="#"><i class="ri-whatsapp-line"></i></a>
                    </div>
                </div>
                
                <div class="contact-card" data-aos="fade-up" data-aos-delay="300">
                    <div class="contact-icon">
                        <i class="ri-time-line"></i>
                    </div>
                    <h3>Working Hours</h3>
                    <p><i class="ri-calendar-line"></i> Mon-Fri: 10:00 AM - 9:00 PM</p>
                    <p><i class="ri-calendar-line"></i> Saturday: 10:00 AM - 7:00 PM</p>
                    <p><i class="ri-calendar-line"></i> Sunday: Closed</p>
                    <?php if (isset($_SESSION['user'])): ?>
                    <a href="book-appointment.php" class="btn btn-primary">
                        <i class="ri-calendar-line"></i> Book Appointment
                    </a>
                    <?php else: ?>
                    <a href="login.php"><i class="btn btn-primary">Login for Book Now</i> </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            
            
            <div class="footer-bottom">
                <p>&copy; 2025 Infinity Salon. All Rights Reserved. Designed with <i class="ri-heart-fill" style="color: var(--primary);"></i> by Infinity Team</p>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <a href="#" class="back-to-top" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </a>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
            <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        // Initialize AOS animation
        AOS.init({
            duration: 800,
            easing: 'ease-in-out',
            once: true
        });
        
        // Initialize Splide sliders
        document.addEventListener('DOMContentLoaded', function() {
            // Gallery slider
            new Splide('.gallery-slider', {
                type: 'loop',
                perPage: 3,
                gap: '30px',
                pagination: false,
                breakpoints: {
                    992: {
                        perPage: 2
                    },
                    768: {
                        perPage: 1
                    }
                }
            }).mount();
            
            // Testimonials slider
            new Splide('.testimonial-slider', {
                type: 'loop',
                perPage: 1,
                gap: '30px',
                arrows: false,
                autoplay: true,
                interval: 5000,
                pauseOnHover: false
            }).mount();
        });
        
        // Mobile menu toggle
        const menuToggle = document.getElementById('menu-toggle');
        const navMenu = document.getElementById('nav-menu');
        
        menuToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            menuToggle.innerHTML = navMenu.classList.contains('active') ? 
                '<i class="ri-close-line"></i>' : '<i class="ri-menu-line"></i>';
        });
        
        // Close mobile menu when clicking on a link
        const navLinks = document.querySelectorAll('.nav-menu a');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('active');
                menuToggle.innerHTML = '<i class="ri-menu-line"></i>';
            });
        });
        
        // Header scroll effect and back-to-top button
        window.addEventListener('scroll', function() {
            const header = document.getElementById('header');
            const backToTop = document.getElementById('back-to-top');
            
            if (window.scrollY > 100) {
                header.classList.add('scrolled');
                backToTop.classList.add('active');
            } else {
                header.classList.remove('scrolled');
                backToTop.classList.remove('active');
            }
        });
        
        // Back to top button functionality
        const backToTopBtn = document.getElementById('back-to-top');
        backToTopBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
        
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                // Skip if it's the back-to-top button
                if (this.id === 'back-to-top') return;
                
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });
    </script>
</body>
</html>