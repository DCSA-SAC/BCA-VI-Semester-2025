<?php
include 'db.php';
include 'functions.php';

$errors = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitizeInput($_POST['username']);
    $password = $_POST['password'];
    $confirm  = $_POST['confirm'];

    if ($password !== $confirm) {
        $errors = "Passwords do not match!";
    } else {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $hash);

        if ($stmt->execute()) {
            header("Location: login.php?msg=registered");
            exit();
        } else {
            $errors = "Username already exists!";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

    <!-- ✅ Internal CSS (same as login) -->
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
            font-family: 'Segoe UI', sans-serif;
            color: #fff;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }
        .form-box {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
            width: 100%;
            max-width: 400px;
            transition: 0.3s ease-in-out;
        }
        .form-box:hover {
            box-shadow: 0 0 30px rgba(0, 255, 204, 0.25);
        }
        .form-box h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #00ffd5;
            font-weight: 700;
            font-size: 28px;
            text-shadow: 0 0 10px rgba(0, 255, 204, 0.3);
        }
        input.form-control {
            margin-top: 15px;
            background-color: rgba(255, 255, 255, 0.08);
            border: none;
            border-radius: 12px;
            color: #fff;
            padding: 12px 15px;
            box-shadow: inset 0 0 5px rgba(0, 255, 204, 0.1);
            transition: 0.3s ease;
        }
        input.form-control::placeholder {
            color: #ccc;
            opacity: 0.6;
        }
        input.form-control:focus {
            background-color: rgba(255, 255, 255, 0.12);
            border: 1px solid #00ffd5;
            outline: none;
        }
        button[type="submit"] {
            margin-top: 20px;
            background: linear-gradient(135deg, #00ffd5, #00bfa6);
            border: none;
            padding: 12px;
            color: #000;
            font-weight: bold;
            border-radius: 12px;
            width: 100%;
            cursor: pointer;
            transition: 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 255, 204, 0.3);
        }
        button[type="submit"]:hover {
            background: linear-gradient(135deg, #00bfa6, #009e86);
            color: #fff;
        }
        p a {
            color: #00ffd5;
            text-decoration: none;
            font-weight: 500;
            transition: 0.2s ease-in-out;
        }
        p a:hover {
            text-decoration: underline;
            color: #00c2a8;
        }
        .alert {
            margin-bottom: 15px;
            border-radius: 10px;
            font-size: 14px;
            padding: 10px;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="form-box">
    <h2>Register</h2>
    <?php if ($errors): ?>
        <div class="alert alert-danger"><?= $errors ?></div>
    <?php endif; ?>
    <form method="POST">
        <input class="form-control" type="text" name="username" placeholder="Username" required>
        <input class="form-control" type="password" name="password" placeholder="Password" required>
        <input class="form-control" type="password" name="confirm" placeholder="Confirm Password" required>
        <button type="submit">Register</button>
        <p class="mt-3"><a href="login.php">Already registered?</a></p>
    </form>
</div>

</body>
</html>
