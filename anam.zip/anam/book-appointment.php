<?php
// Configuration
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'db.php';

// Initialize variables
$message = '';
$message_type = '';
$appointments = [];

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        if (isset($_POST['book'])) {
            handleBooking($conn);
        } elseif (isset($_POST['cancel'])) {
            handleCancellation($conn);
        }
    } catch (Exception $e) {
        $message = $e->getMessage();
        $message_type = "error";
    }
}

// Fetch all appointments
$appointments = fetchAppointments($conn);
$conn->close();

// Function to handle appointment booking
function handleBooking($conn) {
    global $message, $message_type;
    
    // Validate all required fields
    $required = ['name', 'contact', 'email', 'date', 'time', 'service'];
    $missing = array_diff($required, array_keys($_POST));
    
    if (!empty($missing)) {
        throw new Exception("Missing required fields: " . implode(', ', $missing));
    }
    
    // Sanitize inputs
    $name = trim($_POST['name']);
    $contact = trim($_POST['contact']);
    $email = trim($_POST['email']);
    $service = trim($_POST['service']);
    $date = trim($_POST['date']);
    $time = trim($_POST['time']);
    $notes = trim($_POST['notes'] ?? '');
    
    // Validate inputs
    if (empty($name) || empty($contact) || empty($email) || empty($date) || empty($time) || empty($service)) {
        throw new Exception("All fields are required!");
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Invalid email address format");
    }

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO appointments (name, contact, email, service, date, time, notes) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $name, $contact, $email, $service, $date, $time, $notes);
    
    if ($stmt->execute()) {
        $message = "🎉 Appointment booked successfully!";
        $message_type = "success";
    } else {
        throw new Exception("Database error: " . $stmt->error);
    }
    $stmt->close();
}

// Function to handle appointment cancellation
function handleCancellation($conn) {
    global $message, $message_type;
    
    if (empty($_POST['id'])) {
        throw new Exception("No appointment ID provided for cancellation");
    }
    
    $stmt = $conn->prepare("DELETE FROM appointments WHERE id = ?");
    $stmt->bind_param("i", $_POST['id']);
    if ($stmt->execute()) {
        $message = "Appointment cancelled successfully";
        $message_type = "success";
    } else {
        throw new Exception("Failed to cancel appointment: " . $stmt->error);
    }
    $stmt->close();
}

// Function to fetch all appointments
function fetchAppointments($conn) {
    $appointments = [];
    $result = $conn->query("SELECT * FROM appointments ORDER BY date, time");
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $appointments[] = $row;
        }
    }
    
    return $appointments;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Infinity Salon | Book Your Beauty Experience</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary: #8a63ff;
            --primary-light: #b18aff;
            --secondary: #00d2d3;
            --accent: #ff7675;
            --dark: #121212;
            --light: #f5f5f5;
            --glass: rgba(255, 255, 255, 0.7);
            --shadow: 0 8px 32px rgba(31, 38, 135, 0.15);
            --border: 1px solid rgba(255, 255, 255, 0.3);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            color: var(--dark);
            line-height: 1.6;
            padding: 0;
            margin: 0;
            min-height: 100vh;
        }

        .header {
            background: linear-gradient(to right, var(--primary), var(--secondary));
            color: white;
            text-align: center;
            padding: 2rem 1rem;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
        }

        .header h1 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
            letter-spacing: 1px;
        }

        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
            display: grid;
            grid-template-columns: 1fr;
            gap: 2rem;
        }

        @media (min-width: 992px) {
            .container {
                grid-template-columns: 1fr 1fr;
            }
        }

        .card {
            background: var(--glass);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: var(--shadow);
            border: var(--border);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(31, 38, 135, 0.2);
        }

        .card h2 {
            font-family: 'Playfair Display', serif;
            color: var(--primary);
            margin-bottom: 1.5rem;
            font-size: 1.8rem;
            position: relative;
            padding-bottom: 0.5rem;
        }

        .card h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60px;
            height: 3px;
            background: var(--accent);
            border-radius: 3px;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--dark);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 0.8rem 1rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.8);
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(138, 99, 255, 0.2);
        }

        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }

        .btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 100%;
        }

        .btn:hover {
            background: var(--primary-light);
            transform: translateY(-2px);
        }

        .btn i {
            margin-right: 0.5rem;
        }

        .appointment-list {
            margin-top: 1rem;
        }

        .empty-state {
            text-align: center;
            padding: 2rem;
            color: rgba(0, 0, 0, 0.5);
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--primary-light);
        }

        .empty-state h3 {
            font-family: 'Playfair Display', serif;
            margin-bottom: 0.5rem;
            color: var(--dark);
        }

        .appointment-item {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            border-left: 4px solid var(--primary);
            opacity: 0;
            animation: fadeIn 0.5s forwards;
        }

        @keyframes fadeIn {
            to { opacity: 1; }
        }

        .appointment-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .appointment-title {
            font-weight: 600;
            color: var(--dark);
            font-size: 1.1rem;
        }

        .appointment-date {
            background: var(--primary-light);
            color: white;
            padding: 0.3rem 0.6rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        .appointment-details {
            margin-bottom: 1rem;
        }

        .appointment-service {
            display: flex;
            align-items: center;
            margin-bottom: 0.5rem;
            color: var(--dark);
        }

        .service-icon {
            color: var(--accent);
            margin-right: 0.5rem;
        }

        .appointment-notes {
            color: rgba(0, 0, 0, 0.7);
            font-size: 0.9rem;
            display: flex;
            align-items: flex-start;
        }

        .appointment-notes i {
            color: var(--secondary);
            margin-right: 0.5rem;
            margin-top: 0.2rem;
        }

        .cancel-btn {
            background: none;
            border: 1px solid var(--accent);
            color: var(--accent);
            padding: 0.5rem 1rem;
            border-radius: 6px;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
        }

        .cancel-btn:hover {
            background: var(--accent);
            color: white;
        }

        footer {
            text-align: center;
            padding: 2rem 1rem;
            margin-top: 3rem;
            color: rgba(0, 0, 0, 0.6);
            font-size: 0.9rem;
        }

        .fade-in {
            opacity: 0;
            animation: fadeIn 0.5s forwards;
        }

        .delay-1 {
            animation-delay: 0.2s;
        }

        .delay-2 {
            animation-delay: 0.4s;
        }

        .delay-3 {
            animation-delay: 0.6s;
        }
    </style>
</head>
<body>
    <header class="header">
        <h1>Infinity Salon</h1>
        <p>Book your personalized beauty experience with our expert stylists</p>
    </header>

    <div class="container">
        <div class="card fade-in">
            <h2>Book Your Appointment</h2>
            <form method="post">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" name="name" id="name" placeholder="Your name" required>
                </div>
                
                <div class="form-group">
                    <label for="contact">Contact Number</label>
                    <input type="tel" name="contact" id="contact" placeholder="Your phone number" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" name="email" id="email" placeholder="Your email" required>
                </div>
                
                <div class="form-group">
                    <label for="service">Service</label>
                    <select name="service" id="service" required>
                        <option value="">Select a service</option>
                        <option value="Haircut & Styling">Haircut & Styling</option>
                        <option value="Hair Coloring">Hair Coloring</option>
                        <option value="Hair Treatment">Hair Treatment</option>
                        <option value="Makeup">Makeup Service</option>
                        <option value="Manicure/Pedicure">Manicure/Pedicure</option>
                        <option value="Spa Package">Spa Package</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="date">Appointment Date</label>
                    <input type="date" name="date" id="date" min="<?php echo date('Y-m-d'); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="time">Appointment Time</label>
                    <input type="time" name="time" id="time" min="09:00" max="18:00" required>
                </div>
                
                <div class="form-group">
                    <label for="notes">Special Requests</label>
                    <textarea name="notes" id="notes" placeholder="Any special requests or notes..."></textarea>
                </div>
                
                <button type="submit" name="book" class="btn">
                    <i class="fas fa-calendar-check"></i> Book Appointment
                </button>
            </form>
        </div>

        <div class="card fade-in delay-1">
            <h2>Your Appointments</h2>
            <div class="appointment-list">
                <?php if (empty($appointments)): ?>
                    <div class="empty-state">
                        <i class="far fa-calendar-check"></i>
                        <h3>No Appointments Yet</h3>
                        <p>Book your first appointment to get started!</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($appointments as $appt): ?>
                        <div class="appointment-item">
                            <div class="appointment-header">
                                <span class="appointment-title"><?php echo htmlspecialchars($appt['name'] ?? ''); ?></span>
                                <span class="appointment-date">
                                    <?php echo date('M j, Y', strtotime($appt['date'])); ?> at 
                                    <?php echo date('g:i A', strtotime($appt['time'])); ?>
                                </span>
                            </div>
                            <div class="appointment-details">
                                <span class="appointment-service">
                                    <i class="fas fa-spa service-icon"></i>
                                    <?php echo htmlspecialchars($appt['service'] ?? 'Not specified'); ?>
                                </span>
                                <?php if (!empty($appt['notes'])): ?>
                                    <p class="appointment-notes">
                                        <i class="fas fa-comment-dots"></i> 
                                        <?php echo htmlspecialchars($appt['notes']); ?>
                                    </p>
                                <?php endif; ?>
                            </div>
                            <form method="post" onsubmit="return confirm('Are you sure you want to cancel this appointment?');">
                                <input type="hidden" name="id" value="<?php echo $appt['id']; ?>">
                                <button type="submit" name="cancel" class="cancel-btn">
                                    <i class="fas fa-times"></i> Cancel Appointment
                                </button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <footer class="fade-in delay-3">
        <p>&copy; <?php echo date('Y'); ?> Infinity Salon. All rights reserved.</p>
    </footer>

    <?php if ($message): ?>
    <script>
        Swal.fire({
            title: '<?php echo $message_type === "success" ? "Success!" : "Oops..."; ?>',
            text: '<?php echo addslashes($message); ?>',
            icon: '<?php echo $message_type === "success" ? "success" : "error"; ?>',
            confirmButtonColor: 'var(--primary)',
            timer: 3000,
            timerProgressBar: true,
            toast: true,
            position: 'top-end',
            showConfirmButton: false
        });
    </script>
    <?php endif; ?>

    <script>
        // Set minimum time for date input to today
        document.getElementById('date').min = new Date().toISOString().split('T')[0];
        
        // Add animation to appointment items
        document.querySelectorAll('.appointment-item').forEach((item, index) => {
            item.style.animationDelay = `${0.2 + (index * 0.1)}s`;
        });
    </script>
</body>
</html>