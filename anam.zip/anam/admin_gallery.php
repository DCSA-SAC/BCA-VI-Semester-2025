<?php
session_start();
include 'db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit;
}

// Fetch gallery images from the database
$query = "SELECT * FROM gallery ORDER BY id DESC";
$result = $conn->query($query);

// Handle edit form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_image'])) {
    $id = intval($_POST['id']);
    $title = $conn->real_escape_string($_POST['title']);
    
    // Handle file upload if a new image was provided
    if (!empty($_FILES['image']['name'])) {
        // Delete old image
        $oldImageQuery = $conn->query("SELECT image_path FROM gallery WHERE id = $id");
        $oldImage = $oldImageQuery->fetch_assoc();
        if (file_exists($oldImage['image_path'])) {
            unlink($oldImage['image_path']);
        }
        
        // Upload new image
        $target_dir = "uploads/gallery/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $file_name = basename($_FILES["image"]["name"]);
        $target_file = $target_dir . uniqid() . "_" . $file_name;
        
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $conn->query("UPDATE gallery SET title = '$title', image_path = '$target_file' WHERE id = $id");
            $_SESSION['message'] = "Image updated successfully!";
        } else {
            $_SESSION['error'] = "Sorry, there was an error uploading your file.";
        }
    } else {
        // Just update the title if no new image
        $conn->query("UPDATE gallery SET title = '$title' WHERE id = $id");
        $_SESSION['message'] = "Image title updated successfully!";
    }
    
    header("Location: admin_gallery.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Gallery | Infinity Salon</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #d4a373;
            --primary-dark: #b58a5e;
            --secondary: #fefae0;
            --dark: #333;
            --light: #f8f9fa;
            --light-gray: #e9ecef;
            --white: #ffffff;
            --error: #e63946;
            --success: #2a9d8f;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --border-radius: 8px;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: var(--light-gray);
            color: var(--dark);
            line-height: 1.6;
        }

        .admin-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        h2 {
            font-size: 2rem;
            color: var(--dark);
            font-weight: 600;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.8rem 1.5rem;
            background: var(--primary);
            color: var(--white);
            border: none;
            border-radius: var(--border-radius);
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
            box-shadow: var(--shadow);
            cursor: pointer;
        }

        .btn:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(212, 163, 115, 0.3);
        }

        .btn i {
            font-size: 1rem;
        }

        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }

        .gallery-card {
            background: var(--white);
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: var(--transition);
            position: relative;
        }

        .gallery-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }

        .gallery-img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            display: block;
        }

        .gallery-title {
            padding: 0.8rem;
            font-size: 0.9rem;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .gallery-actions {
            position: absolute;
            top: 0.5rem;
            right: 0.5rem;
            display: flex;
            gap: 0.5rem;
        }

        .action-btn {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 255, 255, 0.9);
            color: var(--dark);
            border: none;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: var(--shadow);
        }

        .action-btn:hover {
            background: var(--white);
            transform: scale(1.1);
        }

        .action-btn.delete {
            color: var(--error);
        }

        .action-btn.edit {
            color: var(--success);
        }

        .empty-state {
            text-align: center;
            padding: 3rem;
            background: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            grid-column: 1 / -1;
        }

        .empty-state i {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }

        .empty-state p {
            color: var(--dark);
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: var(--white);
            border-radius: var(--border-radius);
            width: 90%;
            max-width: 500px;
            padding: 2rem;
            position: relative;
            animation: modalFadeIn 0.3s ease-out;
        }

        @keyframes modalFadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .close-modal {
            position: absolute;
            top: 1rem;
            right: 1rem;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--dark);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 1rem;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(212, 163, 115, 0.2);
        }

        .preview-image {
            max-width: 100%;
            height: 150px;
            object-fit: contain;
            margin-bottom: 1rem;
            border-radius: var(--border-radius);
            border: 1px solid #eee;
            display: block;
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 1rem;
            margin-top: 2rem;
        }

        .btn-secondary {
            background: var(--light-gray);
            color: var(--dark);
        }

        .btn-danger {
            background: var(--error);
            color: white;
        }

        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: var(--border-radius);
        }

        .alert-success {
            background: rgba(42, 157, 143, 0.1);
            color: var(--success);
            border: 1px solid rgba(42, 157, 143, 0.3);
        }

        .alert-error {
            background: rgba(230, 57, 70, 0.1);
            color: var(--error);
            border: 1px solid rgba(230, 57, 70, 0.3);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .gallery-grid {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            }
        }

        @media (max-width: 480px) {
            .admin-container {
                padding: 1.5rem;
            }
            
            h2 {
                font-size: 1.5rem;
            }
            
            .gallery-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="header">
            <h2><i class="fas fa-images"></i> Gallery Management</h2>
            <a href="add_image.php" class="btn">
                <i class="fas fa-plus"></i> Add New Image
            </a>
        </div>

        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $_SESSION['message']; ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <?php if ($result->num_rows > 0): ?>
            <div class="gallery-grid">
                <?php while ($image = $result->fetch_assoc()): ?>
                    <div class="gallery-card">
                        <img src="<?php echo htmlspecialchars($image['image_path']); ?>" alt="Gallery Image" class="gallery-img">
                        <div class="gallery-title"><?php echo htmlspecialchars($image['title'] ?? 'Untitled'); ?></div>
                        <div class="gallery-actions">
                            <button class="action-btn edit" onclick="openEditModal(<?php echo $image['id']; ?>, '<?php echo htmlspecialchars($image['title'] ?? ''); ?>', '<?php echo htmlspecialchars($image['image_path']); ?>')">
                                <i class="fas fa-pencil-alt"></i>
                            </button>
                            <button class="action-btn delete" onclick="confirmDelete(<?php echo $image['id']; ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-image"></i>
                <h3>No Images Found</h3>
                <p>Your gallery is currently empty. Add some beautiful images to showcase your work!</p>
                <a href="add_image.php" class="btn">
                    <i class="fas fa-plus"></i> Add Your First Image
                </a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal()">&times;</span>
            <h3>Confirm Deletion</h3>
            <p>Are you sure you want to delete this image? This action cannot be undone.</p>
            <div class="modal-footer">
                <button onclick="closeModal()" class="btn btn-secondary">Cancel</button>
                <button id="confirmDeleteBtn" class="btn btn-danger">Delete</button>
            </div>
        </div>
    </div>

    <!-- Edit Image Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal()">&times;</span>
            <h3>Edit Image</h3>
            <form id="editForm" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id" id="editImageId">
                <input type="hidden" name="update_image" value="1">
                
                <div class="form-group">
                    <label for="editTitle">Image Title</label>
                    <input type="text" id="editTitle" name="title" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="editImage">Current Image</label>
                    <img src="" id="currentImagePreview" class="preview-image">
                </div>
                
                <div class="form-group">
                    <label for="editImageFile">Change Image (optional)</label>
                    <input type="file" id="editImageFile" name="image" class="form-control" accept="image/*">
                    <small>Leave blank to keep current image</small>
                </div>
                
                <div class="modal-footer">
                    <button type="button" onclick="closeModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        let currentImageId = null;
        
        // Delete functionality
        function confirmDelete(imageId) {
            currentImageId = imageId;
            document.getElementById('deleteModal').style.display = 'flex';
        }
        
        document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
            if (currentImageId) {
                window.location.href = `delete_image.php?id=${currentImageId}`;
            }
        });
        
        // Edit functionality
        function openEditModal(id, title, imagePath) {
            currentImageId = id;
            document.getElementById('editImageId').value = id;
            document.getElementById('editTitle').value = title;
            document.getElementById('currentImagePreview').src = imagePath;
            document.getElementById('editModal').style.display = 'flex';
        }
        
        // Preview new image when selected
        document.getElementById('editImageFile').addEventListener('change', function(e) {
            if (e.target.files.length > 0) {
                const file = e.target.files[0];
                const reader = new FileReader();
                
                reader.onload = function(event) {
                    document.getElementById('currentImagePreview').src = event.target.result;
                }
                
                reader.readAsDataURL(file);
            }
        });
        
        // Close modal
        function closeModal() {
            document.getElementById('deleteModal').style.display = 'none';
            document.getElementById('editModal').style.display = 'none';
            currentImageId = null;
        }
        
        // Close modal when clicking outside
        window.addEventListener('click', function(event) {
            if (event.target.classList.contains('modal')) {
                closeModal();
            }
        });
    </script>
</body>
</html>