from django.shortcuts import render,redirect
from .models import Home, Events, Gallery
from .models import Gallery
from .forms import GalleryForm
from .forms import EventsForm  # You need to create this form
from .models import ContactMessage
from django.contrib import messages

def home_view(request):
    obj = Home.objects.all()
    return render(request, 'Home.html', {'obj': obj})

# def gallery_views(request):
#     obj = Gallery.objects.all()
#     context = {'obj': obj}  # Ensure this is a dictionary
#     return render(request, 'Gallery.html', context)  # Pass the dictionary properly


def gallery_views(request):
    if request.method == 'POST':
        form = GalleryForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('gallery')  # Replace with your URL name
    elif 'delete_id' in request.GET:
        Gallery.objects.filter(id=request.GET.get('delete_id')).delete()
        return redirect('gallery')

    obj = Gallery.objects.all()
    form = GalleryForm()
    context = {
        'obj': obj,
        'form': form,
    }
    return render(request, 'Gallery.html', context)

def vedios_views(request):
    return render(request, 'Videos.html')


def events_view(request):
    if request.method == 'POST':
        form = EventsForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('events')  # replace with your URL name
    else:
        form = EventsForm()

    # Delete by query param
    delete_id = request.GET.get('delete_id')
    if delete_id:
        Events.objects.filter(id=delete_id).delete()
        return redirect('events')

    obj = Events.objects.all()
    return render(request, 'Events.html', {'obj': obj, 'form': form})

def contact_views(request):
    return render(request,'contact.html')

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .forms import LoginForm


def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')  # Or your dashboard page

    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')

            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')  # Change this to your home/dashboard
            else:
                messages.error(request, "Invalid username or password.")
    else:
        form = LoginForm()

    return render(request, 'login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home')
def contact_page(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        message = request.POST.get('message')

        # Save to the database
        ContactMessage.objects.create(
            name=name,
            email=email,
            phone=phone,
            message=message
        )
        messages.success(request, "Your message has been sent!")
        return redirect('contact')  # use your URL name here

    return render(request, 'contact.html')