from django.contrib import admin

# Register your models here.
from .models import Home,Gallery,Event
from .models import ContactMessage

admin.site.register(ContactMessage)
admin.site.register(Home)
admin.site.register(Gallery)
admin.site.register(Event)
# admin.site.register(Home)