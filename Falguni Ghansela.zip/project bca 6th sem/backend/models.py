from django.db import models

# Create your models here.
class Home(models.Model):
    image = models.ImageField(upload_to='home')
    name = models.CharField(max_length=100,null=True)
    role = models.CharField(max_length=100,null=True)
    create_at = models.DateField(auto_now_add=True)
    
    
class Gallery(models.Model):
    image = models.ImageField(upload_to='gallery')
    create_at = models.DateField(auto_now_add=True)
        
class Events(models.Model):
    date = models.TextField(max_length=100)
    eventName = models.TextField(max_length=100)
    place = models.TextField(max_length=100)
    create_at = models.DateField(auto_now_add=True)
    
class Event(models.Model):
    date = models.CharField(max_length=100)
    eventName = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    create_at = models.DateField(auto_now_add=True)
            
class ContactMessage(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    message = models.TextField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.email}"           
 