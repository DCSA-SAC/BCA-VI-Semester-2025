from django import forms
from .models import Gallery,Events

class GalleryForm(forms.ModelForm):
    class Meta:
        model = Gallery
        fields = ['image']
        
class EventsForm(forms.ModelForm):
    class Meta:
        model = Events
        fields = ['date', 'eventName', 'place']
        widgets = {
            'date': forms.TextInput(attrs={'placeholder': 'Date'}),
            'eventName': forms.TextInput(attrs={'placeholder': 'Event Name'}),
            'place': forms.TextInput(attrs={'placeholder': 'Place'}),
        }
        
        
class LoginForm(forms.Form):
    username = forms.CharField(max_length=150, widget=forms.TextInput(attrs={
        'placeholder': 'Username'
    }))
    password = forms.CharField(widget=forms.PasswordInput(attrs={
        'placeholder': 'Password'
    }))        