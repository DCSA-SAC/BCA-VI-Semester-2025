import nodemailer from "nodemailer";
import dotenv from "dotenv";

dotenv.config();

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

/**
 * @param {string} email 
 * @param {string} subject 
 * @param {string} text 
 * @param {string} html 
 */
const sendEmail = async (email, subject, text, html = "") => {
  try {
    const mailOptions = {
      from: `"Chaubey Study Zone" <${process.env.EMAIL_USER}>`, 
      to: email,
      subject: subject,
      text: text,
      html: html || `<p>${text}</p>`,
    };

    await transporter.sendMail(mailOptions);
    console.log(`✅ Email sent successfully to ${email}`);
  } catch (error) {
    console.error("❌ Email Not Sent", error);
    throw new Error("Failed to send email. Please try again later.");
  }
};

export default sendEmail;
