<?php
	$con=mysqli_connect("localhost","root","","classic_events")or die("can't connect");
	//mysql_select_db("classic_events")or die ("can't select db");
?>