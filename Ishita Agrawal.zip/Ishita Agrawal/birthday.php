<?php
	include_once("header.php");
?>
	<!-- //header -->
	<div class="banner about-bnr">
		<div class="container">
		</div>
	</div>
	<!-- about -->
	<div class="about">
		<div class="container">
			<h3 class="w3ls-title1"><span>BIRTH</span>DAY</h3>
			<div class="about-agileinfo w3layouts">
				<div class="col-md-8 about-wthree-grids grid-top">
					<h4>Birthday party is one the first thing everyone of us have ever remembered in their memories </h4>
					<p class="top">Classic Events Have the perfect innovative team, who can come up with unique theme. Whoever's birthday party it may be a child or it may be elder's birthday party. We have a range of theme party of childrens.</p>
					<p>Birthday party now a days become so important in everybody's life so the trends of rejoicing beautiful moments have become very close to hearts of people. Everyone wants to celebrate the birthday with little happiness to create beautiful and happier memories for lifetime. People living in busy life in metropolitans is always engaged in the finding excellent ways to enjoy a lot. The city like our Rajkot is also now on their track to enjoy birthday party and theme party. </p>		
					<div class="about-w3agilerow">
						<div class="col-md-4 about-w3imgs">
							<img src="images/cs_birthday2.jpg" alt="" class="img-responsive zoom-img"/>
						</div>
						<div class="col-md-4 about-w3imgs">
							<img src="images/cs_birthday4.jpg" alt=""  class="img-responsive zoom-img"/>
						</div>
						<div class="col-md-4 about-w3imgs">
							<img src="images/cs_birthday5.jpg" alt=""  class="img-responsive zoom-img"/>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
				<?php 
					include_once("sidebar.php");
				?>
				</div>	
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //about -->
	<!-- about-slid -->
	<div class="about-slid agileits-w3layouts"> 
		<div class="container">
			<div class="about-slid-info"> 
				<h2>We can change the entire feel of a party and make it excellent and perfect forever.</h2>
				<p>There are countless options to be taken into account in terms of party theme planning, decoration as per that and perfect management of the entire event. These things collectively prepare such a birthday celebration, which can be cherished forever.</p>
			</div>
		</div>
	</div>
	<!-- //about-slid -->
	<!-- about-services -->
	<br/><br />
	<div class="about-servcs"> 
		<div class="container">
			<h3 CLASS="w3ls-title1">We Specialize In </h3>
			<h5>We provide a wide range of services </h5>
			<div class="servcs-info">
				<div class="col-md-6 sevcs-grids">
					<h4><span>01.</span> BIRTHDAY PARTIES</h4>
					<p>Celebrate like never before with Classic Events making the birthday party cheerful, frantic function. We take care of everything i.e. decoration, cakes, balloon bouuqutes, DJ, live entertainment, bands, magicians, dance troops, fun, games, photography/video, lighting, stage show, fireworks and so on.</p>			
				</div>
				<div class="col-md-6 sevcs-grids"> 
					<h4><span>02.</span> THEME PARTY</h4>
					<p>Celebrate your happy moods with Classic Events. Top-notch theme parties can be organized within your budget and location. You can make them happen.</p>			
				</div>
				<div class="clearfix"> </div>
			</div>
			
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //about-services -->
	<!-- footer -->
	<?php
		include_once("footer.php");
	?>