import * as mongooseAdmin from '@adminjs/mongoose';
console.log(mongooseAdmin);