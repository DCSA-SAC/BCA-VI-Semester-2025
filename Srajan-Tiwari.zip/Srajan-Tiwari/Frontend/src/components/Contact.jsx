import { useState } from "react";
import "./Contact.css"; // Import the CSS file
import profilePic from "./profile.jpeg"; // Uncomment if using a profile picture

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:5000/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await response.json();
      alert(data.message);
      setFormData({ name: "", email: "", phone: "", message: "" });
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to send message");
    }
  };

  return (
    <div className="contact-container">
      {/* Left Section - Contact Details */}
      <div className="contact-details">
      <img src={profilePic} alt="Profile" className="contact-image" loading="lazy" />

        <h2 className="contact-title">Contact Information</h2>
        <p className="contact-text"><strong>Address:</strong> Sadar, Jabalpur, Madhya Pradesh 482001</p>
        <p className="contact-text"><strong>Email:</strong> bismi@gmail.com</p>
        <p className="contact-text"><strong>Phone:</strong> 098469 23905</p>
      </div>

      {/* Right Section - Contact Form */}
      <div className="contact-form-container">
        <h2 className="contact-title">Send a Message</h2>
        <form onSubmit={handleSubmit} className="contact-form">
          <input
            type="text"
            name="name"
            placeholder="Your Name"
            value={formData.name}
            onChange={handleChange}
            className="contact-input"
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Your Email"
            value={formData.email}
            onChange={handleChange}
            className="contact-input"
          />
          <input
            type="tel"
            name="phone"
            placeholder="Your Phone Number"
            value={formData.phone}
            onChange={handleChange}
            className="contact-input"
          />
          <textarea
            name="message"
            placeholder="Your Message"
            value={formData.message}
            onChange={handleChange}
            className="contact-textarea"
            required
          ></textarea>
          <button type="submit" className="contact-button">Send Message</button>
        </form>
      </div>
    </div>
  );
};

export default Contact;
