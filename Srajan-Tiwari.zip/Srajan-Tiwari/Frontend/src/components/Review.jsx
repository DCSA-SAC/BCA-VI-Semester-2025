import React, { useState } from "react";
import "./Review.css";

const Review = () => {
  const [reviews, setReviews] = useState([
    {
      name: "John Doe",
      rating: 5,
      comment: "The food was amazing! Will definitely come again.",
    },
    {
      name: "Jane Smith",
      rating: 4,
      comment: "Great ambiance and tasty food, but a bit slow service.",
    },
    {
      name: "Sam Wilson",
      rating: 5,
      comment: "Absolutely loved the experience. Highly recommend!",
    },
  ]);

  const [newReview, setNewReview] = useState({
    name: "",
    rating: "",
    comment: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewReview({ ...newReview, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (newReview.name && newReview.rating && newReview.comment) {
      setReviews([newReview, ...reviews]); // Add new review to the top
      setNewReview({ name: "", rating: "", comment: "" }); // Reset form
    }
  };

  return (
    <div className="reviews-section">
      <h2>Customer Reviews</h2>

      {/* Review Submission Form */}
      <form className="review-form" onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Your Name"
          value={newReview.name}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="rating"
          placeholder="Rating (1-5)"
          min="1"
          max="5"
          value={newReview.rating}
          onChange={handleChange}
          required
        />
        <textarea
          name="comment"
          placeholder="Your Review"
          value={newReview.comment}
          onChange={handleChange}
          required
        ></textarea>
        <button type="submit">Submit Review</button>
      </form>

      {/* Reviews List */}
      <div className="reviews-list">
        {reviews.length > 0 ? (
          reviews.map((review, index) => (
            <div key={index} className="review-card">
              <h3>{review.name}</h3>
              <p>Rating: {review.rating} / 5</p>
              <p>{review.comment}</p>
            </div>
          ))
        ) : (
          <p>No reviews available.</p>
        )}
      </div>
    </div>
  );
};

export default Review;

