const API_BASE_URL = "http://localhost:5000"; // Or use env var if using a bundler

const form = document.getElementById("booking-form");
const errorMessage = document.getElementById("error-message");
const confirmation = document.getElementById("confirmation");

// Converts AM/PM format to 24-hour format (if needed)
function convertTo24HourFormat(time) {
  if (/^([01]\d|2[0-3]):([0-5]\d)$/.test(time)) {
    return `${time}:00`;
  }

  const [hours, minutes] = time.split(":");
  const [minutePart, period] = minutes.split(" ");
  let hour = parseInt(hours, 10);

  if (period === "PM" && hour !== 12) hour += 12;
  if (period === "AM" && hour === 12) hour = 0;

  return `${String(hour).padStart(2, "0")}:${minutePart.padStart(2, "0")}:00`;
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const name = document.getElementById("name").value;
  const selectedDate = document.getElementById("date").value;
  const selectedTime = document.getElementById("time").value;
  const guestCount = document.getElementById("guests").value;
  const phoneNumber = document.getElementById("phone").value;

  const today = new Date().toISOString().split("T")[0];
  if (selectedDate < today) {
    errorMessage.textContent = "Please choose a valid date.";
    return;
  }

  errorMessage.textContent = "";

  const timeIn24HourFormat = convertTo24HourFormat(selectedTime);
  const generatedBookingId = `BOOK-${Date.now()}`;
  

  const bookingData = {
    bookingId: generatedBookingId,
    name,
    selectedDate,
    selectedTime: timeIn24HourFormat,
    guestCount,
    phoneNumber,
  };

  try {
    const response = await fetch(`${API_BASE_URL}/api/customer-bookings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(bookingData),
    });

    const result = await response.json();

    if (response.ok) {
      confirmation.textContent = `Booking confirmed for ${guestCount} guests on ${selectedDate} at ${selectedTime}. Your booking ID is: ${generatedBookingId}`;
      form.reset();
    } else {
      errorMessage.textContent = result.error || "Booking failed.";
    }
  } catch (err) {
    console.error("Booking error:", err);
    errorMessage.textContent = "An error occurred while saving your booking.";
  }
});
