document.addEventListener("DOMContentLoaded", () => {
  const token = localStorage.getItem("adminToken");

  const bookingTableBody = document.getElementById("bookingTableBody");
  const errorDiv = document.getElementById("errorMessage");
  const table = document.getElementById("bookingTable");
  const loading = document.getElementById("loading");
  const noBookings = document.getElementById("noBookings");

  async function fetchBookings() {
    try {
      const response = await fetch("http://localhost:5000/api/bookings", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await response.json();
      loading.style.display = "none";

      if (!response.ok) {
        throw new Error(data.message || "Failed to fetch bookings.");
      }

      if (data.length === 0) {
        noBookings.style.display = "block";
        table.style.display = "none";
        return;
      }

      table.style.display = "table";
      noBookings.style.display = "none";
      bookingTableBody.innerHTML = "";

      data.forEach((booking) => {
        const row = document.createElement("tr");
        row.innerHTML = `
        <td>${booking.name}</td>
        <td>${booking.selected_date || booking.selectedDate}</td>
        <td>${booking.selected_time || booking.selectedTime}</td>
        <td>${booking.guest_count || booking.guestCount}</td>
        <td>${booking.phone_number || booking.phoneNumber}</td>
        <td class="status-cell">
          <span class="status-text" style="display: ${booking.status === "Confirmed" ? "inline" : "none"};">
            ✅ Confirmed
          </span>
          <button class="confirm-btn" data-id="${booking.booking_id || booking.bookingId}" ${
        booking.status === "Confirmed" ? "style='display:none'" : ""
      }>Confirm</button>
        </td>
        <td>
          <button class="delete-btn" data-id="${booking.booking_id || booking.bookingId}">Delete</button>
        </td>
      `;
      
        bookingTableBody.appendChild(row);
      });
      

      document.querySelectorAll(".delete-btn").forEach((btn) => {
        btn.addEventListener("click", async (e) => {
          const bookingId = e.target.getAttribute("data-id");
          if (confirm("Are you sure you want to delete this booking?")) {
            await deleteBooking(bookingId);
          }
        });
      });

      document.querySelectorAll(".confirm-btn").forEach((btn) => {
        btn.addEventListener("click", async (e) => {
          const bookingId = e.target.getAttribute("data-id");
      
          try {
            const response = await fetch(`http://localhost:5000/api/bookings/${bookingId}/status`, {
              method: "PUT",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
              },
              body: JSON.stringify({ status: "Confirmed" }),
            });
      
            if (response.ok) {
              const statusCell = e.target.closest(".status-cell");
              const statusText = statusCell.querySelector(".status-text");
      
              // ✅ Show status and hide the button
              statusText.style.display = "inline";
              e.target.style.display = "none";
            } else {
              const data = await response.json();
              alert(data.message || "Failed to confirm booking.");
            }
          } catch (error) {
            console.error("Error confirming booking:", error);
            alert("An error occurred while confirming the booking.");
          }
        });
      });
      
      
    } catch (err) {
      console.error("Admin fetch error:", err);
      errorDiv.style.display = "block";
      errorDiv.textContent = err.message || "Error loading bookings.";
      loading.style.display = "none";
    }
  }

  async function deleteBooking(bookingId) {
    try {
      const response = await fetch(`http://localhost:5000/api/bookings/${bookingId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        fetchBookings(); // Refresh
      } else {
        const data = await response.json();
        alert(data.message || "Failed to delete booking.");
      }
    } catch (error) {
      console.error("Delete failed:", error);
      alert("Error deleting booking.");
    }
  }
  function fetchTestimonials() {
    const loading = document.getElementById("testimonialLoading");
    const table = document.getElementById("testimonialTable");
    const tbody = document.getElementById("testimonialTableBody");
    const noTestimonials = document.getElementById("noTestimonials");
  
    fetch("http://localhost:5000/api/testimonials")
      .then(res => res.json())
      .then(data => {
        loading.style.display = "none";
  
        if (data.length === 0) {
          noTestimonials.style.display = "block";
          table.style.display = "none";
          return;
        }
  
        table.style.display = "table";
        noTestimonials.style.display = "none";
  
        tbody.innerHTML = ""; // Clear previous
  
        tbody.innerHTML = ""; // Clear previous

        data.forEach(t => {
          const row = document.createElement("tr");
          row.innerHTML = `
            <td>${t.name}</td>
            <td>${t.email}</td>
            <td>${t.message}</td>
            <td>${new Date(t.created_at).toLocaleString()}</td>
            <td><button class="delete-testimonial-btn" data-id="${t.id}">Delete</button></td>
          `;
          tbody.appendChild(row);
        });
        
        // Attach delete handlers
        document.querySelectorAll(".delete-testimonial-btn").forEach(btn => {
          btn.addEventListener("click", async (e) => {
            const id = e.target.getAttribute("data-id");
            if (confirm("Are you sure you want to delete this testimonial?")) {
              try {
                const response = await fetch(`http://localhost:5000/api/testimonials/${id}`, {
                  method: "DELETE",
                  headers: {
                    Authorization: `Bearer ${token}`,
                  }
                });
        
                if (response.ok) {
                  fetchTestimonials(); // Refresh the list
                } else {
                  alert("Failed to delete testimonial.");
                }
              } catch (err) {
                console.error("Error deleting testimonial:", err);
                alert("An error occurred while deleting the testimonial.");
              }
            }
          });
        });
        
      })
      .catch(err => {
        loading.textContent = "Failed to load testimonials.";
        console.error("Fetch error:", err);
      });
  }
  

  fetchBookings();
  fetchTestimonials();
// Handle manual booking by admin
const bookingForm = document.getElementById("bookingForm");
if (bookingForm) {
  bookingForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const name = bookingForm.name.value;
    const selectedDate = bookingForm.selectedDate.value;
    const selectedTime = bookingForm.selectedTime.value;
    const guestCount = bookingForm.guestCount.value;
    const phoneNumber = bookingForm.phoneNumber.value;
    const bookingId = `BOOK-${Date.now()}`;

    const today = new Date().toISOString().split("T")[0];
  if (selectedDate < today) {
    alert("You cannot select a past date for booking.");
    return;
  }

    const bookingData = {
      bookingId,
      name,
      selectedDate,
      selectedTime,
      guestCount,
      phoneNumber,
    };

    try {
      const response = await fetch("http://localhost:5000/api/bookings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(bookingData),
      });

      const result = await response.json();

      if (response.ok) {
        alert("Booking added successfully!");
        bookingForm.reset();
        fetchBookings(); // Refresh bookings table
      } else {
        alert(result.error || "Failed to add booking.");
      }
    } catch (error) {
      console.error("Admin booking error:", error);
      alert("Error occurred while adding booking.");
    }
  });
}

  // ✅ Logout
  document.getElementById("logoutBtn").addEventListener("click", () => {
    localStorage.removeItem("adminToken");
    window.location.href = "login.html";
  });
});
