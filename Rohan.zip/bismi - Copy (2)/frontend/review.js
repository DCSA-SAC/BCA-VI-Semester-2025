const reviewsData = [
    {
      name: "John Doe",
      rating: 5,
      comment: "The food was amazing! Will definitely come again.",
    },
    {
      name: "Jane Smith",
      rating: 4,
      comment: "Great ambiance and tasty food, but a bit slow service.",
    },
    {
      name: "Sam Wilson",
      rating: 5,
      comment: "Absolutely loved the experience. Highly recommend!",
    },
  ];
  
  document.addEventListener("DOMContentLoaded", () => {
    const reviewsList = document.getElementById("reviewsList");
  
    reviewsData.forEach((review) => {
      const card = document.createElement("div");
      card.className = "review-card";
  
      card.innerHTML = `
        <h3>${review.name}</h3>
        <p>Rating: ${review.rating} / 5</p>
        <p>${review.comment}</p>
      `;
  
      reviewsList.appendChild(card);
    });
  });
  