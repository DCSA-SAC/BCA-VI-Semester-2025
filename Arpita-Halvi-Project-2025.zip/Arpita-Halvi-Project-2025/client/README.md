Backgrounds used in some pages are taken from

- https://www.svgbackgrounds.com/set/free-svg-backgrounds-and-patterns/
