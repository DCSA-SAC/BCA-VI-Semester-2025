<!-- ⚡️ SUPER DIFFERENT & CLASSY HEADER -->
<header class="ultra-header">
  <div class="ultra-top glassy-box">
    <div class="container d-flex justify-content-between align-items-center">
      <p class="welcome glow-txt">🏋️‍♂️ MARUTI FITNESS | RISE. TRAIN. DOMINATE.</p>
      <div class="top-links d-flex">
        <?php if(strlen($_SESSION['uid']) == 0): ?>
          <a href="login.php" class="nav-icon"><i class="material-icons">login</i></a>
        <?php else: ?>
          <a href="profile.php" class="nav-icon"><i class="material-icons">account_circle</i></a>
          <a href="changepassword.php" class="nav-icon"><i class="material-icons">vpn_key</i></a>
          <a href="logout.php" class="nav-icon"><i class="material-icons">logout</i></a>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="ultra-main">
    <div class="container d-flex justify-content-between align-items-center">
      <a href="index.php" class="logo-area">
        <img src="img/logoooo.png" alt="Maruti Logo" class="logo-spin" />
      </a>
      <nav class="main-nav">
        <ul class="nav-list">
          <li><a href="index.php" class="nav-link active">Home</a></li>
          <li><a href="about.php" class="nav-link">About</a></li>
          <li><a href="contact.php" class="nav-link">Contact</a></li>
          <li><a href="classes.html" class="nav-link">Classes</a></li>
          <?php if(strlen($_SESSION['uid']) == 0): ?>
            <li><a href="admin/" class="nav-link">Admin</a></li>
          <?php else: ?>
            <li><a href="booking-history.php" class="nav-link">Bookings</a></li>
          <?php endif; ?>
        </ul>
      </nav>
    </div>
  </div>
</header>

<!-- 💄 STYLING -->
<style>
/* General Reset */
body {
  margin: 0;
  padding: 0;
  font-family: 'Poppins', sans-serif;
}

/* Header Container */
.ultra-header {
  background: #0b0b0b;
  border-bottom: 2px solid transparent;
  border-image: linear-gradient(to right, #e50914, #ff416c) 1;
  box-shadow: 0 10px 30px rgba(229, 9, 20, 0.08);
  position: relative;
  z-index: 999;
}

/* Top Glass Bar */
.ultra-top {
  padding: 10px 0;
}
.glassy-box {
  background: rgba(255, 255, 255, 0.05);
  backdrop-filter: blur(8px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.07);
}
.welcome {
  margin: 0;
  font-weight: 600;
  letter-spacing: 1px;
  font-size: 14px;
  color: #fff;
}
.glow-txt {
  animation: glowy 1.5s ease-in-out infinite alternate;
}
@keyframes glowy {
  from { text-shadow: 0 0 5px #e50914; }
  to { text-shadow: 0 0 12px #e50914; }
}

/* Top Right Icons */
.top-links a {
  color: #fff;
  margin-left: 18px;
  font-size: 18px;
  transition: all 0.3s ease;
}
.top-links a:hover {
  color: #e50914;
  text-shadow: 0 0 8px #e50914;
  transform: scale(1.1);
}

/* Main Header */
.ultra-main {
  padding: 18px 0;
  background: linear-gradient(145deg, #111, #1a1a1a);
}

/* Logo */
.logo-area img {
  height: 150px;
  transition: 0.4s ease;
}
.logo-spin {
  animation: shine 5s infinite linear;
}
@keyframes shine {
  0% { filter: brightness(1); }
  50% { filter: brightness(1.3) drop-shadow(0 0 10px #e50914); }
  100% { filter: brightness(1); }
}

/* Navigation */
.main-nav {
  display: flex;
  align-items: center;
}
.nav-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  gap: 30px;
}
.nav-link {
  color: #fff;
  text-transform: uppercase;
  font-weight: 600;
  position: relative;
  transition: 0.3s ease;
  letter-spacing: 1px;
}
.nav-link::after {
  content: '';
  position: absolute;
  width: 0;
  height: 2px;
  background: #e50914;
  left: 0;
  bottom: -5px;
  transition: width 0.3s;
}
.nav-link:hover,
.nav-link.active {
  color: #e50914;
  text-shadow: 0 0 8px #e50914;
}
.nav-link:hover::after,
.nav-link.active::after {
  width: 100%;
}

/* Responsive */
@media (max-width: 768px) {
  .main-nav {
    flex-direction: column;
    align-items: center;
    margin-top: 15px;
  }
  .nav-list {
    flex-direction: column;
    gap: 10px;
  }
}
</style>
