<!-- ✨ Premium Footer Banner Section Begin -->
<section class="footer-banner-upgraded">
  <div class="container-fluid px-0">
    <div class="row no-gutters">
      <!-- Banner Left -->
      <div class="col-lg-6">
        <div class="footer-banner-box upgraded" style="background-image: url('img/footer-banner/footer-banner-1.jpg');">
          <div class="banner-overlay">
            <span class="tag">Limited Offer</span>
            <h2>7 Days Free Trial</h2>
            <p>Join us now and experience premium training absolutely free.</p>
            <a href="registration.php" class="banner-btn">Join Now</a>
          </div>
        </div>
      </div>
      <!-- Banner Right -->
      <div class="col-lg-6">
        <div class="footer-banner-box upgraded" style="background-image: url('img/footer-banner/footer-banner-2.jpg');">
          <div class="banner-overlay">
            <span class="tag">Need Help?</span>
            <h2>Call Us Anytime</h2>
            <p>+918103650717, +917828781672</p>
            <a href="tel:8103650717" class="banner-btn">Call Now</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- ✨ Premium Footer Banner Section End -->

<style>
.footer-banner-upgraded .footer-banner-box {
  height: 400px;
  background-size: cover;
  background-position: center;
  position: relative;
  transition: transform 0.4s ease;
}
.footer-banner-upgraded .footer-banner-box:hover {
  transform: scale(1.02);
}
.footer-banner-upgraded .banner-overlay {
  background-color: rgba(0, 0, 0, 0.55);
  color: #fff;
  height: 100%;
  padding: 50px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.footer-banner-upgraded .tag {
  font-size: 14px;
  color: #f15d44;
  text-transform: uppercase;
  letter-spacing: 2px;
  font-weight: bold;
  margin-bottom: 10px;
}
.footer-banner-upgraded h2 {
  font-size: 36px;
  font-weight: 700;
  margin-bottom: 15px;
}
.footer-banner-upgraded p {
  font-size: 16px;
  margin-bottom: 25px;
}
.footer-banner-upgraded .banner-btn {
  display: inline-block;
  padding: 12px 25px;
  background: linear-gradient(to right, #eb3c5a, #f67831);
  color: #fff;
  font-weight: 600;
  text-transform: uppercase;
  font-size: 14px;
  border-radius: 30px;
  text-decoration: none;
  transition: background 0.3s ease;
}
.footer-banner-upgraded .banner-btn:hover {
  background: linear-gradient(to right, #f67831, #eb3c5a);
}
@media(max-width: 768px) {
  .footer-banner-upgraded .banner-overlay {
    padding: 30px 20px;
    text-align: center;
  }
  .footer-banner-upgraded h2 {
    font-size: 28px;
  }
}
</style>


<!-- Footer Section Begin -->
<footer class="modern-footer">
  <div class="container">
    <div class="row text-center text-md-left">
      <div class="col-md-4">
        <div class="footer-info">
          <h4>Phone</h4>
          <p>+918103650717, +917828781672</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="footer-info">
          <h4>Address</h4>
          <p>In front of Judicial Academy, BeoharBagh,<br> Jabalpur, Madhya Pradesh 482001</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="footer-info">
          <h4>Email</h4>
          <p>marutifitness@gmail.com</p>
        </div>
      </div>
    </div>

    <div class="footer-line my-4"></div>

    <div class="row align-items-center">
      <div class="col-md-6 text-center text-md-left mb-3 mb-md-0">
        <p class="copyright-text">
          &copy; <script>document.write(new Date().getFullYear());</script> Maruti Fitness. All Rights Reserved.
        </p>
      </div>
      <div class="col-md-6 text-center text-md-right">
        <div class="footer-links">
          <a href="#">Terms of Use</a> |
          <a href="#">Privacy Policy</a>
        </div>
        <div class="footer-social mt-2">
          <a href="https://www.facebook.com/share/19qkiDz6S9/"><i class="fa fa-facebook"></i></a>
          <a href="https://www.instagram.com/_maruti.fitness_?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fa fa-instagram"></i></a>
          <a href="https://youtube.com/@fitnesschallenge-e2u?si=GKqa1XEu6zFcCWcF"><i class="fa fa-youtube-play"></i></a>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- Footer Section End -->

<style>


/* MODERN FOOTER */
.modern-footer {
  background: linear-gradient(135deg, #0a0a0a, #1e1e1e);
  padding: 60px 0 30px;
  color: #fff;
  font-family: 'Poppins', sans-serif;
}
.footer-info h4 {
  color: #f15d44;
  font-size: 16px;
  text-transform: uppercase;
  margin-bottom: 8px;
}
.footer-info p {
  color: #ddd;
  font-size: 15px;
  margin-bottom: 0;
}
.footer-line {
  height: 1px;
  background: #333;
  width: 100%;
}
.footer-links a {
  color: #ccc;
  margin: 0 8px;
  font-size: 14px;
  text-decoration: none;
}
.footer-links a:hover {
  color: #f15d44;
}
.footer-social a {
  display: inline-block;
  color: #fff;
  margin-left: 10px;
  font-size: 16px;
  background: #282828;
  border-radius: 50%;
  width: 36px;
  height: 36px;
  line-height: 36px;
  text-align: center;
  transition: all 0.3s ease;
}
.footer-social a:hover {
  background: linear-gradient(to right, #eb3c5a, #f67831);
  color: #fff;
}
.copyright-text {
  font-size: 14px;
}
@media(max-width: 768px) {
  .footer-banner-modern .banner-content {
    padding: 20px;
  }
}
</style>
