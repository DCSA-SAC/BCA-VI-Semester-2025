<?php 
session_start();
error_reporting(0);
include 'include/config.php';
$uid=$_SESSION['uid'];

if(isset($_POST['submit']))
{ 
$pid=$_POST['pid'];


$sql="INSERT INTO tblbooking (package_id,userid) Values(:pid,:uid)";

$query = $dbh -> prepare($sql);
$query->bindParam(':pid',$pid,PDO::PARAM_STR);
$query->bindParam(':uid',$uid,PDO::PARAM_STR);
$query -> execute();
echo "<script>alert('Package has been booked.');</script>";
echo "<script>window.location.href='booking-history.php'</script>";

}

?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>FITNESS</title>
	<meta charset="UTF-8">
	<meta name="description" content="Ahana Yoga HTML Template">
	<meta name="keywords" content="yoga, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/nice-select.css"/>
	<link rel="stylesheet" href="css/magnific-popup.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>
	<link rel="stylesheet" href="css/animate.css"/>

	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="css/style.css"/>

</head>
<body>
	<!-- Page Preloder -->
	

	<!-- Header Section -->
	<?php include 'include/header.php';?>
	<!-- Header Section end -->

	

	                                                                              
	
<!-- 🌟 Ultra Premium About Section Start -->
<section class="modern-about-section">
  <div class="container">
    <div class="row align-items-center">
      
      <!-- Left: About Content -->
      <div class="col-lg-6">
        <div class="about-glass-card">
          <h2>Welcome to <span>Maruti Fitness</span></h2>
          <p class="tagline">🏋️ Where Strength Meets Passion 🔥</p>
          <div class="about-highlights">
            <div class="highlight-item"><i class="fas fa-dumbbell"></i> Elite Equipment & Space</div>
            <div class="highlight-item"><i class="fas fa-user-friends"></i> Pro Trainers & Mentorship</div>
            <div class="highlight-item"><i class="fas fa-fire-alt"></i> Dynamic Workouts: HIIT, MMA, Yoga</div>
            <div class="highlight-item"><i class="fas fa-shield-alt"></i> Clean, Safe & Motivating Ambience</div>
            <div class="highlight-item"><i class="fas fa-headset"></i> 24/7 Community & Support</div>
          </div>
          <div class="founder-box">
            <img src="img/about-signature.png" alt="Signature">
            <div>
              <h4>Arjun Sonker</h4>
              <span>Founder & Fitness Coach</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Right: Video Section -->
      <div class="col-lg-6">
        <div class="modern-video-box">
          <iframe src="https://www.youtube.com/embed/iJlkODLcDNE?si=bLF_Xef2BJNnulUq" frameborder="0" allowfullscreen></iframe>
        </div>
      </div>

    </div>
  </div>
</section>
<!-- 🌟 Ultra Premium About Section End -->

<style>
/* Layout & Theme */
.modern-about-section {
  padding: 100px 0;
  background: linear-gradient(135deg, #0f0f0f, #1a1a1a);
  color: #fff;
  font-family: 'Segoe UI', sans-serif;
}

.about-glass-card {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 20px;
  padding: 40px;
  box-shadow: 0 0 30px rgba(241, 93, 68, 0.2);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  animation: fadeInLeft 1s ease-in-out;
}

.about-glass-card h2 {
  font-size: 36px;
  font-weight: 700;
  margin-bottom: 15px;
}
.about-glass-card h2 span {
  color: #f15d44;
}

.about-glass-card .tagline {
  font-size: 18px;
  font-weight: 500;
  color: #ccc;
  margin-bottom: 25px;
}

.about-highlights {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.highlight-item {
  font-size: 16px;
  background: rgba(255,255,255,0.05);
  padding: 10px 15px;
  border-radius: 12px;
  border-left: 3px solid #f15d44;
  display: flex;
  align-items: center;
  gap: 10px;
  transition: all 0.3s ease;
}
.highlight-item:hover {
  background: rgba(255,255,255,0.08);
  transform: translateX(5px);
  box-shadow: 0 0 10px #f15d44;
}

.founder-box {
  display: flex;
  align-items: center;
  margin-top: 25px;
  gap: 15px;
}
.founder-box img {
  height: 50px;
}
.founder-box h4 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}
.founder-box span {
  font-size: 14px;
  color: #ccc;
}

/* Video */
.modern-video-box {
  position: relative;
  padding-top: 56.25%;
  overflow: hidden;
  border-radius: 20px;
  box-shadow: 0 0 30px rgba(0,0,0,0.5);
  animation: fadeInRight 1s ease-in-out;
}
.modern-video-box iframe {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0; left: 0;
  border: none;
}

/* Animations */
@keyframes fadeInLeft {
  from { opacity: 0; transform: translateX(-50px); }
  to { opacity: 1; transform: translateX(0); }
}
@keyframes fadeInRight {
  from { opacity: 0; transform: translateX(50px); }
  to { opacity: 1; transform: translateX(0); }
}

/* Responsive */
@media (max-width: 768px) {
  .about-glass-card, .modern-video-box {
    margin-bottom: 30px;
  }
}
</style>

<!-- FontAwesome (if needed) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">


<!-- 🧊 Ultimate Glassmorphism Counter Section Start -->
<section class="counter-glass-section">
  <div class="container">
    <div class="row justify-content-center text-center">
      <!-- Box 1 -->
      <div class="col-md-3 col-sm-6">
        <div class="glass-counter-box">
          <i class="fas fa-dumbbell"></i>
          <h2 class="counter" data-count="4">0</h2>
          <p>Training Packages</p>
        </div>
      </div>
      <!-- Box 2 -->
      <div class="col-md-3 col-sm-6">
        <div class="glass-counter-box">
          <i class="fas fa-map-marked-alt"></i>
          <h2 class="counter" data-count="1">0</h2>
          <p>Center Location</p>
        </div>
      </div>
      <!-- Box 3 -->
      <div class="col-md-3 col-sm-6">
        <div class="glass-counter-box">
          <i class="fas fa-users"></i>
          <h2 class="counter" data-count="200">0</h2><span>+</span>
          <p>Happy Members</p>
        </div>
      </div>
      <!-- Box 4 -->
      <div class="col-md-3 col-sm-6">
        <div class="glass-counter-box">
          <i class="fas fa-user-shield"></i>
          <h2 class="counter" data-count="4">0</h2>
          <p>Certified Coaches</p>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- 🧊 Ultimate Glassmorphism Counter Section End -->

<!-- CSS -->
<style>
.counter-glass-section {
  background: url('https://images.unsplash.com/photo-1605296867304-46d5465a13f1') center/cover no-repeat;
  padding: 100px 0;
  backdrop-filter: blur(8px);
}
.glass-counter-box {
  background: rgba(255, 255, 255, 0.08);
  border-radius: 20px;
  padding: 40px 20px;
  margin: 20px 10px;
  box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(12px);
  color: #fff;
  border: 1px solid rgba(255, 255, 255, 0.18);
  transition: 0.4s ease;
}
.glass-counter-box:hover {
  transform: translateY(-10px);
  box-shadow: 0 0 25px #f15d44, 0 0 50px #f67831;
}
.glass-counter-box i {
  font-size: 50px;
  margin-bottom: 20px;
  color: #f67831;
  text-shadow: 0 0 10px #f15d44;
}
.glass-counter-box h2 {
  font-size: 40px;
  font-weight: 700;
}
.glass-counter-box p {
  font-size: 18px;
  color: #ddd;
}
</style>

<!-- JS Animation -->
<script>
  const counters = document.querySelectorAll('.counter');
  const speed = 150;

  counters.forEach(counter => {
    const updateCount = () => {
      const target = +counter.getAttribute('data-count');
      const count = +counter.innerText;

      const increment = Math.ceil(target / speed);

      if (count < target) {
        counter.innerText = count + increment;
        setTimeout(updateCount, 20);
      } else {
        counter.innerText = target;
      }
    };

    updateCount();
  });
</script>

<!-- Font Awesome (if not already included) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<!-- ✨ Modern Founder Banner Section Start -->
<section class="founder-banner-section">
  <div class="container">
    <div class="row align-items-center">
      
      <!-- Left: Text Content -->
      <div class="col-lg-6">
        <div class="founder-content fade-left">
          <h1>Meet Our Visionary <br><span>Mr. Arjun Sonker</span></h1>
          <p>
            🏆 <strong>A Passion for Fitness. A Mission for Transformation.</strong><br><br>
            With over 18+ years of dedication to fitness and transformation, <strong>Arjun Sonker</strong> has helped thousands sculpt their best selves. From strength training to full-body wellness, his expertise is unmatched.<br><br>
            💥 Founder of Maruti Fitness<br>
            💪 Certified Strength & Wellness Coach<br>
            🔥 Changing Lives, One Rep at a Time
          </p>
        </div>
      </div>

      <!-- Right: Founder Image -->
      <div class="col-lg-6 text-center">
        <div class="founder-img-box fade-right">
          <img src="img/arjunn-bg.png" alt="Arjun Sonker" class="founder-img">
          <div class="glow-border"></div>
        </div>
      </div>

    </div>
  </div>
</section>
<!-- ✨ Modern Founder Banner Section End -->

<style>
.founder-banner-section {
  padding: 100px 0;
  background: linear-gradient(135deg, #1a1a1a, #121212);
  color: #fff;
  font-family: 'Segoe UI', sans-serif;
}

.founder-content h1 {
  font-size: 40px;
  font-weight: 700;
  margin-bottom: 20px;
  line-height: 1.3;
}
.founder-content h1 span {
  color: #f15d44;
}
.founder-content p {
  font-size: 16px;
  line-height: 1.8;
  color: #ccc;
}

.founder-img-box {
  position: relative;
  display: inline-block;
}
.founder-img {
  width: 100%;
  max-width: 400px;
  border-radius: 20px;
  z-index: 2;
  position: relative;
}
.glow-border {
  position: absolute;
  top: -10px; left: -10px; right: -10px; bottom: -10px;
  background: linear-gradient(45deg, #f15d44, #ff9900, #f15d44);
  border-radius: 25px;
  z-index: 1;
  filter: blur(15px);
  animation: pulseGlow 3s infinite ease-in-out;
}

@keyframes pulseGlow {
  0%, 100% { opacity: 0.7; transform: scale(1); }
  50% { opacity: 1; transform: scale(1.05); }
}

.fade-left {
  animation: fadeInLeft 1.2s ease;
}
.fade-right {
  animation: fadeInRight 1.2s ease;
}
@keyframes fadeInLeft {
  from { opacity: 0; transform: translateX(-40px); }
  to { opacity: 1; transform: translateX(0); }
}
@keyframes fadeInRight {
  from { opacity: 0; transform: translateX(40px); }
  to { opacity: 1; transform: translateX(0); }
}

/* Responsive */
@media (max-width: 768px) {
  .founder-content h1 {
    font-size: 30px;
  }
  .founder-img {
    max-width: 300px;
  }
}
</style>




	

	<!-- Footer Section -->
	<?php include 'include/footer.php'; ?>
	<!-- Footer Section end -->

	<div class="back-to-top"><img src="img/icons/up-arrow.png" alt=""></div>

	<!-- Search model end -->

	<!--====== Javascripts & Jquery ======-->
	<script src="js/vendor/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.slicknav.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.nice-select.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/main.js"></script>

	</body>
</html>
