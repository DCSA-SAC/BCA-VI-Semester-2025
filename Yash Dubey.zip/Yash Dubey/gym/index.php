<?php 
session_start();
error_reporting(0);
include 'include/config.php';
$uid=$_SESSION['uid'];

if(isset($_POST['submit']))
{ 
$pid=$_POST['pid'];


$sql="INSERT INTO tblbooking (package_id,userid) Values(:pid,:uid)";

$query = $dbh -> prepare($sql);
$query->bindParam(':pid',$pid,PDO::PARAM_STR);
$query->bindParam(':uid',$uid,PDO::PARAM_STR);
$query -> execute();
echo "<script>alert('Package has been booked.');</script>";
echo "<script>window.location.href='booking-history.php'</script>";

}

?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>FITNESS</title>
	<meta charset="UTF-8">
	<meta name="description" content="Ahana Yoga HTML Template">
	<meta name="keywords" content="yoga, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/nice-select.css"/>
	<link rel="stylesheet" href="css/magnific-popup.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>
	<link rel="stylesheet" href="css/animate.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
<link rel="stylesheet" href="css/owl.theme.default.min.css"/>


	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="css/style.css"/>

</head>
<body>
	<!-- Header Section -->
	<?php include 'include/header.php';?>
	<!-- Header Section end -->
	
<!-- 🔥 Khatarnak About Section Start -->
<section class="about-section-intense">
    <!-- Background Video -->
    <div class="video-container">
        <iframe src="https://www.youtube.com/embed/-k2en7Fnmq4?autoplay=1&mute=1&loop=1&playlist=-k2en7Fnmq4" 
                frameborder="0" allow="autoplay; fullscreen"
                class="video-bg"></iframe>
    </div>

    <!-- Glass Content -->
    <div class="about-overlay">
        <div class="glass-box">
            <h2 class="section-title">𝐓𝐇𝐄 <span class="highlight">𝐌𝐀𝐑𝐔𝐓𝐈 𝐅𝐈𝐓𝐍𝐄𝐒𝐒</span></h2>
            <p class="intro-text">
                Welcome to <strong>Maruti Fitness</strong> — your ultimate transformation hub. Based in the vibrant heart of <strong>Jabalpur</strong>, our gym is more than just a fitness space; it's a lifestyle movement.
            </p>
            <p class="closing-text">
                From beginners to pro athletes, we provide cutting-edge equipment, expert trainers, and a vibe that screams hustle. Push your limits. Become unstoppable.
            </p>
        </div>
    </div>
</section>
<!-- 🔥 Khatarnak About Section End -->

<style>
/* 🔥 Main About Section */
.about-section-intense {
    position: relative;
    width: 100%;
    min-height: 100vh;
    overflow: hidden;
    background: #000;
}

/* 📹 Video Background */
.video-container {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    overflow: hidden;
    z-index: 1;
}

.video-bg {
    width: 100%;
    height: 100%;
    object-fit: cover;
    pointer-events: none;
    filter: brightness(0.4) contrast(1.2);
}

/* 🧊 Glass Effect */
.about-overlay {
    position: relative;
    z-index: 2;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    padding: 40px 20px;
}

.glass-box {
    max-width: 850px;
    padding: 60px 50px;
    background: rgba(255, 255, 255, 0.1);
    border: 2px solid rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(18px);
    border-radius: 25px;
    box-shadow: 0 0 30px rgba(255, 0, 0, 0.3);
    animation: glow-border 3s infinite ease-in-out;
}

/* ✨ Glowing Red Border Animation */
@keyframes glow-border {
    0% {
        box-shadow: 0 0 10px rgba(229, 9, 20, 0.3);
    }
    50% {
        box-shadow: 0 0 25px rgba(229, 9, 20, 0.6);
    }
    100% {
        box-shadow: 0 0 10px rgba(229, 9, 20, 0.3);
    }
}

/* 🧨 Typography */
.section-title {
    color: #fff;
    font-size: 48px;
    text-align: center;
    text-transform: uppercase;
    letter-spacing: 4px;
    margin-bottom: 30px;
}

.highlight {
    color: #e50914;
    text-shadow: 2px 2px 15px rgba(255, 0, 0, 0.6);
}

.intro-text, .closing-text {
    color: #eee;
    font-size: 18px;
    line-height: 1.8;
    text-align: center;
    font-weight: 500;
    text-shadow: 1px 1px 8px rgba(0, 0, 0, 0.5);
}

.closing-text {
    margin-top: 25px;
    color: #ccc;
}

/* 📱 Responsive Tweaks */
@media (max-width: 768px) {
    .glass-box {
        padding: 40px 30px;
    }
    .section-title {
        font-size: 36px;
    }
    .intro-text, .closing-text {
        font-size: 16px;
    }
}
</style>





<!-- New Modern Services Section -->
<section class="modern-services-section py-5" style="background: linear-gradient(135deg, #0f0f0f, #1a1a1a); color: #fff;">
    <div class="container">
        <div class="text-center mb-5">
            <h2 style="text-transform: uppercase; font-weight: 700; color: #e50914;">What We Offer</h2>
            <p style="color: #aaa;">Premium services tailored to help you transform physically and mentally.</p>
        </div>
        <div class="row gy-4 align-items-center">
            
            <!-- Left Column (Image) -->
            <div class="col-lg-5">
                <div class="image-wrap shadow-lg" style="overflow: hidden; border-radius: 20px;">
                    <img src="img/services/service-pic.jpg" alt="Our Services" class="img-fluid" style="border-radius: 20px;">
                </div>
            </div>

            <!-- Right Column (Services List) -->
            <div class="col-lg-7">
                <div class="row g-4">
                    
                    <!-- Service Box -->
                    <div class="col-md-6">
                        <div class="service-box p-4 h-100" style="background: rgba(255,255,255,0.05); border-radius: 15px; backdrop-filter: blur(10px); transition: 0.3s; border: 1px solid rgba(255,255,255,0.08); text-align: center;">
                            <img src="img/services/service-icon-1.png" alt="Strategies" style="width: 50px; margin-bottom: 15px;">
                            <h5 style="color: #fff; font-weight: bold;">Strategies</h5>
                            <p style="color: #ccc;">Customized plans with expert-led training strategies tailored to your body.</p>
                        </div>
                    </div>

                    <!-- Service Box -->
                    <div class="col-md-6">
                        <div class="service-box p-4 h-100" style="background: rgba(255,255,255,0.05); border-radius: 15px; backdrop-filter: blur(10px); transition: 0.3s; border: 1px solid rgba(255,255,255,0.08); text-align: center;">
                            <img src="img/services/service-icon-2.png" alt="Yoga" style="width: 50px; margin-bottom: 15px;">
                            <h5 style="color: #fff; font-weight: bold;">Yoga</h5>
                            <p style="color: #ccc;">Mindful movement, breathing, and flexibility to calm your inner self.</p>
                        </div>
                    </div>

                    <!-- Service Box -->
                    <div class="col-md-6">
                        <div class="service-box p-4 h-100" style="background: rgba(255,255,255,0.05); border-radius: 15px; backdrop-filter: blur(10px); transition: 0.3s; border: 1px solid rgba(255,255,255,0.08); text-align: center;">
                            <img src="img/services/service-icon-3.png" alt="Workout" style="width: 50px; margin-bottom: 15px;">
                            <h5 style="color: #fff; font-weight: bold;">Workout</h5>
                            <p style="color: #ccc;">Powerful sessions: HIIT, strength training & more — all goal-focused.</p>
                        </div>
                    </div>

                    <!-- Service Box -->
                    <div class="col-md-6">
                        <div class="service-box p-4 h-100" style="background: rgba(255,255,255,0.05); border-radius: 15px; backdrop-filter: blur(10px); transition: 0.3s; border: 1px solid rgba(255,255,255,0.08); text-align: center;">
                            <img src="img/services/service-icon-4.png" alt="Weight Loss" style="width: 50px; margin-bottom: 15px;">
                            <h5 style="color: #fff; font-weight: bold;">Weight Loss</h5>
                            <p style="color: #ccc;">Smart and sustainable fat-loss programs with real-time tracking.</p>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</section>
<style>.service-box:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 25px rgba(229, 9, 20, 0.2);
    background: rgba(229, 9, 20, 0.1);
    transition: 0.3s ease-in-out;
}
</style>
<!-- New Modern Services Section END -->


<!-- Testimonial Section Begin -->
<section class="testimonial-section spad" style="background-color: #111; color: #fff; padding: 120px 0; position: relative; overflow: hidden;">
    <div class="container">
        <div class="row mb-5">
            <div class="col-lg-12 text-center">
                <div class="section-title">
                    <h2 style="color: #ff4e00; font-weight: 900; text-transform: uppercase; letter-spacing: 3px; font-size: 40px; position: relative; z-index: 1;">Success Stories</h2>
                    <p style="color: #ccc; font-size: 20px; font-weight: 500;">Real results from our dedicated members</p>
                </div>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="testimonial-slider owl-carousel">
                    
                    <!-- Testimonial 1 -->
                    <div class="testimonial-item text-center p-4" style="background-color: #1e1e1e; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.6); transition: all 0.3s ease-in-out; overflow: hidden; position: relative;">
                        <p style="font-size: 18px; color: #ddd; line-height: 1.8; font-style: italic; position: relative; z-index: 2;">
                            🏅 Achieving gold medal at National Incline-bench Weightlifting Competition 2023.
                        </p>
                        <div class="ti-pic my-4">
                            <img src="img/testimonial/testimonial-2.jpg" alt="Arjun Sonker" class="rounded-circle" style="width: 90px; height: 90px; object-fit: cover; border: 3px solid #ff4e00; transition: all 0.3s ease; position: relative; z-index: 2;">
                        </div>
                        <div class="ti-author">
                            <h4 style="color: #ff4e00; margin-bottom: 5px; font-weight: 700; font-size: 22px; text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.4);">Arjun Sonker</h4>
                            <span style="color: #bbb; font-size: 16px;">Member</span>
                        </div>
                        <div class="testimonial-hover-effect"></div>
                    </div>

                    <!-- Testimonial 2 -->
                    <div class="testimonial-item text-center p-4" style="background-color: #1e1e1e; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.6); transition: all 0.3s ease-in-out; overflow: hidden; position: relative;">
                        <p style="font-size: 18px; color: #ddd; line-height: 1.8; font-style: italic; position: relative; z-index: 2;">
                            “Maruti Fitness changed my life! The guidance, the support, and the atmosphere – it’s unmatched.”
                        </p>
                        <div class="ti-pic my-4">
                            <img src="img/testimonial/testimonial-1.jpg" alt="Vikram Sonker" class="rounded-circle" style="width: 90px; height: 90px; object-fit: cover; border: 3px solid #ff4e00; transition: all 0.3s ease; position: relative; z-index: 2;">
                        </div>
                        <div class="ti-author">
                            <h4 style="color: #ff4e00; margin-bottom: 5px; font-weight: 700; font-size: 22px; text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.4);">Vikram Sonker</h4>
                            <span style="color: #bbb; font-size: 16px;">Leader</span>
                        </div>
                        <div class="testimonial-hover-effect"></div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* Testimonial Section Styling */
.testimonial-section {
    background-color: #111;
    color: #fff;
    padding: 120px 0;
    position: relative;
    overflow: hidden;
}

.testimonial-slider .testimonial-item {
    transition: transform 0.3s ease-in-out, box-shadow 0.3s ease, filter 0.3s ease;
    border-radius: 20px;
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.6);
    background-color: #1e1e1e;
    padding: 30px;
    position: relative;
}

.testimonial-slider .testimonial-item:hover {
    transform: scale(1.05);
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.8);
    filter: brightness(1.1);
}

.testimonial-slider .ti-pic {
    margin-bottom: 20px;
    position: relative;
    z-index: 2;
}

.testimonial-slider .ti-author {
    margin-top: 15px;
    position: relative;
    z-index: 2;
}

.testimonial-slider .ti-author h4 {
    color: #ff4e00;
    font-weight: 700;
    font-size: 22px;
    text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.4);
}

.testimonial-slider .ti-author span {
    color: #bbb;
    font-size: 16px;
}

.testimonial-hover-effect {
    background: linear-gradient(45deg, rgba(255, 78, 0, 0.6), rgba(255, 255, 255, 0.2));
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-radius: 20px;
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: 1;
}

.testimonial-slider .testimonial-item:hover .testimonial-hover-effect {
    opacity: 1;
}

.owl-dots {
    text-align: center;
    margin-top: 30px;
}

.owl-dot span {
    width: 14px;
    height: 14px;
    background: #ff4e00;
    display: inline-block;
    margin: 8px;
    border-radius: 50%;
    opacity: 0.5;
    transition: 0.3s;
}

.owl-dot.active span {
    opacity: 1;
    transform: scale(1.4);
}

/* Adjustments for mobile view */
@media (max-width: 767px) {
    .testimonial-section {
        padding: 80px 0;
    }

    .testimonial-slider .testimonial-item {
        padding: 20px;
    }

    .testimonial-slider .ti-author h4 {
        font-size: 20px;
    }

    .testimonial-slider .ti-author span {
        font-size: 14px;
    }
}
</style>

<script src="js/vendor/jquery-3.2.1.min.js"></script>
<script src="js/owl.carousel.min.js"></script>

<script>
    $(document).ready(function(){
        $(".testimonial-slider").owlCarousel({
            items: 1,
            loop: true,
            margin: 30,
            nav: false,
            dots: true,
            autoplay: true,
            autoplayTimeout: 5000,
            smartSpeed: 800
        });
    });
</script>

<!-- Testimonial Section End -->


<!-- Founder Highlight Section - Premium Glassmorphism Style -->
<section class="founder-section" style="position: relative; background: #0d0d0d; padding: 100px 0; overflow: hidden;">
    <!-- Background Overlay -->
    <div class="overlay" style="background: linear-gradient(135deg, rgba(229,9,20,0.1), rgba(255,60,60,0.05)); position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 1;"></div>

    <div class="container position-relative" style="z-index: 2;">
        <div class="row align-items-center justify-content-between flex-lg-row flex-column-reverse">
            
            <!-- Founder Image -->
            <div class="col-lg-6 text-center mb-5 mb-lg-0">
                <div class="founder-img-wrap" style="position: relative; display: inline-block;">
                    <img src="img/arjunn-bg.png" alt="Mr. Arjun Sonker - Founder" class="img-fluid rounded" style="max-height: 480px; border-radius: 30px; border: 5px solid #e50914; box-shadow: 0 15px 30px rgba(229, 9, 20, 0.3); transition: 0.3s;">
                    <div class="ribbon-tag" style="position: absolute; top: -15px; left: -15px; background: #e50914; padding: 6px 15px; color: white; font-size: 14px; font-weight: bold; border-radius: 20px;">Founder</div>
                </div>
            </div>

            <!-- Text Content -->
            <div class="col-lg-6">
                <div class="glass-content p-4" style="background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(10px); border-radius: 20px; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 10px 30px rgba(0,0,0,0.4);">
                    <h2 class="text-uppercase fw-bold mb-3" style="font-size: 40px; color: #fff; letter-spacing: 1px;">
                        Meet <span style="color: #e50914;">Mr. Arjun Sonker</span>
                    </h2>
                    <p style="font-size: 16.5px; line-height: 1.8; color: #ccc;">
                        🏆 <strong style="color: #ff3c3c;">Driven by Passion, Defined by Strength</strong><br><br>
                        <strong>Arjun Sonker</strong> is not just the founder of <strong>Maruti Fitness</strong>, he’s the force behind its values. With over <strong>18 years of hands-on experience</strong> in fitness training, bodybuilding, and coaching, he has transformed lives and mindsets. His mission is clear: <em>“Discipline, Dedication, and Growth – every day.”</em>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<style>.founder-section .glass-content:hover {
    box-shadow: 0 20px 40px rgba(229, 9, 20, 0.4);
    transform: translateY(-5px);
    transition: 0.4s ease;
}

.founder-img-wrap img:hover {
    transform: scale(1.03);
    transition: 0.3s ease-in-out;
}
</style>
<!-- Founder Highlight Section - Premium Glassmorphism Style  end  -->

<!-- Pricing Section - Premium Glassmorphism Style -->
<section class="pricing-section spad" style="background: linear-gradient(135deg, #0f0f0f 0%, #1a1a1a 100%); padding: 80px 0;">
    <div class="container">
        <div class="section-title text-center mb-5">
            <img src="img/logoooo.png" alt="Maruti Fitness Logo" style="width: 200px; animation: floatLogo 4s ease-in-out infinite;">
            <h2 class="text-uppercase mt-3" style="color: #e50914; font-weight: 700; letter-spacing: 1px;">Our Premium Plans</h2>
            <p style="color: #bbb; font-size: 17px;">Tailored memberships to fuel your transformation journey.</p>
        </div>

        <div class="row justify-content-center">
            <?php  
            $sql = "SELECT id, category, titlename, PackageType, PackageDuratiobn, Price, uploadphoto, Description, create_date FROM tbladdpackage";
            $query = $dbh->prepare($sql);
            $query->execute();
            $results = $query->fetchAll(PDO::FETCH_OBJ);
            if ($query->rowCount() > 0) {
                foreach ($results as $result) {
            ?>
            <div class="col-lg-4 col-md-6 mb-5 d-flex">
                <div class="glass-card p-4 w-100">
                    <div class="mb-3">
                        <h4 class="text-white fw-bold"><?php echo htmlentities($result->titlename); ?></h4>
                        <span class="badge bg-gradient text-white" style="font-size: 13px;"><?php echo htmlentities($result->category); ?></span>
                    </div>
                    <div class="price-box my-3">
                        <h2 class="gradient-text">₹<?php echo htmlentities($result->Price); ?></h2>
                        <p class="text-light" style="font-size: 14px;"><?php echo htmlentities($result->PackageDuratiobn); ?></p>
                    </div>
                    <p class="text-muted" style="font-size: 15px;"><?php echo nl2br(htmlentities($result->Description)); ?></p>

                    <div class="text-center mt-4">
                        <?php if (strlen($_SESSION['uid']) == 0): ?>
                            <a href="login.php" class="btn-gradient">Book Now</a>
                        <?php else: ?>
                            <form method="post">
                                <input type="hidden" name="pid" value="<?php echo htmlentities($result->id); ?>">
                                <input type="submit" name="submit" class="btn-gradient" value="Book Now" onclick="return confirm('Do you really want to book this package?');">
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php 
                } 
            } 
            ?>
        </div>
    </div>
</section>


<!-- Optional: Add this CSS in your custom stylesheet or <style> tag -->
<style>
/* Glass Card Style */
.glass-card {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.15);
    backdrop-filter: blur(10px);
    border-radius: 20px;
    box-shadow: 0 15px 30px rgba(229, 9, 20, 0.2);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.glass-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 25px 40px rgba(229, 9, 20, 0.3);
}

/* Gradient Button */
.btn-gradient {
    background: linear-gradient(90deg, #e50914, #ff3c3c);
    color: white;
    padding: 10px 25px;
    border: none;
    border-radius: 40px;
    font-weight: 600;
    transition: 0.3s ease-in-out;
    text-decoration: none;
    display: inline-block;
    cursor: pointer;
}

.btn-gradient:hover {
    background: linear-gradient(90deg, #ff3c3c, #e50914);
}

.gradient-text {
    font-size: 36px;
    color: #e50914; /* Fallback color shown by default */
}

/* Only apply gradient text if supported */
@supports (-webkit-background-clip: text) {
    .gradient-text {
        background: linear-gradient(90deg, #e50914, #ff3c3c);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
}



/* Floating Logo Animation */
@keyframes floatLogo {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-6px); }
}

</style>


<!-- Footer Section -->
	<?php include 'include/footer.php'; ?>
	<!-- Footer Section end -->

	<div class="back-to-top"><img src="img/icons/up-arrow.png" alt=""></div>

	<!-- Search model end -->

	<!--====== Javascripts & Jquery ======-->
	<script src="js/vendor/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.slicknav.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.nice-select.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/main.js"></script>

	</body>
</html>
