<?php
error_reporting(0);
require_once('include/config.php');

if(isset($_POST['submit'])) { 
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $Password = $_POST['password'];
    $pass = md5($Password);
    $RepeatPassword = $_POST['RepeatPassword'];

    $usermatch = $dbh->prepare("SELECT mobile, email FROM tbluser WHERE (email=:usreml || mobile=:mblenmbr)");
    $usermatch->execute(array(':usreml' => $email, ':mblenmbr' => $mobile)); 
    while ($row = $usermatch->fetch(PDO::FETCH_ASSOC)) {
        $usrdbeml = $row['email'];
        $usrdbmble = $row['mobile'];
    }

    if (empty($fname)) {
        $error = "Please Enter First Name";
    } else if (empty($mobile)) {
        $error = "Please Enter Mobile No";
    } else if (empty($email)) {
        $error = "Please Enter Email";
    } else if ($email == $usrdbeml || $mobile == $usrdbmble) {
        $error = "Email Id or Mobile Number Already Exists!";
    } else if ($Password == "" || $RepeatPassword == "") {
        $error = "Password And Confirm Password Cannot Be Empty!";
    } else if ($_POST['password'] != $_POST['RepeatPassword']) {
        $error = "Password And Confirm Password Do Not Match!";
    } else {
        $sql = "INSERT INTO tbluser (fname, lname, email, mobile, state, city, password) 
                VALUES (:fname, :lname, :email, :mobile, :state, :city, :Password)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':fname', $fname, PDO::PARAM_STR);
        $query->bindParam(':lname', $lname, PDO::PARAM_STR);
        $query->bindParam(':email', $email, PDO::PARAM_STR);
        $query->bindParam(':mobile', $mobile, PDO::PARAM_STR);
        $query->bindParam(':state', $state, PDO::PARAM_STR);
        $query->bindParam(':city', $city, PDO::PARAM_STR);
        $query->bindParam(':Password', $pass, PDO::PARAM_STR);
        $query->execute();
        $lastInsertId = $dbh->lastInsertId();
        if ($lastInsertId > 0) {
            echo "<script>alert('Registration successful. Please login');</script>";
            echo "<script>window.location.href='login.php';</script>";
        } else {
            $error = "Registration Not Successful";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Maruti Fitness | Register</title>
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/font-awesome.min.css"/>
    <link rel="stylesheet" href="css/style.css"/>
    <style>
        body {
            background-color: #1a1a1a;
            font-family: 'Poppins', sans-serif;
            color: #fff;
        }

        .page-top {
            text-align: center;
            padding: 60px 0 30px;
        }

        .page-top h1 {
            font-size: 3rem;
            font-weight: bold;
            margin-bottom: 10px;
            color: #f39c12;
        }

        .page-top p {
            font-size: 1.2rem;
            color: #ccc;
        }

        .contact-page-section {
            padding: 30px 0;
        }

        .contact-form input {
            width: 100%;
            padding: 15px;
            margin: 10px 0;
            background-color: #2c2c2c;
            border: none;
            border-radius: 6px;
            color: #fff;
            font-size: 15px;
            transition: 0.3s;
        }

        .contact-form input:focus {
            outline: none;
            border: 1px solid #f39c12;
            box-shadow: 0 0 8px #f39c12;
        }

        .site-btn {
            background: linear-gradient(to right, #e74c3c, #f39c12);
            color: white;
            padding: 12px;
            border: none;
            border-radius: 30px;
            font-size: 18px;
            width: 100%;
            transition: 0.3s ease;
        }

        .site-btn:hover {
            background: linear-gradient(to right, #f39c12, #e74c3c);
            box-shadow: 0 0 12px #e67e22;
        }

        .errorWrap, .succWrap {
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .errorWrap {
            background-color: #e74c3c;
            color: white;
        }

        .succWrap {
            background-color: #2ecc71;
            color: white;
        }

        @media (max-width: 768px) {
            .page-top h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>

<?php include 'include/header.php'; ?>

<div class="page-top">
    <h1>Join Maruti Fitness</h1>
    <p>Register now and transform your lifestyle</p>
</div>

<section class="contact-page-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <?php if ($error) { ?>
                    <div class="errorWrap"><strong>ERROR:</strong> <?php echo htmlentities($error); ?></div>
                <?php } ?>
                <form class="contact-form" method="post">
                    <div class="row">
                        <div class="col-md-6"><input type="text" name="fname" placeholder="First Name" value="<?php echo $fname;?>" required></div>
                        <div class="col-md-6"><input type="text" name="lname" placeholder="Last Name" value="<?php echo $lname;?>"></div>
                        <div class="col-md-6"><input type="email" name="email" placeholder="Email" value="<?php echo $email;?>" required></div>
                        <div class="col-md-6"><input type="text" name="mobile" placeholder="Mobile" maxlength="10" value="<?php echo $mobile;?>" required></div>
                        <div class="col-md-6"><input type="text" name="state" placeholder="State" value="<?php echo $state;?>" required></div>
                        <div class="col-md-6"><input type="text" name="city" placeholder="City" value="<?php echo $city;?>" required></div>
                        <div class="col-md-6"><input type="password" name="password" placeholder="Password" required></div>
                        <div class="col-md-6"><input type="password" name="RepeatPassword" placeholder="Confirm Password" required></div>
                        <div class="col-12 mt-3">
                            <input type="submit" name="submit" class="site-btn" value="Register Now">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php include 'include/footer.php'; ?>

<script src="js/vendor/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
