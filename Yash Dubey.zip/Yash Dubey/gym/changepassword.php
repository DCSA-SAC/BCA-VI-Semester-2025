<?php
session_start();
error_reporting(0);
require_once('include/config.php');
if(strlen( $_SESSION["uid"])==0)
    {   
header('location:login.php');
}
else{
// Code for change password	
if(isset($_POST['submit']))
	{
$password=md5($_POST['password']);
$newpassword=md5($_POST['newpassword']);
$email=$_SESSION['email'];
$sql ="SELECT password FROM tbluser WHERE email=:email and password=:password";
$query= $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
if($query -> rowCount() > 0)
{
$con="update tbluser set password=:newpassword where email=:email";
$chngpwd1 = $dbh->prepare($con);
$chngpwd1-> bindParam(':email', $email, PDO::PARAM_STR);
$chngpwd1-> bindParam(':newpassword', $newpassword, PDO::PARAM_STR);
$chngpwd1->execute();
$msg="Your Password succesfully changed";
}
else {
$error="Your current password is not valid.";	
}
}
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>FITNESS</title>
	<meta charset="UTF-8">
	<meta name="description" content="Ahana Yoga HTML Template">
	<meta name="keywords" content="yoga, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/nice-select.css"/>
	<link rel="stylesheet" href="css/magnific-popup.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>
	<link rel="stylesheet" href="css/animate.css"/>

	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="css/style.css"/>
<script type="text/javascript">
function valid()
{
if(document.chngpwd.newpassword.value!= document.chngpwd.confirmpassword.value)
{
alert("New Password and Confirm Password Field do not match  !!");
document.chngpwd.confirmpassword.focus();
return false;
}
return true;
}
</script>
  <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>
</head>
<body>
	<!-- Page Preloder -->
	

	<!-- Header Section -->
	<?php include 'include/header.php';?>
	<!-- Header Section end -->

	<!-- Profile Page Top Section (🔥 Bawal Style 🔥) -->
<section class="page-top-section" style="position: relative; height: 350px; background: url('img/page-top-bg.jpg') center/cover no-repeat; display: flex; align-items: center; justify-content: center; overflow: hidden;">
    <!-- Dark Overlay -->
    <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.85); z-index: 1;"></div>

    <!-- Neon Border Glow Lines -->
    <div class="glow-border"></div>

    <div class="container text-center position-relative" style="z-index: 2;">
        <h1 class="profile-title">🔥 Change Password 🔥</h1>
        <p class="profile-subtitle">Manage your fitness journey like a pro</p>
    </div>
</section>

<!-- Custom CSS -->
<style>
.profile-title {
    font-size: 58px;
    color: #FF4E00;
    font-weight: bold;
    text-shadow: 0 0 15px rgba(255, 78, 0, 0.7), 0 0 30px rgba(255, 78, 0, 0.5);
    letter-spacing: 2px;
    animation: glowFade 3s infinite alternate;
}

.profile-subtitle {
    font-size: 18px;
    color: #ccc;
    margin-top: 10px;
    text-shadow: 0 0 5px rgba(255, 255, 255, 0.2);
}

@keyframes glowFade {
    from {
        text-shadow: 0 0 10px rgba(255, 78, 0, 0.6), 0 0 20px rgba(255, 78, 0, 0.3);
    }
    to {
        text-shadow: 0 0 25px rgba(255, 78, 0, 1), 0 0 40px rgba(255, 78, 0, 0.7);
    }
}

/* Optional Glow Border */
.glow-border {
    position: absolute;
    top: 15px;
    left: 15px;
    right: 15px;
    bottom: 15px;
    border: 2px solid rgba(255, 78, 0, 0.5);
    border-radius: 20px;
    box-shadow: 0 0 30px rgba(255, 78, 0, 0.4);
    z-index: 1;
    animation: pulseGlow 4s infinite alternate;
}

@keyframes pulseGlow {
    0% {
        box-shadow: 0 0 10px rgba(255, 78, 0, 0.3);
    }
    100% {
        box-shadow: 0 0 35px rgba(255, 78, 0, 0.8);
    }
}
</style>




	<!-- Change Password Section -->
<section class="pricing-section spad" style="background: linear-gradient(135deg, #121212, #1e1e1e); padding: 80px 0;">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-sm-6"></div>
            <div class="col-lg-4 col-sm-6">
                <div class="pricing-item entermediate">
                    <div class="pi-top text-center">
                        <h4 class="text-uppercase text-white font-weight-bold">Change Password</h4>
                        <p class="text-light">Secure your account with a stronger password</p>
                    </div>
                    <!-- Success/Error Messages -->
                    <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div><?php } 
                    else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div><?php }?>
                    
                    <!-- Password Change Form -->
                    <form class="singup-form contact-form" method="post" onSubmit="return valid();">
                        <div class="row">
                            <div class="col-md-12 mb-4">
                                <input type="password" name="password" id="password" placeholder="Old Password" autocomplete="off" class="custom-input">
                            </div>
                            <div class="col-md-12 mb-4">
                                <input type="password" name="newpassword" id="newpassword" placeholder="New Password" autocomplete="off" class="custom-input">
                            </div>
                            <div class="col-md-12 mb-4">
                                <input type="password" name="confirmpassword" id="confirmpassword" placeholder="Confirm Password" autocomplete="off" class="custom-input">
                            </div>
                        </div>
                        <input type="submit" id="submit" name="submit" value="Submit" class="site-btn sb-gradient">
                    </form>
                </div>
            </div>
            <div class="col-lg-4 col-sm-6"></div>
        </div>
    </div>
</section>

<!-- Custom CSS for Gym Vibe Design -->
<style>
/* Styling the Input Fields with a Gym Vibe */
.custom-input {
    width: 100%;
    padding: 15px;
    border-radius: 10px;
    border: 2px solid #444;
    background-color: #2c2c2c;
    color: #fff;
    font-size: 16px;
    margin-bottom: 20px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
}

.custom-input:focus {
    outline: none;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.8);
}

/* Submit Button */
.site-btn.sb-gradient {
    width: 100%;
    padding: 15px 0;
    border-radius: 30px;
    color: #fff;
    font-weight: 600;
    font-size: 16px;
    text-align: center;
    transition: all 0.3s ease;
    background: linear-gradient(135deg, #f44336, #ff5722);
}

.site-btn.sb-gradient:hover {
    transform: scale(1.05);
    cursor: pointer;
}

/* Form Container */
.pricing-item {
    background: rgba(0, 0, 0, 0.7);
    border-radius: 15px;
    padding: 40px 30px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
}

.pi-top {
    text-align: center;
    padding-bottom: 20px;
}

.pi-top h4 {
    font-size: 24px;
    color: #fff;
    font-weight: 700;
    margin-bottom: 10px;
}

.pi-top p {
    font-size: 14px;
    color: #ccc;
}

/* Error/Success Messages */
.succWrap {
    margin-bottom: 15px;
    padding: 10px;
    background-color: #388e3c;
    border-radius: 5px;
    color: white;
}


/* Page Background */
.pricing-section {
    background: linear-gradient(135deg, #121212, #1e1e1e);
    padding: 80px 0;
}
</style>

	

	<!-- Footer Section -->
	<?php include 'include/footer.php'; ?>
	<!-- Footer Section end -->

	<div class="back-to-top"><img src="img/icons/up-arrow.png" alt=""></div>

	<!-- Search model end -->

	<!--====== Javascripts & Jquery ======-->
	<script src="js/vendor/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.slicknav.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.nice-select.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/main.js"></script>

	</body>
</html>
<?php } ?>