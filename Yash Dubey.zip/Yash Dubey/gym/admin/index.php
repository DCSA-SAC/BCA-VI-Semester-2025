<?php  
session_start();
error_reporting(0);
include 'include/config.php'; 
if (strlen($_SESSION['adminid']) == 0) {
  header('location:logout.php');
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>𝐅𝐈𝐓𝐍𝐄𝐒𝐒</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg,rgb(255, 21, 21),rgb(255, 56, 56));
            color:rgb(255, 52, 52);
            font-family: 'Helvetica Neue', sans-serif;
            overflow-x: hidden;
        }
        .app-title h1 {
            color:rgb(255, 26, 26);
            font-size: 32px;
            font-weight: 700;
            text-shadow: 0 3px 6px rgba(255, 31, 31, 0.98);
        }
        .app-breadcrumb .breadcrumb-item a {
            color: #f2c400;
        }
        .widget-small {
    border-radius: 8px;
    overflow: hidden;
    margin-bottom: 25px;
    transition: all 0.3s ease;
    background-color: #333;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);  /* Fixed */
}

        .widget-small:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 35px rgb(255, 0, 0);
        }
        .widget-small .info {
            padding: 25px;
            text-align: center;
            border-radius: 8px;
            background-color:rgb(226, 102, 102);
            position: relative;
        }
        .widget-small i {
            color: #f2c400;
            font-size: 50px;
            transition: all 0.3s ease;
        }
        .widget-small:hover i {
            color: #ff9933;
        }
        .widget-small .info h4 {
            font-size: 24px;
            margin-bottom: 12px;
            font-weight: 600;
            letter-spacing: 1px;
        }
        .widget-small .info p {
            font-size: 36px;
            font-weight: bold;
            color:rgb(255, 13, 0);
        }
        .row {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }
        .col-md-6, .col-lg-6 {
            flex: 1 1 calc(50% - 15px);
            margin-bottom: 25px;
        }
        .col-lg-6 {
            flex: 1 1 calc(50% - 15px);
        }
        /* Gradient Background for the page */
        .app-content {
            background: linear-gradient(135deg, rgba(13, 6, 6, 0.8), rgba(0, 0, 0, 0.8));
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.5);
        }
        .breadcrumb-item i {
            color:rgb(255, 208, 0);
        }
        
        h1 {
  color:rgb(255, 0, 0);
  text-shadow: 0 0 10px #00ffe0, 0 0 20px #00ffe0;
}

    </style>
</head>
<body class="app sidebar-mini rtl">
    <!-- Navbar-->
    <?php include 'include/header.php'; ?>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <?php include 'include/sidebar.php'; ?>
    <main class="app-content">
        <div class="app-title">
            <div>
            <h1 style="font-family: 'Orbitron', sans-serif; letter-spacing: 2px;">
  <i class="fa fa-dashboard"></i> 𝐃𝐀𝐒𝐇𝐁𝐎𝐀𝐑𝐃
</h1>


            </div>
            <ul class="app-breadcrumb breadcrumb">
                <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
                <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            </ul>
        </div>
        <div class="row">
            <!-- Listed Categories -->
            <div class="col-md-6 col-lg-6">
                <?php
                    $sql="SELECT count(id) as totalcat FROM tblcategory;";
                    $query= $dbh->prepare($sql);
                    $query-> execute();
                    $results = $query -> fetchAll(PDO::FETCH_OBJ);
                    foreach($results as $result)
                    {
                ?>
                    <a href="add-category.php">  
                    <div class="widget-small info coloured-icon">
                        <i class="icon fa fa-list-ul fa-3x"></i>
                        <div class="info">
                            <h4>Listed Categories</h4>
                            <p><b><?php echo $result->totalcat;?></b></p>
                        </div>
                    </div>
                    </a>
                <?php  } ?>
            </div>

            <!-- Listed Package Types -->
            <div class="col-md-6 col-lg-6">
                <?php
                    $sql="SELECT count(id) as totalpackagetype FROM tblcategory;";
                    $query= $dbh->prepare($sql);
                    $query-> execute();
                    $results = $query -> fetchAll(PDO::FETCH_OBJ);
                    foreach($results as $result)
                    {
                ?>
                    <a href="add-package.php">  
                    <div class="widget-small primary coloured-icon">
                        <i class="icon fa fa-cogs fa-3x"></i>
                        <div class="info">
                            <h4>Listed Package Type</h4>
                            <p><b><?php echo $result->totalpackagetype;?></b></p>
                        </div>
                    </div>
                    </a>
                <?php  } ?>
            </div>

            <!-- Listed Packages -->
            <div class="col-md-6 col-lg-6">
                <?php
                    $sql="SELECT count(id) as totalpost FROM tbladdpackage;";
                    $query= $dbh->prepare($sql);
                    $query-> execute();
                    $results = $query -> fetchAll(PDO::FETCH_OBJ);
                    $cnt=1;
                    if($query -> rowCount() > 0)
                    {
                    foreach($results as $result)
                    {
                ?>
                    <a href="manage-post.php">  
                    <div class="widget-small primary coloured-icon">
                        <i class="icon fa fa-gift fa-3x"></i>
                        <div class="info">
                            <h4>Listed Packages</h4>
                            <p><b><?php echo $result->totalpost;?></b></p>
                        </div>
                    </div>
                    </a>
                <?php  $cnt=$cnt+1; } } ?>
            </div>
      
            <!-- Total Bookings -->
            <div class="col-md-6 col-lg-6">
                <?php
                    $sql="SELECT count(id) as totalbookings FROM tblbooking;";
                    $query= $dbh->prepare($sql);
                    $query-> execute();
                    $results = $query -> fetchAll(PDO::FETCH_OBJ);
                    foreach($results as $result)
                    {
                ?>
                <a href="booking-history.php"> 
                    <div class="widget-small info coloured-icon">
                        <i class="icon fa fa-users fa-3x"></i>
                        <div class="info">
                            <h4>Total Bookings</h4>
                            <p><b><?php echo $result->totalbookings;?></b></p>
                        </div>
                    </div>
                </a>
                <?php  } ?>
            </div>

            <!-- New Bookings -->
            <div class="col-md-6 col-lg-6">
                <?php
                    $sql="SELECT count(id) as totalbookings FROM tblbooking where paymentType is null or paymentType=''";
                    $query= $dbh->prepare($sql);
                    $query-> execute();
                    $results = $query -> fetchAll(PDO::FETCH_OBJ);
                    foreach($results as $result)
                    {
                ?>
                <a href="new-bookings.php"> 
                    <div class="widget-small danger coloured-icon">
                        <i class="icon fa fa-clock fa-3x"></i>
                        <div class="info">
                            <h4>New Bookings</h4>
                            <p><b><?php echo $result->totalbookings;?></b></p>
                        </div>
                    </div>
                </a>
                <?php  } ?>
            </div>

            <!-- Partial Payment Bookings -->
            <div class="col-md-6 col-lg-6">
                <?php
                    $sql="SELECT count(id) as totalbookings FROM tblbooking where paymentType='Partial Payment'";
                    $query= $dbh->prepare($sql);
                    $query-> execute();
                    $results = $query -> fetchAll(PDO::FETCH_OBJ);
                    foreach($results as $result)
                    {
                ?>
                <a href="partial-payment-bookings.php"> 
                    <div class="widget-small warning coloured-icon">
                        <i class="icon fa fa-credit-card fa-3x"></i>
                        <div class="info">
                            <h4>Partial Payment Bookings</h4>
                            <p><b><?php echo $result->totalbookings;?></b></p>
                        </div>
                    </div>
                </a>
                <?php  } ?>
            </div>

            <!-- Full Payment Bookings -->
            <div class="col-md-6 col-lg-6">
                <?php
                    $sql="SELECT count(id) as totalbookings FROM tblbooking where paymentType='Full Payment'";
                    $query= $dbh->prepare($sql);
                    $query-> execute();
                    $results = $query -> fetchAll(PDO::FETCH_OBJ);
                    foreach($results as $result)
                    {
                ?>
                <a href="full-payment-bookings.php"> 
                    <div class="widget-small primary coloured-icon">
                        <i class="icon fa fa-check-circle fa-3x"></i>
                        <div class="info">
                            <h4>Full Payment Bookings</h4>
                            <p><b><?php echo $result->totalbookings;?></b></p>
                        </div>
                    </div>
                </a>
                <?php  } ?>
            </div>
        </div>
    </main>

    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
</body>
</html>
<style>body {
    background: linear-gradient(135deg, #1b1b1b, #2d2d2d);
    color: #f5f5f5; /* lighter text */
    font-family: 'Helvetica Neue', sans-serif;
    overflow-x: hidden;
}

.app-title h1,
.widget-small .info h4,
.widget-small .info p,
.breadcrumb-item a,
.breadcrumb-item i {
    color: #f5f5f5 !important; /* brighter white text for titles */
}

.widget-small .info {
    color: #e0e0e0;
}

a {
    color: #f5f5f5;
    text-decoration: none;
}

a:hover {
    color: #ffcc00;
}

.widget-small:hover i {
    color: #ffcc00;
}

.widget-small .info h4 {
    color: #ffffff;
}

.widget-small .info p {
    color: #f2c400;
}
</style>
<?php } ?>
