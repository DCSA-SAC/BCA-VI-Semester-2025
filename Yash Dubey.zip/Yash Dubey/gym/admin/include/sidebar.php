<aside class="gym-sidebar">
  <div class="sidebar-logo">
    <h2><i class="fas fa-dumbbell"></i> MARUTI <span>GYM</span></h2>
  </div>
  <ul class="sidebar-menu">
    <li><a href="index.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>

    <li class="has-submenu">
      <a href="#"><i class="fas fa-tags"></i><span>Category</span><i class="fas fa-chevron-right arrow"></i></a>
      <ul class="submenu">
        <li><a href="add-category.php">Add Category</a></li>
      </ul>
    </li>

    <li class="has-submenu">
      <a href="#"><i class="fas fa-box"></i><span>Package Type</span><i class="fas fa-chevron-right arrow"></i></a>
      <ul class="submenu">
        <li><a href="add-package.php">Add Package</a></li>
      </ul>
    </li>

    <li class="has-submenu">
      <a href="#"><i class="fas fa-dumbbell"></i><span>Package</span><i class="fas fa-chevron-right arrow"></i></a>
      <ul class="submenu">
        <li><a href="add-post.php">Add</a></li>
        <li><a href="manage-post.php">Manage</a></li>
      </ul>
    </li>

    <li class="has-submenu">
      <a href="#"><i class="fas fa-history"></i><span>Booking History</span><i class="fas fa-chevron-right arrow"></i></a>
      <ul class="submenu">
        <li><a href="new-bookings.php">New</a></li>
        <li><a href="partial-payment-bookings.php">Partial Payment</a></li>
        <li><a href="full-payment-bookings.php">Full Payment</a></li>
        <li><a href="booking-history.php">All</a></li>
      </ul>
    </li>

    <li class="has-submenu">
      <a href="#"><i class="fas fa-chart-line"></i><span>Report</span><i class="fas fa-chevron-right arrow"></i></a>
      <ul class="submenu">
        <li><a href="report-booking.php">Booking Report</a></li>
        <li><a href="report-registration.php">Registration Report</a></li>
      </ul>
    </li>
  </ul>
</aside>
<style>/* Sidebar Styles */
.gym-sidebar {
  width: 260px;
  background: #111;
  min-height: 100vh;
  padding-top: 20px;
  position: fixed;
  left: 0;
  top: 0;
  overflow-y: auto;
  box-shadow: 2px 0 12px rgba(0,0,0,0.7);
  z-index: 100;
}

/* Logo */
.sidebar-logo {
  text-align: center;
  color: #f39c12;
  font-size: 22px;
  margin-bottom: 20px;
  font-weight: bold;
  letter-spacing: 1px;
}
.sidebar-logo span {
  color: #fff;
}

/* Menu Styles */
.sidebar-menu {
  list-style: none;
  padding: 0;
  margin: 0;
}
.sidebar-menu li {
  border-bottom: 1px solid #222;
}
.sidebar-menu a {
  display: flex;
  align-items: center;
  padding: 14px 20px;
  color: #ddd;
  text-decoration: none;
  font-size: 16px;
  font-weight: 500;
  transition: all 0.3s ease;
}
.sidebar-menu a i {
  margin-right: 12px;
  font-size: 18px;
}
.sidebar-menu a:hover {
  background: #f39c12;
  color: #000;
}

/* Submenu */
.has-submenu .submenu {
  display: none;
  background: #1c1c1c;
}
.has-submenu:hover .submenu {
  display: block;
}
.submenu li a {
  padding-left: 45px;
  font-size: 14px;
  color: #ccc;
}
.submenu li a:hover {
  color: #000;
  background: #f39c12;
}

/* Arrow Icon */
.arrow {
  margin-left: auto;
  transition: transform 0.3s ease;
}
.has-submenu:hover .arrow {
  transform: rotate(90deg);
}
</style>