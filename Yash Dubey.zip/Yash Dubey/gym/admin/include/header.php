<header class="gym-header">
  <div class="logo-area">
    <a class="logo-text" href="index.php">🏋️‍♂️ 𝐌𝐀𝐑𝐔𝐓𝐈 <span>FITNESS</span></a>
  </div>
  <div class="nav-toggle">
    <a class="toggle-btn" href="#" data-toggle="sidebar" aria-label="Toggle Sidebar">
      <i class="fas fa-bars"></i>
    </a>
  </div>
  <ul class="nav-right">
    <li class="user-dropdown">
      <a href="#" class="user-link" data-toggle="dropdown">
        <span>Welcome, Admin</span> <i class="fas fa-user-circle fa-lg"></i>
      </a>
      <ul class="dropdown-menu">
        <li><a href="change-password.php"><i class="fas fa-key"></i> Change Password</a></li>
        <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
      </ul>
    </li>
  </ul>
</header>
<style>/* Gym Header Styles */
.gym-header {
  background: #111;
  color: #fff;
  padding: 15px 30px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.7);
  position: sticky;
  top: 0;
  z-index: 999;
}

/* Logo Area */
.logo-area .logo-text {
  font-size: 28px;
  font-weight: 900;
  color: #f39c12;
  text-decoration: none;
  letter-spacing: 1px;
  text-shadow: 2px 2px 5px #000;
  transition: transform 0.3s ease;
}

.logo-area .logo-text span {
  color: #fff;
  font-weight: 400;
}

.logo-area .logo-text:hover {
  transform: scale(1.05);
}

/* Sidebar Toggle */
.nav-toggle .toggle-btn {
  color: #f39c12;
  font-size: 22px;
  display: none;
}

@media (max-width: 768px) {
  .nav-toggle .toggle-btn {
    display: block;
  }
}

/* Right Navigation */
.nav-right {
  list-style: none;
  display: flex;
  align-items: center;
  gap: 20px;
}

.user-dropdown {
  position: relative;
}

.user-link {
  color: #fff;
  font-weight: 600;
  text-decoration: none;
  transition: color 0.3s ease;
}

.user-link:hover {
  color: #f39c12;
}

.user-link i {
  margin-left: 8px;
}

/* Dropdown Menu */
.dropdown-menu {
  position: absolute;
  right: 0;
  top: 45px;
  background-color: #222;
  border-radius: 6px;
  padding: 10px 0;
  box-shadow: 0 8px 16px rgba(0,0,0,0.5);
  display: none;
  min-width: 180px;
  z-index: 1000;
}

.user-dropdown:hover .dropdown-menu {
  display: block;
}

.dropdown-menu li {
  list-style: none;
}

.dropdown-menu a {
  display: block;
  padding: 10px 20px;
  color: #ddd;
  text-decoration: none;
  transition: background 0.3s, color 0.3s;
}

.dropdown-menu a:hover {
  background: #f39c12;
  color: #000;
}
</style>