<?php
session_start();
error_reporting(0);
require_once('include/config.php');
$msg = ""; 
if(isset($_POST['submit'])) {
  $email = trim($_POST['email']);
  $password = md5(($_POST['password']));
  if($email != "" && $password != "") {
    try {
      $query = "select id, name, email, mobile, password, create_date from tbladmin where email=:email and password=:password";
      $stmt = $dbh->prepare($query);
      $stmt->bindParam('email', $email, PDO::PARAM_STR);
      $stmt->bindValue('password', $password, PDO::PARAM_STR);
      $stmt->execute();
      $count = $stmt->rowCount();
      $row   = $stmt->fetch(PDO::FETCH_ASSOC);
      if($count == 1 && !empty($row)) {
        $_SESSION['adminid'] = $row['id'];
        $_SESSION['email'] = $row['email'];
        $_SESSION['name'] = $row['fname'];
        header("location: index.php");
      } else {
        $msg = "Invalid username and password!";
      }
    } catch (PDOException $e) {
      echo "Error: ".$e->getMessage();
    }
  } else {
    $msg = "Both fields are required!";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | FITNESS</title>
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/login-style.css">
  </head>
  <body>
    <div class="login-page">
      <div class="login-container">
        <div class="login-header">
          <h1>Admin Login</h1>
          <p>Strength, Fitness & Power</p>
        </div>
        <div class="login-box">
          <form method="post">
            <?php if($msg){ ?>
              <div class="alert"><?php echo htmlentities($msg); ?></div>
            <?php } ?>
            <div class="input-group">
              <label for="email">Email Address</label>
              <input type="email" class="form-input" name="email" id="email" placeholder="Enter your email" required>
            </div>
            <div class="input-group">
              <label for="password">Password</label>
              <input type="password" class="form-input" name="password" id="password" placeholder="Enter your password" required>
            </div>
            <div class="btn-container">
              <input type="submit" name="submit" value="Sign In" class="btn btn-primary">
            </div>
            <div class="footer-link">
              <a href="../index.php">Back to Home</a>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- JavaScript Libraries -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>

<style>
  /* Overall Body and Background */
  body {
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 0;
    background: linear-gradient(135deg, rgba(0, 0, 0, 0.7), rgba(1, 1, 1, 0.7)), url('images/gym-background.jpg');
    background-size: cover;
    background-position: center;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    overflow: hidden;
    animation: backgroundMove 15s ease-in-out infinite;
  }

  /* Keyframe for Background Animation */
  @keyframes backgroundMove {
    0% { background-position: center; }
    50% { background-position: right bottom; }
    100% { background-position: center; }
  }

  /* Login Page Wrapper */
  .login-page {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100%;
    position: absolute;
  }

  /* Container Box */
  .login-container {
    background: rgba(0, 0, 0, 0.8);
    padding: 40px 50px;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
    max-width: 500px;
    width: 100%;
    text-align: center;
    position: relative;
    animation: fadeIn 1.5s ease-out;
  }

  /* Header Style */
  .login-header h1 {
    font-size: 36px;
    font-weight: 700;
    color: #fff;
    margin-bottom: 15px;
    letter-spacing: 2px;
    text-transform: uppercase;
    text-shadow: 3px 3px 10px rgba(0, 0, 0, 0.6);
  }

  .login-header p {
    font-size: 18px;
    color: #ccc;
    margin-bottom: 40px;
    font-style: italic;
  }

  /* Input Fields */
  .input-group {
    margin-bottom: 25px;
    position: relative;
    animation: inputAnimation 0.8s ease-in-out;
  }

  .input-group input {
    width: 100%;
    padding: 15px;
    font-size: 18px;
    background: transparent;
    color: #fff;
    border: 2px solid rgba(255, 255, 255, 0.5);
    border-radius: 8px;
    outline: none;
    transition: all 0.3s ease;
  }

  .input-group input:focus {
    border: 2px solid #f39c12;
    box-shadow: 0 0 10px rgba(243, 156, 18, 0.5);
  }

  .input-group label {
    position: absolute;
    left: 15px;
    top: -10px;
    font-size: 16px;
    color: #f39c12;
    background-color: rgba(0, 0, 0, 0.5);
    padding: 0 5px;
    font-weight: 600;
  }

  /* Submit Button with Hover Effects */
  .btn-container {
    margin-top: 20px;
  }

  .btn {
    width: 100%;
    padding: 15px;
    font-size: 18px;
    color: #fff;
    background-color: #f39c12;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
  }

  .btn:hover {
    background-color: #e67e22;
    transform: scale(1.05);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
  }

  /* Alert Styling */
  .alert {
    color: #ff5c5c;
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 15px;
    animation: fadeAlert 2s ease-in-out;
  }

  /* Footer Link */
  .footer-link a {
    color: #fff;
    font-size: 14px;
    text-decoration: none;
    margin-top: 20px;
    display: block;
    transition: color 0.3s ease;
  }

  .footer-link a:hover {
    color: #f39c12;
  }

  /* Input Label and Button Animation */
  @keyframes inputAnimation {
    0% { opacity: 0; transform: translateY(20px); }
    100% { opacity: 1; transform: translateY(0); }
  }

  /* Alert Fade Animation */
  @keyframes fadeAlert {
    0% { opacity: 0; }
    100% { opacity: 1; }
  }

  /* Media Queries for responsiveness */
  @media (max-width: 768px) {
    .login-container {
      padding: 25px;
    }

    .login-header h1 {
      font-size: 30px;
    }

    .footer-link a {
      font-size: 12px;
    }
  }
</style>
