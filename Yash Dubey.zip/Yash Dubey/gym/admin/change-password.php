<?php
session_start();
error_reporting(0);
include 'include/config.php'; 
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
} else {
  // Code for change password
  if(isset($_POST['submit'])) {
    $password = md5($_POST['password']);
    $newpassword = md5($_POST['newpassword']);
    $email = $_SESSION['email'];

    $sql = "SELECT password FROM tbladmin WHERE email=:email and password=:password";
    $query = $dbh->prepare($sql);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->bindParam(':password', $password, PDO::PARAM_STR);
    $query->execute();
    $results = $query->fetchAll(PDO::FETCH_OBJ);

    if($query->rowCount() > 0) {
      $con = "update tbladmin set password=:newpassword where email=:email";
      $chngpwd1 = $dbh->prepare($con);
      $chngpwd1->bindParam(':email', $email, PDO::PARAM_STR);
      $chngpwd1->bindParam(':newpassword', $newpassword, PDO::PARAM_STR);
      $chngpwd1->execute();
      $msg = "Your Password was successfully changed!";
    } else {
      $error = "Your current password is not valid."; 
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Change Password</title>
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
      body {
        background: linear-gradient(to right, #1a1a1a, #121212);
        color: #f2f2f2;
        font-family: 'Segoe UI', sans-serif;
      }
      .app-content {
        padding: 30px;
        min-height: 100vh;
      }
      .tile {
        background-color: #1e1e1e;
        border-radius: 15px;
        padding: 30px;
        box-shadow: 0 0 20px rgba(0, 255, 150, 0.3);
        margin-bottom: 30px;
      }
      h3.tile-title {
        color: #00e676;
        font-weight: bold;
        text-shadow: 0 0 5px #00e676;
      }
      label {
        color: #ccc;
        font-weight: bold;
      }
      input[type="password"] {
        background-color: #2a2a2a;
        border: 1px solid #333;
        color: #fff;
        border-radius: 10px;
        padding: 10px;
        font-size: 16px;
        margin-top: 10px;
        transition: all 0.3s ease;
      }
      input[type="password"]:focus {
        background-color: #333;
        box-shadow: 0 0 8px #00e676;
        border-color: #00e676;
      }
      .btn-primary {
        background-color: #00e676;
        border-radius: 10px;
        color: #000;
        font-weight: bold;
        padding: 10px 20px;
        transition: background-color 0.3s ease;
      }
      .btn-primary:hover {
        background-color: #00c853;
      }
      .errorWrap {
        padding: 15px;
        margin: 0 0 20px 0;
        background-color: #d32f2f;
        border-left: 4px solid #b71c1c;
        color: #fff;
        border-radius: 10px;
        font-size: 16px;
      }
      .succWrap {
        padding: 15px;
        margin: 0 0 20px 0;
        background-color: #388e3c;
        border-left: 4px solid #2e7d32;
        color: #fff;
        border-radius: 10px;
        font-size: 16px;
      }
      .form-group {
        margin-bottom: 20px;
      }
    </style>
  </head>

  <body class="app sidebar-mini rtl">
    <!-- Include Header -->
    <?php include 'include/header.php'; ?>
    <!-- Sidebar Menu -->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <?php include 'include/sidebar.php'; ?>

    <main class="app-content">
      <div class="row">
        <div class="col-md-6">
          <div class="tile">
            <h3 class="tile-title">Change Password</h3>

            <!-- Display Success or Error Messages -->
            <?php if ($error) { ?>
              <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div>
            <?php } else if ($msg) { ?>
              <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div>
            <?php } ?>

            <div class="tile-body">
              <form class="row" method="post" onsubmit="return valid()">
                <div class="form-group col-md-12">
                  <label class="control-label">Old Password</label>
                  <input type="password" name="password" id="password" placeholder="Old Password" class="form-control" autocomplete="off" required>
                </div>
                <div class="form-group col-md-12">
                  <label class="control-label">New Password</label>
                  <input type="password" name="newpassword" id="newpassword" class="form-control" placeholder="New Password" autocomplete="off" required>
                </div>
                <div class="form-group col-md-12">
                  <label class="control-label">Confirm Password</label>
                  <input type="password" name="confirmpassword" id="confirmpassword" placeholder="Confirm Password" autocomplete="off" class="form-control" required>
                </div>
                <div class="form-group col-md-4 align-self-end">
                  <input type="submit" name="submit" id="submit" class="btn btn-primary" value="Submit">
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </main>

    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/plugins/pace.min.js"></script>

    <script type="text/javascript">
      function valid() {
        if (document.chngpwd.newpassword.value !== document.chngpwd.confirmpassword.value) {
          alert("New Password and Confirm Password do not match!");
          document.chngpwd.confirmpassword.focus();
          return false;
        }
        return true;
      }
    </script>
  </body>
</html>
<?php  ?>
