<?php
session_start();
error_reporting(0);
require_once('include/config.php');
if(strlen($_SESSION["adminid"])==0) {   
  header('location:login.php');
} else {

if(isset($_POST['submit'])) {
  $adminid = $_SESSION['adminid'];
  $name = $_POST['name'];
  $email = $_POST['email'];
  $mobile = $_POST['mobile'];

  $sql = "UPDATE tbladmin SET name=:name,email=:email,mobile=:mobile WHERE id=:adminid";
  $query = $dbh->prepare($sql);
  $query->bindParam(':name', $name, PDO::PARAM_STR);
  $query->bindParam(':email', $email, PDO::PARAM_STR);
  $query->bindParam(':mobile', $mobile, PDO::PARAM_STR);
  $query->bindParam(':adminid', $adminid, PDO::PARAM_STR);
  $query->execute();
  echo "<script>alert('Profile has been updated.');</script>";
  echo "<script> window.location.href = 'profile.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Profile</title>
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
      body {
        background: linear-gradient(45deg, #1d1d1d, #232323);
        font-family: 'Arial', sans-serif;
        color: #f4f4f4;
        overflow-x: hidden;
      }
      .app-content {
        padding: 40px;
        min-height: 100vh;
        transition: all 0.3s ease;
      }
      .tile {
        background-color: #222;
        padding: 30px;
        border-radius: 20px;
        box-shadow: 0 0 20px rgba(0, 255, 0, 0.4);
        margin-bottom: 30px;
        transition: all 0.3s ease;
      }
      h3.tile-title {
        font-size: 26px;
        font-weight: bold;
        color: #00e676;
        text-shadow: 0 0 5px #00e676;
        margin-bottom: 20px;
      }
      .form-group label {
        font-size: 16px;
        font-weight: bold;
        color: #ccc;
      }
      .form-control {
        background-color: #333;
        border: 1px solid #444;
        color: #fff;
        padding: 12px 15px;
        border-radius: 10px;
        font-size: 16px;
        width: 100%;
        margin-bottom: 20px;
        transition: all 0.3s ease;
      }
      .form-control:focus {
        background-color: #444;
        box-shadow: 0 0 8px #00e676;
        border-color: #00e676;
      }
      .btn-primary {
        background-color: #00e676;
        border-radius: 10px;
        color: #000;
        padding: 12px 20px;
        font-weight: bold;
        text-transform: uppercase;
        transition: all 0.3s ease;
      }
      .btn-primary:hover {
        background-color: #00c853;
      }
      .errorWrap {
        background-color: #d32f2f;
        color: #fff;
        padding: 15px;
        border-radius: 10px;
        border-left: 5px solid #c62828;
        margin-bottom: 20px;
        font-size: 16px;
      }
      .succWrap {
        background-color: #388e3c;
        color: #fff;
        padding: 15px;
        border-radius: 10px;
        border-left: 5px solid #2e7d32;
        margin-bottom: 20px;
        font-size: 16px;
      }
      .tile-body {
        padding-top: 20px;
      }
      .form-group input[readonly] {
        background-color: #333;
        cursor: not-allowed;
      }
      .tile-body form .form-group input,
      .tile-body form .form-group textarea {
        background-color: #333;
        color: #f4f4f4;
        border-radius: 8px;
      }
      .form-group {
        margin-bottom: 30px;
      }
      .form-group input, .form-group textarea {
        transition: all 0.3s ease;
      }
    </style>
  </head>

  <body class="app sidebar-mini rtl">
    <?php include 'include/header.php'; ?>
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <?php include 'include/sidebar.php'; ?>

    <main class="app-content">
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Profile</h3>
            <div class="tile-body">
              <form class="row" method="post">
                <?php 
                  $adminid = $_SESSION['adminid'];
                  $sql = "SELECT id, name, email, mobile, create_date FROM tbladmin WHERE id=:adminid";
                  $query = $dbh->prepare($sql);
                  $query->bindParam(':adminid', $adminid, PDO::PARAM_STR);
                  $query->execute();
                  $results = $query->fetchAll(PDO::FETCH_OBJ);
                  if($query->rowCount() > 0) {
                    foreach($results as $result) { ?>
                      <div class="form-group col-md-12">
                        <label class="control-label">Name</label>
                        <input class="form-control" type="text" name="name" id="name" placeholder="Enter your name" value="<?php echo $result->name;?>">
                      </div>
                      <div class="form-group col-md-12">
                        <label class="control-label">Email</label>
                        <input class="form-control" type="text" name="email" id="email" placeholder="Enter your email" value="<?php echo $result->email;?>" readonly>
                      </div>
                      <div class="form-group col-md-12">
                        <label class="control-label">Mobile No</label>
                        <input class="form-control" type="text" name="mobile" id="mobile" placeholder="Enter your Mobile" value="<?php echo $result->mobile;?>">
                      </div>
                      <div class="form-group col-md-12">
                        <label class="control-label">Regd. Date</label>
                        <input class="form-control" type="text" name="reg" id="reg" value="<?php echo $result->create_date;?>" readonly>
                      </div>
                      <div class="form-group col-md-4 align-self-end">
                        <input type="submit" id="submit" name="submit" value="Update" class="btn btn-primary">
                      </div>
                    <?php }
                  }
                ?>
              </form>
            </div>
          </div>
        </div>
      </div>
    </main>

    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/plugins/pace.min.js"></script>
  </body>
</html>

<?php } ?>
