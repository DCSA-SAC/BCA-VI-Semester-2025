<?php 
session_start();
error_reporting(0);
include 'include/config.php';
$uid=$_SESSION['uid'];

if(isset($_POST['submit']))
{ 
$pid=$_POST['pid'];


$sql="INSERT INTO tblbooking (package_id,userid) Values(:pid,:uid)";

$query = $dbh -> prepare($sql);
$query->bindParam(':pid',$pid,PDO::PARAM_STR);
$query->bindParam(':uid',$uid,PDO::PARAM_STR);
$query -> execute();
echo "<script>alert('Package has been booked.');</script>";
echo "<script>window.location.href='booking-history.php'</script>";

}

?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>FITNESS</title>
	<meta charset="UTF-8">
	<meta name="description" content="Ahana Yoga HTML Template">
	<meta name="keywords" content="yoga, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/nice-select.css"/>
	<link rel="stylesheet" href="css/magnific-popup.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>
	<link rel="stylesheet" href="css/animate.css"/>

	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="css/style.css"/>

</head>


<body>
	<!-- Page Preloder -->
	

	<!-- Header Section -->
	<?php include 'include/header.php';?>
	<!-- Header Section end -->

<!-- Contact Section -->
<section class="section contact" id="contact" style="background: #1d1d1d; padding: 80px 0; color: #fff;">
    <div class="container">
        <!-- Section Title -->
        <div class="section-title text-center" data-aos="fade-up">
            <p class="subtitle text-uppercase" style="font-size: 18px; letter-spacing: 2px; color: #ff4b2b;">Contact Us</p>
            <h2 class="text-light fw-bold" style="font-size: 3rem; letter-spacing: 1px;">Get In Touch</h2>
            <p class="lead text-muted mt-3" style="font-size: 18px; color: #ddd;"></p>
        </div>

        <!-- Contact Information -->
        <div class="contact-info row justify-content-center">
            <!-- Location Card -->
            <div class="col-md-4 col-sm-12">
                <div class="contact-card p-4 rounded shadow-lg" data-aos="fade-up" data-aos-delay="100" style="background: rgba(255, 255, 255, 0.1); border-radius: 10px;">
                    <div class="contact-icon mb-3">
                        <i class="ri-map-pin-line" style="font-size: 40px; color: #ff4b2b;"></i>
                    </div>
                    <h3 class="text-light" style="font-size: 1.5rem;">Our Location</h3>
                    <p class="text-muted">In front of Judicial Academy, BeoharBagh,
					Jabalpur, Madhya Pradesh 482001</p>
                    <p class="text-muted">Jabalpur</p>
                    <p class="text-muted">Madhya Pradesh, 482001</p>
                    <a href="https://maps.google.com" target="_blank" class="btn btn-outline-light mt-3" style="border: 2px solid #ff4b2b; color: #ff4b2b; font-size: 16px; padding: 10px 20px;">
                        <i class="ri-map-2-line"></i> View on Map
                    </a>
                </div>
            </div>

            <!-- Contact Info Card -->
            <div class="col-md-4 col-sm-12">
                <div class="contact-card p-4 rounded shadow-lg" data-aos="fade-up" data-aos-delay="200" style="background: rgba(255, 255, 255, 0.1); border-radius: 10px;">
                    <div class="contact-icon mb-3">
                        <i class="ri-phone-line" style="font-size: 40px; color: #ff4b2b;"></i>
                    </div>
                    <h3 class="text-light" style="font-size: 1.5rem;">Contact Info</h3>
                    <a href="tel:+918962689555" class="d-block text-muted" style="font-size: 18px; margin-top: 10px;">
                        <i class="ri-phone-fill"></i> +918103650717, +9178287 81672
                    </a>
                    <a href="mailto:infinitysalon@gmail.com" class="d-block text-muted" style="font-size: 18px; margin-top: 10px;">
                        <i class="ri-mail-fill"></i>marutifitness@gmail.com
                    </a>
                    <div class="social-links mt-3 text-center">
                        <a href="#" style="font-size: 25px; color: #ff4b2b; margin-right: 20px;"><i class="ri-facebook-fill"></i></a>
                        <a href="#" style="font-size: 25px; color: #ff4b2b; margin-right: 20px;"><i class="ri-instagram-line"></i></a>
                        <a href="#" style="font-size: 25px; color: #ff4b2b;"><i class="ri-whatsapp-line"></i></a>
                    </div>
                </div>
            </div>

            <!-- Working Hours Card -->
            <div class="col-md-4 col-sm-12">
                <div class="contact-card p-4 rounded shadow-lg" data-aos="fade-up" data-aos-delay="300" style="background: rgba(255, 255, 255, 0.1); border-radius: 10px;">
                    <div class="contact-icon mb-3">
                        <i class="ri-time-line" style="font-size: 40px; color: #ff4b2b;"></i>
                    </div>
                    <h3 class="text-light" style="font-size: 1.5rem;">Working Hours</h3>
                    <p class="text-muted"><i class="ri-calendar-line"></i>MONDAY - SATURDAY</p>
                    <p class="text-muted"><i class="ri-calendar-line"></i>05:00 AM - 11:00 PM</p>
                    <p class="text-muted"><i class="ri-calendar-line"></i> Sunday: Closed</p>
                    
                    <!-- Conditional Appointment Booking Button -->
                    <?php if (isset($_SESSION['user'])): ?>
                        <a href="book-appointment.php" class="btn btn-danger mt-3">
                            <i class="ri-calendar-line"></i> Book Appointment
                        </a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-danger mt-3">
                            <i class="ri-login-box-line"></i> Login to Book Now
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Style -->
<style>
    /* Custom Styles */
    .contact-card {
        transition: all 0.3s ease;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }

    .contact-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 30px rgba(0, 0, 0, 0.2);
    }

    .contact-icon {
        text-align: center;
        margin-bottom: 20px;
    }

    .social-links a:hover {
        color: #ff4b2b;
    }

    .btn-outline-light:hover {
        background-color: #ff4b2b;
        color: #fff;
    }

    .btn-danger {
        background-color: #ff4b2b;
        border: none;
    }

    .btn-danger:hover {
        background-color: #ff3a23;
    }
</style>

	<!-- Map Section Begin -->
<section class="map-section" style="position: relative; padding: 80px 0; background-color: #1a1a1a;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="section-title" data-aos="fade-up">
                    <p class="subtitle text-uppercase" style="font-size: 18px; letter-spacing: 2px; color: #ff4b2b;">Our Location</p>
                    <h2 class="text-light fw-bold" style="font-size: 3rem; letter-spacing: 1px;">Find Us On The Map</h2>
                    <p class="lead text-muted mt-3" style="color: #ddd;">Visit our fitness center for your fitness journey. Get directions below.</p>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <!-- Map Embed Section -->
            <div class="col-lg-8 col-md-10 col-sm-12" data-aos="fade-up" data-aos-delay="100" style="position: relative;">
                <div class="map-container" style="border-radius: 15px; overflow: hidden;">
                    <iframe 
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29343.658323312815!2d79.93303876794631!3d23.171758850786865!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3981af384e1ca7dd%3A0xf1d1ea51e7061e90!2smaruti%20fitness!5e0!3m2!1sen!2sin!4v1738422166448!5m2!1sen!2sin"
                        width="100%" height="450" style="border:0; border-radius: 15px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
                <div class="map-overlay" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
                    <img src="img/icon/location.png" alt="Location Icon" style="width: 50px; height: 50px; opacity: 0.8; animation: bounce 2s infinite;">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Map Section End -->

<!-- Style -->
<style>
    /* Adding a subtle effect on the location icon */
    @keyframes bounce {
        0% { transform: translate(-50%, -50%) scale(1); }
        50% { transform: translate(-50%, -50%) scale(1.1); }
        100% { transform: translate(-50%, -50%) scale(1); }
    }

    .map-container iframe {
        border-radius: 15px; /* Rounded corners */
    }

    .map-overlay img {
        width: 50px;
        height: 50px;
        animation: bounce 2s infinite; /* Animation effect */
    }
</style>

	

	<!-- Footer Section -->
	<?php include 'include/footer.php'; ?>
	<!-- Footer Section end -->

	<div class="back-to-top"><img src="img/icons/up-arrow.png" alt=""></div>

	<!-- Search model end -->

	<!--====== Javascripts & Jquery ======-->
	<script src="js/vendor/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.slicknav.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.nice-select.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/main.js"></script>

	</body>
</html>
