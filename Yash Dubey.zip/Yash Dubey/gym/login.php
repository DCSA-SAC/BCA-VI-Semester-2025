
<?php
session_start();
error_reporting(0);
require_once('include/config.php');
$msg = ""; 
if(isset($_POST['submit'])) {
  $email = trim($_POST['email']);
  $password = md5(($_POST['password']));
  if($email != "" && $password != "") {
    try {
      $query = "select id, fname, lname, email, mobile, password, address, create_date from tbluser where email=:email and password=:password";
      $stmt = $dbh->prepare($query);
      $stmt->bindParam('email', $email, PDO::PARAM_STR);
      $stmt->bindValue('password', $password, PDO::PARAM_STR);
      $stmt->execute();
      $count = $stmt->rowCount();
      $row   = $stmt->fetch(PDO::FETCH_ASSOC);
      if($count == 1 && !empty($row)) {
        /******************** Your code ***********************/
        $_SESSION['uid']   = $row['id'];
        $_SESSION['email'] = $row['email'];
        $_SESSION['name'] = $row['fname'];
       header("location: index.php");
      } else {
        $msg = "Invalid username and password!";
      }
    } catch (PDOException $e) {
      echo "Error : ".$e->getMessage();
    }
  } else {
    $msg = "Both fields are required!";
  }
}
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>FITNESS</title>
	<meta charset="UTF-8">
	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/nice-select.css"/>
	<link rel="stylesheet" href="css/magnific-popup.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>
	<link rel="stylesheet" href="css/animate.css"/>

	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="css/style.css"/>

</head>
<body>
	<!-- Page Preloder -->
	

	<!-- Header Section -->
	<?php include 'include/header.php';?>
	<!-- Header Section end -->

	                                                                              
	


	
<!-- Login Section Begin -->
<section class="login-section" style="background: linear-gradient(135deg, #0d0d0d, #1a1a1a); padding: 100px 0; position: relative;">
    <div class="container position-relative">
        <div class="row justify-content-center">
            <div class="col-lg-5">
                <div class="login-card">
                    <h2 class="login-title">MARUTI FITNESS</h2>
                    <p class="login-subtitle">Unleash the Beast Within</p>

                    <?php if($error){?>
                        <div class="errorWrap">ERROR: <?php echo htmlentities($error); ?> </div>
                    <?php } else if($msg){ ?>
                        <div class="succWrap">SUCCESS: <?php echo htmlentities($msg); ?> </div>
                    <?php } ?>

                    <form method="post" class="login-form mt-4">
                        <input type="text" name="email" id="email" placeholder="Email Address" required>
                        <input type="password" name="password" id="password" placeholder="Password" required>
                        <div class="btn-group">
                            <button type="submit" name="submit" class="btn-login">Login</button>
                            <a href="registration.php" class="btn-register">Join Now</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Login CSS -->
<style>
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@700&display=swap');

body {
    background-color: #0a0a0a;
}

.login-section {
    background: linear-gradient(135deg, #0a0a0a, #1a1a1a);
    color: #fff;
}

.login-card {
    background: #111;
    padding: 40px;
    border-radius: 20px;
    border: 2px solid #ff0055;
    box-shadow: 0 0 25px rgba(255, 0, 85, 0.2);
    text-align: center;
}

.login-title {
    font-family: 'Orbitron', sans-serif;
    font-size: 28px;
    font-weight: bold;
    color: #ff0055;
    text-shadow: 0 0 10px #ff0055;
    margin-bottom: 10px;
    letter-spacing: 2px;
}

.login-subtitle {
    font-size: 14px;
    color: #999;
    margin-bottom: 20px;
    font-style: italic;
}

.login-form input {
    width: 100%;
    padding: 14px;
    margin-bottom: 20px;
    border: none;
    border-radius: 10px;
    background-color: #1a1a1a;
    color: #fff;
    font-size: 16px;
    box-shadow: 0 0 10px #222;
    transition: 0.3s ease;
}

.login-form input:focus {
    outline: none;
    box-shadow: 0 0 10px #ff0055;
    background-color: #222;
}

.btn-group {
    display: flex;
    gap: 15px;
    justify-content: center;
    margin-top: 10px;
}

.btn-login, .btn-register {
    flex: 1;
    padding: 14px;
    font-size: 15px;
    font-weight: bold;
    border-radius: 30px;
    text-decoration: none;
    text-align: center;
    color: #fff;
    transition: 0.3s;
}

.btn-login {
    background: linear-gradient(135deg, #ff0055, #ff6600);
    box-shadow: 0 0 10px rgba(255, 0, 85, 0.5);
    border: none;
}

.btn-register {
    background: linear-gradient(135deg, #007991, #00c9a7);
    box-shadow: 0 0 10px rgba(0, 255, 200, 0.4);
    border: none;
}

.btn-login:hover,
.btn-register:hover {
    transform: scale(1.05);
    cursor: pointer;
}

.errorWrap, .succWrap {
    font-weight: bold;
    text-align: center;
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 15px;
}

.errorWrap {
    background-color: #330000;
    color: #ff4d4d;
    border: 1px solid #ff4d4d;
}

.succWrap {
    background-color: #003322;
    color: #00ff99;
    border: 1px solid #00ff99;
}
</style>



	<?php include 'include/footer.php'; ?>
	<!-- Footer Section end -->

	<div class="back-to-top"><img src="img/icons/up-arrow.png" alt=""></div>

	<!-- Search model end -->

	<!--====== Javascripts & Jquery ======-->
	<script src="js/vendor/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.slicknav.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.nice-select.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/main.js"></script>

	</body>
</html>
