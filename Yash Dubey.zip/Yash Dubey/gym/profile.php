<?php
session_start();
error_reporting(0);
require_once('include/config.php');
if(strlen( $_SESSION["uid"])==0)
    {   
header('location:login.php');
}
else{


if(isset($_POST['submit']))
{
$uid=$_SESSION['uid'];
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$city=$_POST['city'];
$state=$_POST['state'];
$address=$_POST['address'];
$sql="update tbluser set fname=:fname,lname=:lname,mobile=:mobile,city=:city,state=:state,address=:Address where id=:uid";
$query = $dbh->prepare($sql);
$query->bindParam(':fname',$fname,PDO::PARAM_STR);
$query->bindParam(':lname',$lname,PDO::PARAM_STR);
$query->bindParam(':mobile',$mobile,PDO::PARAM_STR);
$query->bindParam(':city',$city,PDO::PARAM_STR);
$query->bindParam(':state',$state,PDO::PARAM_STR);
$query->bindParam(':Address',$address,PDO::PARAM_STR);
$query->bindParam(':uid',$uid,PDO::PARAM_STR);
$query->execute();
//$msg="<script>toastr.success('Mobile info updated Successfully', {timeOut: 5000})</script>";
echo "<script>alert('Profile has been updated.');</script>";
echo "<script> window.location.href =profile.php;</script>";

}


 ?>
<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>FITNESS | User Profile</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/nice-select.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>

	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="css/style.css"/>

</head>
<body>
	<!-- Page Preloder -->
	

	<!-- Header Section -->
	<?php include 'include/header.php';?>
	<!-- Header Section end -->

	
	                                                                              
	<!-- Profile Page Top Section (🔥 Bawal Style 🔥) -->
<section class="page-top-section" style="position: relative; height: 350px; background: url('img/page-top-bg.jpg') center/cover no-repeat; display: flex; align-items: center; justify-content: center; overflow: hidden;">
    <!-- Dark Overlay -->
    <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.85); z-index: 1;"></div>

    <!-- Neon Border Glow Lines -->
    <div class="glow-border"></div>

    <div class="container text-center position-relative" style="z-index: 2;">
        <h1 class="profile-title">🔥 My Profile 🔥</h1>
        <p class="profile-subtitle">Manage your fitness journey like a pro</p>
    </div>
</section>

<!-- Custom CSS -->
<style>
.profile-title {
    font-size: 58px;
    color: #FF4E00;
    font-weight: bold;
    text-shadow: 0 0 15px rgba(255, 78, 0, 0.7), 0 0 30px rgba(255, 78, 0, 0.5);
    letter-spacing: 2px;
    animation: glowFade 3s infinite alternate;
}

.profile-subtitle {
    font-size: 18px;
    color: #ccc;
    margin-top: 10px;
    text-shadow: 0 0 5px rgba(255, 255, 255, 0.2);
}

@keyframes glowFade {
    from {
        text-shadow: 0 0 10px rgba(255, 78, 0, 0.6), 0 0 20px rgba(255, 78, 0, 0.3);
    }
    to {
        text-shadow: 0 0 25px rgba(255, 78, 0, 1), 0 0 40px rgba(255, 78, 0, 0.7);
    }
}

/* Optional Glow Border */
.glow-border {
    position: absolute;
    top: 15px;
    left: 15px;
    right: 15px;
    bottom: 15px;
    border: 2px solid rgba(255, 78, 0, 0.5);
    border-radius: 20px;
    box-shadow: 0 0 30px rgba(255, 78, 0, 0.4);
    z-index: 1;
    animation: pulseGlow 4s infinite alternate;
}

@keyframes pulseGlow {
    0% {
        box-shadow: 0 0 10px rgba(255, 78, 0, 0.3);
    }
    100% {
        box-shadow: 0 0 35px rgba(255, 78, 0, 0.8);
    }
}
</style>


	<!-- Contact Section -->
<section class="contact-page-section spad overflow-hidden" style="background: linear-gradient(135deg, #1f1f1f, #333); padding: 80px 0; position: relative;">
    <!-- Background Glow Effect -->
    <div class="background-glow" style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0, 0, 0, 0.7); z-index: 1;"></div>

    <div class="container">
        <div class="row">
            <div class="col-lg-2"></div>
            <div class="col-lg-8">
                <form class="singup-form contact-form" method="post" style="position: relative; z-index: 2;">
                    <h2 class="section-title text-center text-white mb-5">Update Your Profile</h2>
                    <div class="row">
                        <?php 
                        $uid=$_SESSION['uid'];
                        $sql ="SELECT id, fname, lname, email, mobile, password, address, state, city, create_date from tbluser where id=:uid ";
                        $query= $dbh -> prepare($sql);
                        $query->bindParam(':uid',$uid, PDO::PARAM_STR);
                        $query-> execute();
                        $results = $query -> fetchAll(PDO::FETCH_OBJ);
                        if($query->rowCount() > 0)
                        {
                        foreach($results as $result)
                        {?>	
                        <div class="col-md-6">
                            <input type="text" name="fname" id="fname" placeholder="First Name" autocomplete="off" value="<?php echo $result->fname;?>" class="custom-input">
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="lname" id="lname" placeholder="Last Name" autocomplete="off" value="<?php echo $result->lname;?>" class="custom-input">
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="email" id="email" placeholder="Your Email" autocomplete="off" value="<?php echo $result->email;?>" readonly class="custom-input">
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="mobile" id="mobile" placeholder="Mobile Number" autocomplete="off" value="<?php echo $result->mobile;?>" class="custom-input">
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="state" id="state" placeholder="State" autocomplete="off" value="<?php echo $result->state;?>" class="custom-input">
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="city" id="city" placeholder="City" autocomplete="off" value="<?php echo $result->city;?>" class="custom-input">
                        </div>
                        <div class="col-md-12">
                            <input type="text" name="address" id="address" placeholder="Address" autocomplete="off" value="<?php echo $result->address;?>" class="custom-input">
                        </div>
                        <div class="col-md-12">
                            <input type="submit" id="submit" name="submit" value="Update" class="site-btn sb-gradient">
                        </div>
                        <?php }} ?>
                    </div>
                </form>
            </div>
            <div class="col-lg-2"></div>
        </div>
    </div>
</section>

<!-- Custom CSS -->
<style>
.contact-page-section {
    background: linear-gradient(135deg, #212121, #333);
    border-radius: 12px;
    overflow: hidden;
    padding: 80px 0;
}

.section-title {
    font-size: 40px;
    font-weight: 700;
    color: #FF4E00;
    text-transform: uppercase;
    text-shadow: 0 0 20px rgba(255, 78, 0, 0.8), 0 0 40px rgba(255, 78, 0, 0.5);
    letter-spacing: 2px;
}

.custom-input {
    width: 100%;
    padding: 14px;
    margin-bottom: 18px;
    border: none;
    border-radius: 10px;
    background-color: rgba(255, 255, 255, 0.1);
    color: #fff;
    font-size: 16px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
    transition: all 0.3s ease;
}

.custom-input:focus {
    outline: none;
    box-shadow: 0 0 15px rgba(255, 78, 0, 0.7);
    background-color: rgba(255, 255, 255, 0.2);
}

.site-btn {
    padding: 12px 30px;
    font-size: 16px;
    background: linear-gradient(135deg, #ff4e00, #ec9f05);
    color: white;
    border: none;
    border-radius: 50px;
    box-shadow: 0 4px 20px rgba(255, 78, 0, 0.5);
    transition: all 0.3s ease;
    cursor: pointer;
}

.site-btn:hover {
    transform: scale(1.05);
    box-shadow: 0 4px 25px rgba(255, 78, 0, 0.6);
}

.background-glow {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    z-index: 1;
    box-shadow: 0 0 40px rgba(255, 78, 0, 0.4);
}
</style>

	<!-- Trainers Section end -->
<?php include 'include/footer.php'; ?>
	<!-- Footer Section end -->
	
	<div class="back-to-top"><img src="img/icons/up-arrow.png" alt=""></div>

	<!-- Search model -->
	
	<!-- Search model end -->

	<!--====== Javascripts & Jquery ======-->
	<script src="js/vendor/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.slicknav.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.nice-select.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/main.js"></script>

	</body>
</html>
 <?php } ?>

  <style>
.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #dd3d36;
    color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #5cb85c;
    color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
        </style>
