
Admin Credential
Username:marutifitness@gmail.com
Password: maruti@1234


Employer Credential
Username: john@test.com
Password: Test@123
or Register a new user