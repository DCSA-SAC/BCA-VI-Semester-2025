<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

require_once('db.php');

// Delete Event
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmt = $pdo->prepare("DELETE FROM events WHERE id = ?");
    $stmt->execute([$delete_id]);
    header("Location: manage_events.php");
    exit();
}

// Add New Event
if (isset($_POST['add_event'])) {
    $event_name = $_POST['title'];
    $event_date = $_POST['event_date'];
    $event_description = $_POST['description'];
    $event_type = $_POST['event_type'];
    $image = "";

    if ($_FILES['event_image']['name']) {
        $image_name = time() . "_" . $_FILES['event_image']['name'];
        $image_tmp = $_FILES['event_image']['tmp_name'];
        $image_path = "uploads/" . $image_name;
        move_uploaded_file($image_tmp, $image_path);
        $image = $image_name;
    }

    $stmt = $pdo->prepare("INSERT INTO events (event_name, event_date, event_description, event_image, event_type) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$event_name, $event_date, $event_description, $image, $event_type]);

    header("Location: manage_events.php");
    exit();
}

// Fetch Events
$stmt = $pdo->query("SELECT * FROM events ORDER BY event_date ASC");
$result = $stmt->fetchAll();

$local_events = array_filter($result, fn($e) => $e['event_type'] === 'local');
$other_events = array_filter($result, fn($e) => $e['event_type'] === 'other');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Events</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Manage Events</h2>
        <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>

        <form action="manage_events.php" method="POST" enctype="multipart/form-data" class="mt-4">
            <h3>Add New Event</h3>
            <div class="mb-3">
                <label>Event Title</label>
                <input type="text" name="title" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Event Date</label>
                <input type="date" name="event_date" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Description</label>
                <textarea name="description" class="form-control" required></textarea>
            </div>
            <div class="mb-3">
                <label>Event Type</label>
                <select name="event_type" class="form-control" required>
                    <option value="local">Local Gurudwara</option>
                    <option value="other">Other Gurudwara</option>
                </select>
            </div>
            <div class="mb-3">
                <label>Upload Event Image</label>
                <input type="file" name="event_image" class="form-control">
            </div>
            <button type="submit" name="add_event" class="btn btn-primary">Add Event</button>
        </form>

        <!-- Local Events -->
        <h3 class="mt-5">Local Gurudwara Events</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($local_events as $row) { ?>
                    <tr>
                        <td>
                            <?php if ($row['event_image']) { ?>
                                <img src="uploads/<?php echo $row['event_image']; ?>" width="80">
                            <?php } else { echo "No Image"; } ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['event_name']); ?></td>
                        <td><?php echo date("F j, Y", strtotime($row['event_date'])); ?></td>
                        <td><?php echo htmlspecialchars($row['event_description']); ?></td>
                        <td>
                            <a href="?delete_id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <!-- Other Events -->
        <h3 class="mt-5">Other Gurudwara Events</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($other_events as $row) { ?>
                    <tr>
                        <td>
                            <?php if ($row['event_image']) { ?>
                                <img src="uploads/<?php echo $row['event_image']; ?>" width="80">
                            <?php } else { echo "No Image"; } ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['event_name']); ?></td>
                        <td><?php echo date("F j, Y", strtotime($row['event_date'])); ?></td>
                        <td><?php echo htmlspecialchars($row['event_description']); ?></td>
                        <td>
                            <a href="?delete_id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
