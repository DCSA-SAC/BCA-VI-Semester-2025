<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['role'] !== 'superadmin') {
    die("<h3 class='text-danger text-center mt-5'>❌ Access Denied: You are not a Super Admin!</h3>");
}

require 'db.php';

// ✅ Add New Admin
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_admin'])) {
    $new_username = trim($_POST['new_username']);
    $new_password = password_hash($_POST['new_password'], PASSWORD_ARGON2ID);
    $new_role = $_POST['new_role'];

    $stmt = $pdo->prepare("INSERT INTO admin_users (username, password_hash, role) VALUES (?, ?, ?)");
    if ($stmt->execute([$new_username, $new_password, $new_role])) {
        header("Location: manage_admins.php?success=Admin added successfully!");
        exit;
    } else {
        $error = "❌ Failed to add admin. Try again!";
    }
}

// ✅ Delete Admin (Prevent deleting Super Admin)
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);

    $stmt = $pdo->prepare("SELECT role FROM admin_users WHERE id = ?");
    $stmt->execute([$delete_id]);
    $admin = $stmt->fetch();

    if ($admin && $admin['role'] !== 'super_admin') {
        $stmt = $pdo->prepare("DELETE FROM admin_users WHERE id = ?");
        $stmt->execute([$delete_id]);
        header("Location: manage_admins.php?success=Admin deleted successfully!");
        exit;
    } else {
        header("Location: manage_admins.php?error=You cannot delete a Super Admin!");
        exit;
    }
}

// ✅ Fetch All Admins
$stmt = $pdo->query("SELECT * FROM admin_users ORDER BY role DESC");
$admins = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Admins</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }
        .btn-danger {
            background-color: #dc3545;
            border: none;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
        .alert {
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="container mt-5">
        <h2 class="mb-4 text-center">Manage Admins</h2>
        
        <a href="dashboard.php" class="btn btn-secondary mb-3">Back</a>

        <!-- ✅ Success & Error Messages -->
        <?php if (isset($_GET['success'])) { ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($_GET['success']); ?></div>
        <?php } ?>
        <?php if (isset($_GET['error'])) { ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($_GET['error']); ?></div>
        <?php } ?>

        <!-- ✅ Add New Admin Form -->
        <form action="manage_admins.php" method="POST" class="mt-3 p-4 border rounded bg-light">
            <h4>Add New Admin</h4>
            <input type="text" name="new_username" class="form-control mb-2" placeholder="Username" required>
            <input type="password" name="new_password" class="form-control mb-2" placeholder="Password" required>
            <select name="new_role" class="form-control mb-2">
                <option value="admin">Admin</option>
                <option value="super_admin">Super Admin</option>
            </select>
            <button type="submit" name="add_admin" class="btn btn-primary w-100">Add Admin</button>
        </form>

        <!-- ✅ Display Existing Admins -->
        <h4 class="mt-5">Existing Admins</h4>
        <table class="table table-bordered mt-3">
            <thead class="table-dark">
                <tr>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($admins as $admin) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($admin['username']); ?></td>
                        <td><?php echo ucfirst(htmlspecialchars($admin['role'])); ?></td>
                        <td>
                            <?php if ($admin['role'] !== 'super_admin') { ?>
                                <a href="?delete_id=<?php echo $admin['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                            <?php } else { ?>
                                <span class="text-muted">Super Admin</span>
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
