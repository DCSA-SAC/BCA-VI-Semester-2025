<?php
include('db.php');

try {
    $localStmt = $pdo->prepare("SELECT * FROM events WHERE event_type = 'local' ORDER BY event_date ASC");
    $localStmt->execute();

    $otherStmt = $pdo->prepare("SELECT * FROM events WHERE event_type = 'other' ORDER BY event_date ASC");
    $otherStmt->execute();
} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events - Gurudwara Sahib</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .upcoming-title-bar {
            position: relative;
            height: 80px;
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            border-radius: 12px;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
            animation: slideInTitle 1.2s ease-out forwards;
            margin-bottom: 30px;
        }

        .upcoming-title-text {
            font-size: 2.5rem;
            font-weight: bold;
            color: white;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3);
            letter-spacing: 1.5px;
            transition: color 0.3s ease;
        }

        .upcoming-title-text:hover {
            color: #ffc107;
        }

        @keyframes slideInTitle {
            0% { transform: translateY(-100%); opacity: 0; }
            100% { transform: translateY(0); opacity: 1; }
        }

        .event-section-title {
            font-size: 24px;
            font-weight: 600;
            margin-top: 50px;
            margin-bottom: 25px;
            text-align: center;
            border-bottom: 1px solid #ccc;
            padding-bottom: 8px;
        }

        .event-card {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }

        .event-img {
            width: 300px;
            height: auto;
            object-fit: cover;
            border-radius: 4px;
            margin-right: 15px;
            cursor: pointer;
        }

        .event-details h5 {
            margin-bottom: 5px;
        }

        .event-details p {
            margin-bottom: 0;
        }

        .lightbox {
            display: none;
            position: fixed;
            z-index: 9999;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.9);
            justify-content: center;
            align-items: center;
        }

        .lightbox img {
            max-width: 90%;
            max-height: 80%;
        }

        .lightbox:target {
            display: flex;
        }

        /* Updated Visit Button */
        .visit-btn {
            background: linear-gradient(135deg, #ff7043, #64b5f6);
            color: white;
            padding: 12px 25px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease-in-out;
            text-transform: uppercase;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .visit-btn:hover {
            background: linear-gradient(135deg, #64b5f6, #ff7043);
            transform: scale(1.05);
            color: white;
        }

        .visit-btn i {
            font-size: 1.2rem; /* Icon size */
            margin-right: 10px;
        }

    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="Gurdwara.html">
            <img src="IMG/logo (2).png" alt="Gurudwara Logo" width="70" height="70" class="me-2">
            <span>Gurudwara Sahib Gorakhpur</span>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="Gurdwara.html">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="donation.php">Donate</a></li>
                <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
                <li class="nav-item"><a class="nav-link active" href="events.php">Events</a></li>
                <li class="nav-item"><a class="nav-link" href="facilities.php">Facilities</a></li>
                <li class="nav-item"><a class="nav-link" href="login.php">Admin</a></li>
                <li class="nav-item">
                    <a class="btn visit-btn" href="https://maps.app.goo.gl/N7oYKckGG2dKMoAP8">
                        <i class="fas fa-map-marker-alt"></i> Visit Gurdwara
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <div class="upcoming-title-bar">
        <div class="upcoming-title-text">Upcoming Events</div>
    </div>

    <!-- Local Events -->
    <div class="event-section-title">Our's Gurudwara Events</div>
    <?php while ($row = $localStmt->fetch(PDO::FETCH_ASSOC)) : ?>
        <div class="event-card">
            <?php if (!empty($row['event_image'])) : ?>
                <img src="uploads/<?= htmlspecialchars($row['event_image']) ?>" class="event-img" onclick="openLightbox(this.src)">
            <?php else: ?>
                <img src="no-image.jpg" class="event-img" alt="No image">
            <?php endif; ?>
            <div class="event-details">
                <h5><?= htmlspecialchars($row['event_name']) ?></h5>
                <p class="text-muted"><?= date("F j, Y", strtotime($row['event_date'])) ?></p>
                <p><?= htmlspecialchars($row['event_description']) ?></p>
            </div>
        </div>
    <?php endwhile; ?>

    <!-- Other Events -->
    <div class="event-section-title">Other Gurudwara Events</div>
    <?php while ($row = $otherStmt->fetch(PDO::FETCH_ASSOC)) : ?>
        <div class="event-card">
            <?php if (!empty($row['event_image'])) : ?>
                <img src="uploads/<?= htmlspecialchars($row['event_image']) ?>" class="event-img" onclick="openLightbox(this.src)">
            <?php else: ?>
                <img src="no-image.jpg" class="event-img" alt="No image">
            <?php endif; ?>
            <div class="event-details">
                <h5><?= htmlspecialchars($row['event_name']) ?></h5>
                <p class="text-muted"><?= date("F j, Y", strtotime($row['event_date'])) ?></p>
                <p><?= htmlspecialchars($row['event_description']) ?></p>
            </div>
        </div>
    <?php endwhile; ?>
</div>

<!-- Lightbox for Image Popup -->
<div class="lightbox" id="lightbox" onclick="this.style.display='none'">
    <img id="lightbox-img" src="">
</div>

<footer class="bg-dark text-white text-center py-3 mt-5">
    &copy; <?= date("Y") ?> Gurudwara Sahib. All rights reserved.
</footer>

<script>
    function openLightbox(src) {
        document.getElementById('lightbox-img').src = src;
        document.getElementById('lightbox').style.display = 'flex';
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
