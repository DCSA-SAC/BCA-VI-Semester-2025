<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Facilities</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <style>
    /* Navbar Styling */
    .navbar {
        background-color: #f7f7f7;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    }

    .navbar-brand img {
        border-radius: 50%;
    }

    .navbar-nav .nav-link {
        font-size: 18px;
        font-weight: 500;
        padding: 10px 15px;
        transition: color 0.3s ease-in-out;
    }

    .navbar-nav .nav-link:hover {
        color: #ff7043;
    }

    /* Visit Button */
    .visit-btn {
        background: linear-gradient(135deg, #ff7043, #64b5f6);
        color: white;
        padding: 12px 25px;
        font-size: 16px;
        font-weight: bold;
        border: none;
        border-radius: 30px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        transition: all 0.3s ease-in-out;
        text-transform: uppercase;
    }

    .visit-btn:hover {
        background: linear-gradient(135deg, #64b5f6, #ff7043);
        transform: scale(1.05);
        color: white;
    }

    /* Facility Cards */
    .facility-card {
        transition: transform 0.3s ease-in-out, box-shadow 0.3s ease;
    }
    .facility-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
    }
    .card-header {
        background-color: #ffcc80;
        font-size: 1.5rem;
        font-weight: bold;
        color:rgb(152, 43, 180);
    }
    .card-body {
        font-size: 1.1rem;
        line-height: 1.6;
    }
    .facility-title {
        color:rgb(209, 230, 50);
        font-size: 1.6rem;
    }
    .facility-section {
        background: #f1f8e9;
        padding: 30px 0;
        margin-top: 30px;
    }
    .facility-image {
        width: 100%;
        height: auto;
        border-radius: 8px;
    }
    .therapy-card {
        margin-bottom: 20px;
    }

    /* Facility Title Bar */
    .facility-title-bar {
        position: relative;
        height: 80px;
        background: linear-gradient(135deg, #f44336 0%, #ffeb3b 100%);
        border-radius: 12px;
        display: flex;
        justify-content: center;
        align-items: center;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        animation: slideInTitle 1.2s ease-out forwards;
        margin-bottom: 30px;
    }

    .facility-title-text {
        font-size: 2.5rem;
        font-weight: bold;
        color: white;
        text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3);
        letter-spacing: 1.5px;
        transition: color 0.3s ease;
    }

    .facility-title-text:hover {
        color: #ff9800;
    }

    @keyframes slideInTitle {
        0% { transform: translateY(-100%); opacity: 0; }
        100% { transform: translateY(0); opacity: 1; }
    }
  </style>
</head>
<body>
  
  <nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
      <a class="navbar-brand d-flex align-items-center" href="Gurdwara.html">
        <img src="IMG/logo (2).png" alt="Gurudwara Logo" width="70" height="70" class="me-2">
        <span>Gurudwara Sahib Gorakhpur</span>
      </a> 
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" 
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"><a class="nav-link" href="Gurdwara.html">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="donation.php">Donate</a></li>
          <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
          <li class="nav-item"><a class="nav-link" href="events.php">Events</a></li>
          <li class="nav-item"><a class="nav-link active" href="facilities.php">Facilities</a></li>
          <li class="nav-item"><a class="nav-link" href="login.php">Admin</a></li>
          <li class="nav-item">
            <a class="btn visit-btn" href="https://maps.app.goo.gl/N7oYKckGG2dKMoAP8">Visit Gurdwara</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="container mt-5">
    <!-- Title Bar for Facilities -->
    <div class="facility-title-bar">
        <div class="facility-title-text">Our Facilities</div>
    </div>

    <p class="text-center mb-4">We provide various services to our community to make their visit comfortable and enriching.</p>

    <div class="row facility-section">
      <div class="col-md-6 mb-4">
        <div class="card facility-card shadow-lg">
          <div class="card-header text-center">
            <i class="fas fa-medkit" style="font-size: 2rem; color: #28a745;"></i>
            <h4>Medical Facility</h4>
          </div>
          <div class="card-body">
            <p>
              Our Gurudwara provides a medical facility with qualified doctors. The medical center is equipped with basic medical supplies and 
              equipment for minor injuries and health issues.
            </p>
            
            <div class="therapy-card">
              <h5>Homeopathic Therapy</h5>
              <p>We offer Homeopathic treatments that are safe, natural, and effective for treating a wide range of ailments.</p>
              <img src="IMG/homo.jpg" alt="Homeopathy" class="facility-image">
            </div>

            <div class="therapy-card">
              <h5>Physiotherapy</h5>
              <p>Our physiotherapy department focuses on rehabilitation and pain management.</p>
              <img src="IMG/fizo.jpg" alt="Physiotherapy" class="facility-image">
            </div>

            <div class="therapy-card">
              <h5>Acupuncture Therapy</h5>
              <p>We offer acupuncture therapy to help manage chronic pain, reduce stress, and improve overall wellness.</p>
              <img src="IMG/acu.jpg" alt="Acupuncture" class="facility-image">
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6 mb-4">
        <div class="card facility-card shadow-lg">
          <div class="card-header text-center">
            <i class="fas fa-book-open" style="font-size: 2rem; color: #17a2b8;"></i>
            <h4>Library Facility</h4>
          </div>
          <div class="card-body">
            <p>
              Our Gurudwara is home to a peaceful and quiet library with a collection of religious books, literature, and historical texts.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
</html>
