 <!-- submit_donation.php -->
 <?php
    include('db.php');
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['donor_name'];
        $email = $_POST['email'];
        $amount = $_POST['amount'];
        $payment_method = $_POST['payment_method'];
        $transaction_id = $_POST['transaction_id'];
    
        $targetDir = "uploads/";
        $fileName = basename($_FILES["receipt_image"]["name"]);
        $targetFilePath = $targetDir . $fileName;
        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
    
        $allowTypes = array('jpg', 'png', 'jpeg', 'pdf');
        if (in_array($fileType, $allowTypes)) {
            if (move_uploaded_file($_FILES["receipt_image"]["tmp_name"], $targetFilePath)) {
                $stmt = $pdo->prepare("INSERT INTO donation_history (donor_name, email, amount, payment_method, transaction_id, receipt_image) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $email, $amount, $payment_method, $transaction_id, $fileName]);
                echo "Donation recorded successfully.";
            } else {
                echo "File upload failed.";
            }
        } else {
            echo "Invalid file type. Only JPG, JPEG, PNG & PDF are allowed.";
        }
    }
    ?>