-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2025 at 09:26 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin_panel`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('superadmin','admin') NOT NULL DEFAULT 'admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password_hash`, `role`) VALUES
(12, 'dj', '$argon2id$v=19$m=65536,t=4,p=1$bVl1NVhiTFc1N1UxT0R6OA$AmtaEnRDUpMjAn0bz2QKnkP9N1g1aN+9SAWpgLiyNB0', 'superadmin'),
(13, 'k', '$argon2id$v=19$m=65536,t=4,p=1$c0hBME1jL21FNGU3bmZHNQ$w363dBdWlKNJZZs0mP3lcfm9k6N98LutWdNvc7nMG+I', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `donation_details`
--

CREATE TABLE `donation_details` (
  `id` int(11) NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `account_number` varchar(50) NOT NULL,
  `ifsc_code` varchar(20) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `upi_id` varchar(100) NOT NULL,
  `qr_code` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donation_details`
--

INSERT INTO `donation_details` (`id`, `account_name`, `bank_name`, `account_number`, `ifsc_code`, `branch`, `upi_id`, `qr_code`) VALUES
(1, 'Gurudwara Sahib Trust', 'Punjab & Sind Bank', '1234567890', 'PSIB000XXXX', 'Napier Town,Jabalpur', '9827589935@psbpay', 'IMG/QR.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `donation_history`
--

CREATE TABLE `donation_history` (
  `id` int(11) NOT NULL,
  `donor_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `receipt_image` varchar(255) NOT NULL,
  `donation_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donation_history`
--

INSERT INTO `donation_history` (`id`, `donor_name`, `email`, `amount`, `payment_method`, `transaction_id`, `receipt_image`, `donation_date`) VALUES
(1, 'berbeb', 'fghj@gmail.com', 354.00, 'UPI', '135345326456456', 'images.jpg', '2025-02-27 22:14:12'),
(2, 'prashantbuti ', 'prob@gmail.com', 501.00, 'UPI', '1234567834', 'Screenshot_2024-10-15-22-03-27-031_com.done.faasos.jpg', '2025-02-28 06:42:13');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_description` text NOT NULL,
  `event_date` date NOT NULL,
  `event_image` varchar(255) NOT NULL,
  `event_type` varchar(20) DEFAULT 'local'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `event_name`, `event_description`, `event_date`, `event_image`, `event_type`) VALUES
(3, 'Celebrating NanakShahi Samat 557', 'The Nanakshahi calendar (Gurmukhi: ਨਾਨਕਸ਼ਾਹੀ, romanized: Nānakshāhī) is a tropical solar calendar used in Sikhism. It is based on the \"Barah Maha\" (Twelve Months), a composition composed by the Sikh gurus reflecting the changes in nature conveyed in the twelve-month cycle of the year..', '2025-03-13', 'event 14 march.jpg', 'local'),
(4, 'Shaheedi Diwas', 'Martyrdom Day of Guru Arjan Dev Ji is celebrated every year in between may and june day to commemorate the martyrdom of the 5th Sikh Guru, Guru Arjan Dev Ji. He gave up his life in 1606 in Lahore on the orders of the Mughal Emperor Jahangir. This day is celebrated in Sikhism for sacrifice, courage and protection of religion.', '2025-05-30', '1744742103_IMG-20250415-WA0016.jpg', 'local'),
(5, 'Vaisakhi', 'Vaisakhi, also known as Baisakhi, marks the first day of the month of Vaisakh and is traditionally celebrated annually on 13 April or sometimes 14 April. It is seen as a spring harvest celebration primarily in Punjab and Northern India. Whilst it is culturally significant as a festival of harvest, in many parts of India, Vaisakhi is also the date for the Indian Solar New Year. But to Sikhs this is not the new year as first of Chet month is celebrated as new year according to the Nanakshahi calendar', '2025-04-13', '1744742371_WhatsApp Image 2025-04-15 at 23.35.28_409f32ba.jpg', 'other');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `uploaded_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `file_name`, `uploaded_on`) VALUES
(7, 'IMG-20250415-WA0021.jpg', '2025-04-15 18:24:17'),
(8, 'IMG-20250415-WA0022.jpg', '2025-04-15 18:24:29'),
(9, 'IMG-20250415-WA0027.jpg', '2025-04-15 18:24:42'),
(10, 'IMG-20250415-WA0028.jpg', '2025-04-15 18:24:58'),
(11, 'IMG-20250415-WA0029.jpg', '2025-04-15 18:25:10'),
(13, 'IMG-20250415-WA0010.jpg', '2025-04-15 18:26:18'),
(14, 'IMG-20250415-WA0009.jpg', '2025-04-15 18:26:34'),
(15, 'IMG-20250415-WA0005.jpg', '2025-04-15 18:26:52'),
(16, 'IMG-20250415-WA0023.jpg', '2025-04-15 18:27:12'),
(17, 'IMG-20250415-WA0024.jpg', '2025-04-15 18:27:23'),
(18, 'IMG-20250415-WA0026.jpg', '2025-04-15 18:27:38'),
(19, 'IMG-20241124-WA0004.jpg', '2025-04-15 18:28:08'),
(20, 'IMG-20241124-WA0001.jpg', '2025-04-15 18:28:16'),
(21, 'IMG-20241124-WA0003.jpg', '2025-04-15 18:28:22'),
(22, 'IMG-20241124-WA0002.jpg', '2025-04-15 18:28:30'),
(23, 'IMG-20241124-WA0005.jpg', '2025-04-15 18:28:38');

-- --------------------------------------------------------

--
-- Table structure for table `translations`
--

CREATE TABLE `translations` (
  `id` int(11) NOT NULL,
  `lang_code` varchar(10) NOT NULL,
  `key_name` varchar(100) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `translations`
--

INSERT INTO `translations` (`id`, `lang_code`, `key_name`, `value`) VALUES
(1, 'en', 'title', 'Gurdwara Guru Nanak Darbar, Gorakhpur'),
(2, 'hi', 'title', 'गुरुद्वारा गुरु नानक दरबार, गोरखपुर'),
(3, 'pa', 'title', 'ਗੁਰਦੁਆਰਾ ਗੁਰੂ ਨਾਨਕ ਦਰਬਾਰ, ਗੋਰਖਪੁਰ'),
(4, 'en', 'description', 'Experience the peace and spirituality at our Gurudwara.'),
(5, 'hi', 'description', 'यहां शांति और आध्यात्मिकता का अनुभव करें।'),
(6, 'pa', 'description', 'ਇੱਥੇ ਸ਼ਾਂਤੀ ਅਤੇ ਆਧਿਆਤਮਿਕਤਾ ਦਾ ਅਨੁਭਵ ਕਰੋ।'),
(7, 'en', 'donate', 'Donate Now'),
(8, 'hi', 'donate', 'अभी दान करें'),
(9, 'pa', 'donate', 'ਹੁਣੇ ਦਾਨ ਕਰੋ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `donation_details`
--
ALTER TABLE `donation_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donation_history`
--
ALTER TABLE `donation_history`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_id` (`transaction_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `translations`
--
ALTER TABLE `translations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `donation_details`
--
ALTER TABLE `donation_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `donation_history`
--
ALTER TABLE `donation_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `translations`
--
ALTER TABLE `translations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
