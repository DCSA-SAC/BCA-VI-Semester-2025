<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

$admin_role = $_SESSION['role'] ?? 'admin';
$is_super_admin = ($admin_role === "superadmin");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(to right, #f8f9fa, #e3f2fd);
            font-family: 'Segoe UI', sans-serif;
        }
        .dashboard-header {
            background-color: #0d6efd;
            color: white;
            padding: 20px;
            border-radius: 0 0 10px 10px;
            text-align: center;
        }
        .card {
            border: none;
            transition: transform 0.2s ease-in-out;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }
        .superadmin-box {
            border: 2px solid #dc3545;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="#">Admin Panel</a>
        <div class="ms-auto">
            <a href="logout.php" class="btn btn-outline-light">Logout</a>
        </div>
    </div>
</nav>

<div class="container my-5">
    <div class="dashboard-header mb-4">
        <h2>Welcome, <?php echo ucfirst(htmlspecialchars($admin_role)); ?>!</h2>
        <p class="mb-0">Manage your website with ease</p>
    </div>

    <div class="row g-4">
        <!-- Donations -->
        <div class="col-md-6">
            <div class="card text-white bg-primary">
                <div class="card-body text-center">
                    <h5 class="card-title">Donations History</h5>
                    <p class="card-text">View and manage donation records</p>
                    <a href="admin_dona.php" class="btn btn-light">View Donations</a>
                </div>
            </div>
        </div>

        <!-- Events -->
        <div class="col-md-6">
            <div class="card text-dark bg-warning">
                <div class="card-body text-center">
                    <h5 class="card-title">Manage Events</h5>
                    <p class="card-text">Add or edit upcoming events</p>
                    <a href="manage_events.php" class="btn btn-dark">Manage Events</a>
                </div>
            </div>
        </div>

        <!-- Gallery -->
        <div class="col-md-6">
            <div class="card text-white bg-success">
                <div class="card-body text-center">
                    <h5 class="card-title">Manage Gallery</h5>
                    <p class="card-text">Upload images or videos</p>
                    <a href="manage_gallery.php" class="btn btn-light">Manage Gallery</a>
                </div>
            </div>
        </div>

        <!-- Super Admin Panel -->
        <?php if ($is_super_admin) { ?>
        <div class="col-md-6">
            <div class="card text-white bg-danger superadmin-box">
                <div class="card-body text-center">
                    <h5 class="card-title">Super Admin Panel</h5>
                    <p class="card-text">Manage other admin accounts</p>
                    <a href="manage_admins.php" class="btn btn-light">Manage Admins</a>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
