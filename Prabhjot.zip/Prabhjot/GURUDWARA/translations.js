const translations = {
    en: {
        title: "Gurudwara Guru Nanak Darbar, Gorakhpur",
        description: "Experience the peace and spirituality at our Gurudwara.",
        donate: "Donate Now",
        religious_title: "Religious Programs",
        daily_schedule: "Daily Schedule",
        morning_schedule: "Mornings (4:30AM to 8:30AM)",
        morning_program: `
            <li>Prakash Sri Guru Granth Sahib ji, 4:30 AM</li>
            <li>Nitnem 5:00 AM – 6:00 AM</li>
            <li>Paath Sukhmani Sahib 6:00 AM - 7:00 AM</li>
            <li>Kirtan Asa Di Var 7:00 AM – 8:30 AM</li>
        `,
        evening_schedule: "Evenings (6:00PM to 8:30PM)",
        evening_program: `
            <li>Paath Rehras Sahib and Katha – 6:00 PM – 7:00 PM</li>
            <li>Gurbani Kirtan 7:00 PM – 8:00 PM</li>
        `,
        visesh_title: "Visesh Programmes on  First Sunday Night of Month",
        visesh_program: "Sampuran Asa Di Var followed by Shabad Kirtan by well-known Ragi Jathas till 10:00 PM. Guru Ka Langar served thereafter."
    },
    hi: {
        title: "गुरुद्वारा गुरु नानक दरबार, गोरखपुर",
        description: "यहां शांति और आध्यात्मिकता का अनुभव करें।",
        donate: "अभी दान करें",
        religious_title: "धार्मिक कार्यक्रम",
        daily_schedule: "दैनिक कार्यक्रम",
        morning_schedule: "सुबह (4:30AM से 8:30AM तक)",
        morning_program: `
            <li>प्रकाश श्री गुरु ग्रंथ साहिब जी, 4:30 AM</li>
            <li>नितनेम 5:00 AM – 6:00 AM</li>
            <li>पाठ सुखमनी साहिब 6:00 AM - 7:00 AM</li>
            <li>कीर्तन आसा दी वार 7:00 AM – 8:30 AM</li>
        `,
        evening_schedule: "शाम (6:00PM से 8:30PM तक)",
        evening_program: `
            <li>पाठ रहरास साहिब और कथा – 6:00 PM – 7:00 PM</li>
            <li>गुरबानी कीर्तन 7:00 PM – 8:00 PM</li>
        `,
        visesh_title: "रविवार रात के विशेष कार्यक्रम",
        visesh_program: "संपूर्ण आसा दी वार के बाद प्रसिद्ध रागी जत्थों द्वारा शब्द कीर्तन रात 10:00 बजे तक। इसके बाद गुरु का लंगर परोसा जाता है।"
    },
    pa: {
        title: "ਗੁਰਦੁਆਰਾ ਗੁਰੂ ਨਾਨਕ ਦਰਬਾਰ, ਗੋਰਖਪੁਰ",
        description: "ਇੱਥੇ ਸ਼ਾਂਤੀ ਅਤੇ ਆਧਿਆਤਮਿਕਤਾ ਦਾ ਅਨੁਭਵ ਕਰੋ।",
        donate: "ਹੁਣੇ ਦਾਨ ਕਰੋ",
        religious_title: "ਧਾਰਮਿਕ ਪ੍ਰੋਗਰਾਮ",
        daily_schedule: "ਰੋਜ਼ਾਨਾ ਦਾ ਸ਼ਡੂਲ",
        morning_schedule: "ਸਵੇਰ (4:30AM ਤੋਂ 8:30AM)",
        morning_program: `
            <li>ਪਰਕਾਸ਼ ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ, 4:30 AM</li>
            <li>ਨਿਤਨੇਮ 5:00 AM – 6:00 AM</li>
            <li>ਪਾਠ ਸੁਖਮਨੀ ਸਾਹਿਬ 6:00 AM - 7:00 AM</li>
            <li>ਕੀਰਤਨ ਆਸਾ ਦੀ ਵਾਰ 7:30 AM – 8:30 AM</li>
        `,
        evening_schedule: "ਸ਼ਾਮ (6:30PM ਤੋਂ 7:45PM)",
        evening_program: `
            <li>ਪਾਠ ਰਹਰਾਸ ਸਾਹਿਬ ਅਤੇ ਕਥਾ – 6:30 PM – 7:00 PM</li>
            <li>ਗੁਰਬਾਨੀ ਕੀਰਤਨ 7:00 PM – 7:45 PM</li>
        `,
        visesh_title: "ਐਤਵਾਰ ਰਾਤ ਦੇ ਵਿਸ਼ੇਸ਼ ਪ੍ਰੋਗਰਾਮ",
        visesh_program: "ਸੰਪੂਰਣ ਆਸਾ ਦੀ ਵਾਰ ਤੋਂ ਬਾਅਦ ਪ੍ਰਸਿੱਧ ਰਾਗੀ ਜੱਥਿਆਂ ਵਲੋਂ ਸ਼ਬਦ ਕੀਰਤਨ 09:00PM ਤਕ। ਇਸ ਤੋਂ ਬਾਅਦ ਗੁਰੂ ਕਾ ਲੰਗਰ ਪੈਸ਼ ਕੀਤਾ ਜਾਂਦਾ ਹੈ।"
    }
};
