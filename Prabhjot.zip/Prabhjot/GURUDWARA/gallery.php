<?php
include('db.php');

$stmt = $pdo->query("SELECT file_name FROM gallery ORDER BY uploaded_on DESC");
$images = $stmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery - Gurudwara Sahib</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .title-bar {
            position: relative;
            height: 100px;
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            border-radius: 15px;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            animation: titleSlideIn 1.5s ease-out forwards; 
            margin-bottom: 30px;
        }

        .title-text {
            font-size: 3rem;
            font-weight: bold;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3); 
            letter-spacing: 2px;
            transition: color 0.3s ease-in-out;
        }

        .title-text:hover {
            color: #ffcc00; 
        }

        @keyframes titleSlideIn {
            0% {
                transform: translateX(100%);
            }
            100% {
                transform: translateX(0);
            }
        }

        .gallery-container { 
            display: flex; 
            flex-wrap: wrap; 
            gap: 15px; 
            justify-content: center; 
            opacity: 0; 
            animation: fadeIn 1s forwards; 
        }

        @keyframes fadeIn {
            to { opacity: 1; }
        }

        .gallery-item { 
            flex: 1 1 calc(33.333% - 30px); 
            border-radius: 10px; 
            overflow: hidden; 
            cursor: pointer; 
            transition: transform 0.3s ease, box-shadow 0.3s ease; 
        }

        .gallery-item img { 
            width: 100%; 
            height: 300px; 
            object-fit: cover; 
            border-radius: 10px; 
        }

        .gallery-item:hover { 
            transform: scale(1.05); 
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.3); 
        }

        @media (max-width: 768px) { 
            .gallery-item { 
                flex: 1 1 calc(50% - 30px); 
            } 
        }

        @media (max-width: 480px) { 
            .gallery-item { 
                flex: 1 1 100%; 
            } 
        }

        .lightbox { 
            display: none; 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%; 
            background: rgba(0, 0, 0, 0.9); 
            justify-content: center; 
            align-items: center; 
            flex-direction: column; 
            z-index: 9999; 
            overflow: hidden; 
        }

        .lightbox img { 
            max-width: 90%; 
            max-height: 90%; 
            border-radius: 10px; 
        }

        .lightbox .close { 
            position: absolute; 
            top: 20px; 
            right: 30px; 
            font-size: 30px; 
            color: white; 
            cursor: pointer; 
        }

        .lightbox .nav-btn { 
            position: absolute; 
            top: 50%; 
            transform: translateY(-50%); 
            font-size: 40px; 
            color: white; 
            background: none; 
            border: none; 
            cursor: pointer; 
            padding: 10px; 
        }

        .prev { left: 10px; }
        .next { right: 10px; }

        .navbar {
            background-color: #ffffff;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .navbar-brand img {
            border-radius: 50%;
        }

        .navbar-nav .nav-link {
            font-size: 18px;
            font-weight: 500;
            padding: 10px 15px;
            transition: color 0.3s ease-in-out;
        }

        .navbar-nav .nav-link:hover {
            color: #ff6600;
        }

        .visit-btn {
            background: linear-gradient(135deg, #ff7043, #64b5f6);
            color: white;
            padding: 12px 25px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease-in-out;
            text-transform: uppercase;
        }

        .visit-btn:hover {
            background: linear-gradient(135deg, #64b5f6, #ff7043);
            transform: scale(1.05);
            color: white;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="Gurdwara.html">
            <img src="IMG/logo (2).png" alt="Gurudwara Logo" width="70" height="70" class="me-2">
            <span>Gurudwara Sahib Gorakhpur</span>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="Gurdwara.html">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="donation.php">Donate</a></li>
                <li class="nav-item"><a class="nav-link active" href="gallery.php">Gallery</a></li>
                <li class="nav-item"><a class="nav-link" href="events.php">Events</a></li>
                <li class="nav-item"><a class="nav-link" href="facilities.php">Facilities</a></li>
                <li class="nav-item"><a class="nav-link" href="login.php">Admin</a></li>
                <li class="nav-item">
                    <a class="btn visit-btn" href="https://maps.app.goo.gl/N7oYKckGG2dKMoAP8">
                        <i class="fas fa-map-marker-alt"></i> Visit Gurdwara
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container my-5">
    <div class="title-bar">
        <div class="title-text">Gurudwara Gallery</div>
    </div>
    <div class="gallery-container">
        <?php foreach ($images as $index => $fileName) { ?>
            <div class="gallery-item" onclick="openLightbox(<?php echo $index; ?>)">
                <img src="uploads/<?php echo htmlspecialchars($fileName); ?>" alt="Gallery Image" loading="lazy">
            </div>
        <?php } ?>
    </div>
</div>

<div class="lightbox" id="lightbox">
    <span class="close" onclick="closeLightbox()">&times;</span>
    <button class="nav-btn prev" onclick="changeImage(-1)">&#10094;</button>
    <img id="lightbox-img" src="" alt="Gallery Image">
    <button class="nav-btn next" onclick="changeImage(1)">&#10095;</button>
</div>

<footer class="bg-dark text-white text-center py-3">
    <p>© 2025 Gurudwara Sahib. All rights reserved.</p>
</footer>

<script>
    let images = <?php echo json_encode($images); ?>;
    let currentIndex = 0;
    let lightboxImg = document.getElementById("lightbox-img");

    function openLightbox(index) {
        currentIndex = index;
        lightboxImg.src = "uploads/" + images[currentIndex];
        document.getElementById("lightbox").style.display = "flex";
    }

    function closeLightbox() {
        document.getElementById("lightbox").style.display = "none";
    }

    function changeImage(direction) {
        currentIndex += direction;
        if (currentIndex < 0) {
            currentIndex = images.length - 1;
        } else if (currentIndex >= images.length) {
            currentIndex = 0;
        }
        lightboxImg.src = "uploads/" + images[currentIndex];
    }

    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape") closeLightbox();
        if (event.key === "ArrowRight") changeImage(1);
        if (event.key === "ArrowLeft") changeImage(-1);
    });

    document.getElementById("lightbox").addEventListener("click", function (event) {
        if (event.target === this) closeLightbox();
    });
</script>

</body>
</html>
