<?php
include('db.php');

$stmt = $pdo->query("SELECT * FROM donations ORDER BY created_at DESC");
$donations = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Donations - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Donation Records</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Amount</th>
                    <th>Transaction ID</th>
                    <th>Screenshot</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($donations as $donation) { ?>
                    <tr>
                        <td><?php echo $donation['id']; ?></td>
                        <td><?php echo htmlspecialchars($donation['name']); ?></td>
                        <td><?php echo htmlspecialchars($donation['email']); ?></td>
                        <td>₹<?php echo number_format($donation['amount'], 2); ?></td>
                        <td><?php echo htmlspecialchars($donation['transaction_id']); ?></td>
                        <td>
                            <?php if ($donation['screenshot']) { ?>
                                <a href="<?php echo htmlspecialchars($donation['screenshot']); ?>" target="_blank">View</a>
                            <?php } else { ?>
                                No Screenshot
                            <?php } ?>
                        </td>
                        <td><?php echo $donation['created_at']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
