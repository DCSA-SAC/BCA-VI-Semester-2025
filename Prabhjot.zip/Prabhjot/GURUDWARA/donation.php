<?php
include('db.php');

// Fetch donation details from database
$stmt = $pdo->query("SELECT * FROM donation_details LIMIT 1");
$donation = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donate to Gurudwara Sahib</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
 body {
    font-family: 'Poppins', sans-serif;
    background-color: #f4f4f4;
    color: #333;
    margin: 0;
    padding: 0;
}
.navbar {
    background-color: #ffffff;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}
.navbar-brand img {
    border-radius: 50%;
}
.navbar-nav .nav-link {
    font-size: 18px;
    font-weight: 500;
    padding: 10px 15px;
    transition: color 0.3s ease-in-out;
}
.navbar-nav .nav-link:hover {
    color: #ff6600;
}
.visit-btn {
    background: linear-gradient(135deg, #007bff, #ff6600);
    color: white;
    padding: 12px 25px;
    font-size: 16px;
    font-weight: bold;
    border: none;
    border-radius: 30px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
    transition: all 0.3s ease-in-out;
    text-transform: uppercase;
}

.visit-btn:hover {
    background: linear-gradient(135deg, #ff6600, #007bff);
    transform: scale(1.05);
    color: white;
}
.banner {
    background: url('IMG/IMG-20241124-WA0001.jpg') center/cover no-repeat;
    padding: 200px 0;
    text-align: center;
    color: white;
    position: relative;
    box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.3);
}
.banner h1 {
    font-size: 48px;
    font-weight: bold;
    text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.5);
}
.khanda {
    width: 60px;
    height: auto;
    margin: 0 15px;
    filter: drop-shadow(0px 5px 5px rgba(0, 0, 0, 0.5));
}
.donation-uses {
    text-align: center;
    padding: 60px 20px;
    background: white;
    border-radius: 10px;
    box-shadow: 0px 5px 20px rgba(0, 0, 0, 0.1);
}
.donation-uses img {
    width: 100%;
    border-radius: 10px;
    transition: transform 0.3s ease;
}
.donation-uses img:hover {
    transform: scale(1.05);
}
.donation-uses p {
    font-size: 18px;
    font-weight: 500;
    margin-top: 10px;
}
.btn-donate {
    background: linear-gradient(to right, #ff8800, #ff5500);
    color: white;
    font-size: 20px;
    padding: 15px 30px;
    border-radius: 10px;
    transition: transform 0.3s ease, background 0.3s;
    font-weight: bold;
}
.btn-donate:hover {
    background: linear-gradient(to right, #e65c00, #cc2900);
    transform: scale(1.1);
}
form {
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.1);
}
form .form-label {
    font-weight: bold;
}
form input, form select {
    border-radius: 5px;
    padding: 10px;
    border: 1px solid #ccc;
}
form button {
    width: 100%;
    font-size: 18px;
}
.footer {
    background-color: #222;
    color: white;
    padding: 20px;
    text-align: center;
    font-size: 16px;
    margin-top: 50px;
}

    </style>
</head>
<body>
 
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container ">
            <a class="navbar-brand d-flex align-items-center" href="Gurdwara.html">
                <img src="IMG/logo (2).png" alt="Gurudwara Logo" width="70" height="70" class="me-2">
                <span>Gurudwara Sahib Gorakhpur</span>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" 
              aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="Gurdwara.html">Home</a></li>
                    <li class="nav-item"><a class="nav-link active" href="donation.php">Donate</a></li>
                    <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
                    <li class="nav-item"><a class="nav-link" href="events.php">Events</a></li>
                    <li class="nav-item"><a class="nav-link" href="facilities.php">Facilities</a></li>
                    <li class="nav-item"><a class="nav-link" href="login.php">Admin</a></li>
                    <li class="nav-item">
                        <a class="btn visit-btn" href="https://maps.app.goo.gl/N7oYKckGG2dKMoAP8">Visit Gurdwara</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <section class="banner">
        <div class="container">
            <h1><img src="IMG/khanda-khanda.jpg" alt="Khanda" class="khanda"> Donate for <img src="IMG/khanda-khanda.jpg" alt="Khanda" class="khanda"></h1>
            <h1> Gurdwara Sahib </h1>
        </div>
    </section>
    
    <div class="container donation-uses">
        <h2>How Your Donation Helps</h2>
        <div class="row mt-4">
            <div class="col-md-4">
                <img src="IMG/langar.jpg" alt="Langar">
                <p><strong>Langar Sewa:</strong> Providing free meals to the community.</p>
            </div>
            <div class="col-md-4">
                <img src="IMG/medic.jpeg" alt="Medical Assistance">
                <p><strong>Medical Assistance:</strong> Helping the needy with healthcare services.</p>
            </div>
            <div class="col-md-4">
                <img src="IMG/edu.jpg" alt="Education Aid">
                <p><strong>Education Aid:</strong> Supporting Sikh education and cultural programs.</p>
            </div>
        </div>
    </div>
    
    <div class="container text-center mt-5">
        <h2>Ways to Donate</h2>
        <button class="btn btn-donate mt-3" data-bs-toggle="collapse" data-bs-target="#bankDetails">Bank Transfer Details</button>
        <div id="bankDetails" class="collapse mt-3">
            <p><strong>Account Name:</strong> <?= $donation['account_name']; ?></p>
            <p><strong>Bank Name:</strong> <?= $donation['bank_name']; ?></p>
            <p><strong>Account Number:</strong> <?= $donation['account_number']; ?></p>
            <p><strong>IFSC Code:</strong> <?= $donation['ifsc_code']; ?></p>
            <p><strong>Branch:</strong> <?= $donation['branch']; ?></p>
        </div>
        
        <button class="btn btn-donate mt-3" data-bs-toggle="collapse" data-bs-target="#upiDetails">Donate via UPI</button>
        <div id="upiDetails" class="collapse mt-3">
            <img src="<?= $donation['qr_code']; ?>" alt="UPI QR Code" class="img-fluid mb-4" width="250">
            <p><strong>UPI ID:</strong> <?= $donation['upi_id']; ?></p>
        </div>
    </div>
    
    <br/>
    <div class="container mt-5">
        <h2 class="text-center">Submit Your Donation Details</h2>
        <p class="text-center">If you have donated via bank transfer or QR code, please fill the form below to confirm.</p>
        <form action="sub.php" method="POST" enctype="multipart/form-data" class="p-4 bg-light rounded">
            <div class="mb-3">
                <label class="form-label">Full Name</label>
                <input type="text" name="donor_name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Donation Amount</label>
                <input type="number" name="amount" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Payment Method</label>
                <select name="payment_method" class="form-control" required>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="UPI">UPI</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Transaction ID</label>
                <input type="text" name="transaction_id" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Upload Bank Receipt / UPI transaction_id Screenshot </label>
                <input type="file" name="receipt_image" class="form-control" accept="image/*" required>
            </div>
            <button type="submit" class="btn btn-donate">Submit Donation</button>
        </form>
    </div>
    
    <footer class="footer">
        <p>Copyright © Gurdwara Sahib 2024</p>
    </footer>
</body>
</html>
