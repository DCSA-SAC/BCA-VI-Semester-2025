function changeLanguage(lang) {
    document.querySelectorAll("[data-lang]").forEach(element => {
        let key = element.getAttribute("data-lang");
        if (translations[lang][key]) {
            element.innerHTML = translations[lang][key];
        }
    });
    localStorage.setItem("selectedLanguage", lang);
}
document.addEventListener("DOMContentLoaded", function () {
    let savedLanguage = localStorage.getItem("selectedLanguage") || "en";
    document.getElementById("languageSelect").value = savedLanguage;
    changeLanguage(savedLanguage);

    document.getElementById("languageSelect").addEventListener("change", function () {
        changeLanguage(this.value);
    });
});
