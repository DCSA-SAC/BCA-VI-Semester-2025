<?php
session_start();
require 'db.php';

// Check if any admin exists
$stmt = $pdo->query("SELECT COUNT(*) FROM admin_users");
$admin_count = $stmt->fetchColumn();

if ($admin_count > 0) {
    header("Location: login.php");
    exit;
}

// Handle registration
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_ARGON2ID);

    $stmt = $pdo->prepare("INSERT INTO admin_users (username, password_hash, role) VALUES (?, ?, 'superadmin')");
    $stmt->execute([$username, $password]);

    $_SESSION['admin_logged_in'] = true;
    $_SESSION['admin_id'] = $pdo->lastInsertId();
    $_SESSION['role'] = 'superadmin';

    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Super Admin Registration</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Super Admin Registration</h2>
        <form method="POST">
            <input type="text" name="username" class="form-control" placeholder="Username" required><br>
            <input type="password" name="password" class="form-control" placeholder="Password" required><br>
            <button type="submit" class="btn btn-primary">Register</button>
        </form>
        <p><a href="login.php">Already have an account? Login</a></p>
    </div>
</body>
</html>
