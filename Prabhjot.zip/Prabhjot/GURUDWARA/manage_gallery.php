<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

require_once('db.php'); // Use require_once to ensure the file is included only once

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["image"])) {
    $targetDir = "uploads/";
    $fileName = basename($_FILES["image"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];

    if (in_array($fileType, $allowedTypes)) {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
            $stmt = $pdo->prepare("INSERT INTO gallery (file_name) VALUES (?)");
            $stmt->execute([$fileName]);
            $success = "✅ Image uploaded successfully!";
        } else {
            $error = "❌ Error uploading image!";
        }
    } else {
        $error = "❌ Invalid file type! Only JPG, JPEG, PNG, and GIF allowed.";
    }
}

// Delete Image
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Fetch the file name before deleting
    $stmt = $pdo->prepare("SELECT file_name FROM gallery WHERE id = ?");
    $stmt->execute([$delete_id]);
    $row = $stmt->fetch();

    if ($row) {
        $filePath = "uploads/" . $row['file_name'];

        // Delete the file if it exists
        if (file_exists($filePath)) {
            unlink($filePath);
        }

        // Delete from database
        $stmt = $pdo->prepare("DELETE FROM gallery WHERE id = ?");
        $stmt->execute([$delete_id]);
        header("Location: manage_gallery.php");
        exit();
    }
}

// Fetch gallery images
$stmt = $pdo->query("SELECT * FROM gallery ORDER BY uploaded_on DESC");
$galleryImages = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Gallery - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

    <div class="container mt-5">
        <h2>Manage Gallery</h2>
        <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>

        <form action="manage_gallery.php" method="POST" enctype="multipart/form-data" class="mt-4">
            <h3>Upload New Image</h3>
            <div class="mb-3">
                <label>Select Image</label>
                <input type="file" name="image" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Upload</button>
        </form>

        <?php if (isset($success)) echo "<p class='text-success mt-3'>$success</p>"; ?>
        <?php if (isset($error)) echo "<p class='text-danger mt-3'>$error</p>"; ?>

        <h3 class="mt-5">Gallery Images</h3>
        <div class="row">
            <?php foreach ($galleryImages as $row) { ?>
                <div class="col-md-4 text-center mb-4">
                    <img src="uploads/<?php echo htmlspecialchars($row['file_name']); ?>" class="img-fluid rounded shadow" alt="Image">
                    <br>
                    <a href="?delete_id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm mt-2" onclick="return confirm('Are you sure you want to delete this image?');">Delete</a>
                </div>
            <?php } ?>
        </div>
    </div>

</body>
</html>
