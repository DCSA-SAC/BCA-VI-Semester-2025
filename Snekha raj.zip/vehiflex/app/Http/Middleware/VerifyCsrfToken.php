<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class VerifyCsrfToken
{
    /**
     * उन routes की list जिनको CSRF protection से exempt करना है
     */
    protected $except = [
        '/razorpay/payment-success',
        '/razorpay/update-payment-status',
    ];

    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        // अगर route exempt list में है तो CSRF check मत करो
        foreach ($this->except as $route) {
            if ($request->is($route)) {
                return $next($request);
            }
        }

        // अगर exempt नहीं है तो default CSRF check करो
        if ($request->hasSession() && $request->session()->token() !== $request->input('_token')) {
            abort(419, 'CSRF token mismatch.');
        }

        return $next($request);
    }
}
