<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str; // Add this at the top
use App\Models\Car;
use App\Models\Booking;
use Razorpay\Api\Api;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class BookingController extends Controller
{


    public function bookCar(Request $request)
    {
        $request->validate([
            'car_id' => 'required|exists:cars,id',
            'pick_point' => 'required',
            'drop_point' => 'required',
            'pick_lat' => 'required',
            'pick_lng' => 'required',
            'drop_lat' => 'required',
            'drop_lng' => 'required',
            'amount' => 'required|numeric|min:1',
        ]);

        $api = new Api(env('RAZORPAY_KEY'), env('RAZORPAY_SECRET'));

        $order = $api->order->create([
            'receipt' => uniqid(),
            'amount' => $request->amount * 100, // Razorpay amount in paisa
            'currency' => 'INR',
            'payment_capture' => 1 // Auto capture
        ]);

        $random_payment_id = 'PAY-' . strtoupper(Str::random(10)); // Generating random Payment ID

        $booking = Booking::create([
            'car_id' => $request->car_id,
            'user_id' => auth()->id(),
            'booking_date' => now(),
            'pick_point' => $request->pick_point,
            'drop_point' => $request->drop_point,
            'pick_lat' => $request->pick_lat,
            'pick_lng' => $request->pick_lng,
            'drop_lat' => $request->drop_lat,
            'drop_lng' => $request->drop_lng,
            'amount' => $request->amount,
            'payment_status' => 'pending',
            'razorpay_payment_id' => $random_payment_id, // Storing random payment ID
        ]);

        return response()->json([
            'booking_id' => $booking->id,
            'order_id' => $order->id,
            'amount' => $request->amount * 100,
            'key' => env('RAZORPAY_KEY'),
            'razorpay_payment_id' => $random_payment_id, // Returning generated payment ID
        ]);
    }

    // Handle successful payment
    public function paymentSuccess(Request $request)
    {
        $validated = $request->validate([
            'booking_id' => 'required|exists:bookings,id',
            'razorpay_payment_id' => 'required|string'
        ]);

        try {
            // Find the booking and update the payment status and Razorpay Payment ID
            $booking = Booking::where('id', $validated['booking_id'])->firstOrFail();
            $booking->update([
                'payment_status' => 'confirmed',
                'razorpay_payment_id' => $validated['razorpay_payment_id'], // Updating razorpay_payment_id
            ]);

            Log::info("Payment successful", [
                'booking_id' => $booking->id,
                'razorpay_payment_id' => $validated['razorpay_payment_id'],
            ]);

            return response()->json([
                'status' => 'success',
                'message' => 'Booking confirmed!',
            ], 200);

        } catch (Exception $e) {
            Log::error("Error updating booking after payment", ['error' => $e->getMessage()]);

            return response()->json([
                'status' => 'error',
                'message' => 'Payment confirmation failed.',
            ], 500);
        }
    }

}
