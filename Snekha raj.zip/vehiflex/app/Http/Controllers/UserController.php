<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index()
    {
        // Fetch the car details based on the carId


        // Return the view and pass the car details to the view
        return view('dashboard',);
    }
}
