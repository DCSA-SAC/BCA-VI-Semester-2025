<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {
        // Fetch the car details based on the carId


        // Return the view and pass the car details to the view
        return view('admin.index',);
    }
    public function CarManagement()
    {
        // Fetch the car details based on the carId


        // Return the view and pass the car details to the view
        return view('admin.car-management',);
    }
    public function ManagementDriver()
    {
        // Fetch the car details based on the carId


        // Return the view and pass the car details to the view
        return view('admin.manage-driver',);
    }
    public function ManagementBooking()
    {
        // Fetch the car details based on the carId


        // Return the view and pass the car details to the view
        return view('admin.manage-books',);
    }
}
