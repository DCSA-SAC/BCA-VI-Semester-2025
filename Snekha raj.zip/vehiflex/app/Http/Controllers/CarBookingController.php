<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\Car;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Razorpay\Api\Api;

class CarBookingController extends Controller
{
    public $price_per_km = 15;

    // Show car booking form
    public function book($carId)
    {
        // Fetch car details using the carId
        $car = Car::findOrFail($carId);

        // Fetch the Razorpay key from the environment
        $razorpayKey = env('RAZORPAY_KEY');

        // Fetch the user's name and email using Auth
        $userName = Auth::user()->name;
        $userEmail = Auth::user()->email;

        // Return the booking view with car details, Razorpay key, and user details
        return view('car.booking', compact('car', 'razorpayKey', 'userName', 'userEmail'));
    }

    // Handle car booking with payment
    public function bookCar(Request $request, $carId)
    {
        $request->validate([
            'pickPoint' => 'required|string',
            'dropPoint' => 'required|string',
            'bookingDate' => 'required|date|after_or_equal:today',
            'fareAmount' => 'required|numeric|min:1',
        ]);

        // Check car availability
        if (!Booking::isCarAvailable($carId, $request->bookingDate)) {
            session()->flash('error', 'This car is not available on the selected date.');
            return redirect()->back();
        }

        // Create Razorpay order for payment
        try {
            $api = new Api(env('RAZORPAY_KEY'), env('RAZORPAY_SECRET'));
            $order = $api->order->create([
                'amount' => $request->fareAmount * 100,  // Convert to paise
                'currency' => 'INR',
                'payment_capture' => 1,  // auto capture after successful payment
            ]);

            // Store Razorpay order ID and return view with payment form
            return view('car.payment', [
                'razorpayOrderId' => $order['id'],
                'amount' => $request->fareAmount * 100,  // Convert to paise
                'key' => env('RAZORPAY_KEY'),
                'name' => Auth::user()->name,
                'email' => Auth::user()->email,
                'pickPoint' => $request->pickPoint,
                'dropPoint' => $request->dropPoint,
                'bookingDate' => $request->bookingDate,
                'fareAmount' => $request->fareAmount,
            ]);
        } catch (\Exception $e) {
            session()->flash('error', 'Payment gateway error: ' . $e->getMessage());
            return redirect()->back();
        }
    }

    // Handle payment success
    // Handle payment success
    public function handlePaymentSuccess(Request $request, $carId)
    {
        $paymentId = $request->razorpay_payment_id;

        // Validate inputs
        $request->validate([
            'pickPoint' => 'required|string',
            'dropPoint' => 'required|string',
            'bookingDate' => 'required|date|after_or_equal:today',
            'fareAmount' => 'required|numeric|min:1',
        ]);

        // Create booking without payment
        $booking = Booking::create([
            'car_id' => $carId,
            'user_id' => Auth::id(),
            'booking_date' => $request->bookingDate,
            'pick_point' => $request->pickPoint,
            'drop_point' => $request->dropPoint,
            'pick_lat' => $request->pickLat,
            'pick_lng' => $request->pickLng,
            'drop_lat' => $request->dropLat,
            'drop_lng' => $request->dropLng,
            'amount' => $request->fareAmount,
            'payment_status' => 'Success',
            'razorpay_payment_id' => null,
        ]);

        session()->flash('success', 'Car booked successfully! Payment is pending.');
        return redirect()->route('home');
    }


    // Handle booking without payment
    public function bookWithoutPayment(Request $request, $carId)
    {
        // Validate inputs
        $request->validate([
            'pickPoint' => 'required|string',
            'dropPoint' => 'required|string',
            'bookingDate' => 'required|date|after_or_equal:today',
            'fareAmount' => 'required|numeric|min:1',
        ]);

        // Create booking without payment
        $booking = Booking::create([
            'car_id' => $carId,
            'user_id' => Auth::id(),
            'booking_date' => $request->bookingDate,
            'pick_point' => $request->pickPoint,
            'drop_point' => $request->dropPoint,
            'pick_lat' => $request->pickLat,
            'pick_lng' => $request->pickLng,
            'drop_lat' => $request->dropLat,
            'drop_lng' => $request->dropLng,
            'amount' => $request->fareAmount,
            'payment_status' => 'Pending',
            'razorpay_payment_id' => null,
        ]);

        session()->flash('success', 'Car booked successfully! Payment is pending.');
        return redirect()->route('home');
    }

    // Update fare based on distance
    public function updateFare(Request $request)
    {
        // Validate the distance input
        $request->validate([
            'distanceKm' => 'required|numeric|min:0',
        ]);

        // Calculate fare
        $fareAmount = max($request->distanceKm * $this->price_per_km, 1);
        return response()->json(['fareAmount' => $fareAmount]);
    }
}
