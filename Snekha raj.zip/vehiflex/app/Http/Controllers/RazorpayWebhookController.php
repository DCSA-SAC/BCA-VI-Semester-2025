<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Livewire\CarBooking;

class RazorpayWebhookController extends Controller
{
    public function handleWebhook(Request $request)
    {
        $carBooking = new CarBooking();
        return $carBooking->handleRazorpayWebhook($request);
    }
}
