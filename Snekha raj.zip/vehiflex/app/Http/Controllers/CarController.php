<?php

namespace App\Http\Controllers;

use App\Models\Car;
use App\Models\User;
use Illuminate\Http\Request;

class CarController extends Controller
{
    public function show($carId)
    {
        // Fetch the car details based on the carId
        $car = Car::findOrFail($carId);

        // Return the view and pass the car details to the view
        return view('car.details', compact('car'));
    }
    public function book($carId)
{
    // Fetch the car details based on the carId
    $car = Car::findOrFail($carId);

    // Check the car details


    // Fetch available drivers (users with the "driver" role) for the selected car
    $drivers = User::where('role', 'driver')
                    ->whereHas('cars', function ($query) use ($car) {
                        $query->where('car_id', $car->id);
                    })
                    ->get();

    // Check if the drivers are being fetched correctly


    // Fetch users (non-drivers) if needed (you can decide if you want to show users)
    $users = User::where('role', 'user')->get();

    // Check if the users are being fetched correctly


    // Return the view and pass car details, drivers, and users to the view
    return view('car.booking', compact('car', 'drivers', 'users'));
}

}
