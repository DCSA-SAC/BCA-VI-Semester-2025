<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Booking;
use Razorpay\Api\Api;
use Illuminate\Support\Facades\Session;

class PaymentController extends Controller
{
    public function initiatePayment($bookingId)
    {
        $booking = Booking::findOrFail($bookingId);
        $razorpayKey = config('services.razorpay.key');

        return view('car.payment', compact('booking', 'razorpayKey'));
    }

    public function paymentSuccess(Request $request)
    {
        $booking = Booking::findOrFail(Session::get('booking_id'));

        if ($request->has('razorpay_payment_id')) {
            $booking->update([
                'payment_status' => 'paid',
                'razorpay_payment_id' => $request->razorpay_payment_id,
            ]);

            session()->flash('success', 'Payment Successful! Your booking is confirmed.');
            return redirect()->route('home');
        }

        session()->flash('error', 'Payment failed! Please try again.');
        return redirect()->route('home');
    }
}
