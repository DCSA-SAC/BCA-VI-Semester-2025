<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\Booking;

class BookingList extends Component
{
    public function render()
    {
        // Paginate the bookings and pass to the view
        $bookings = Booking::with(['car', 'user'])->paginate(10);  // Adjust pagination as per your need

        return view('livewire.booking-list', compact('bookings'));
    }
}
