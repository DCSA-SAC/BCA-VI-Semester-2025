<?php

namespace App\Livewire;

use App\Models\Booking;
use App\Models\Car;
use App\Models\User;
use App\Models\CarDriver;
use Livewire\Component;

class ManageBookings extends Component
{
    public $bookings, $car_id, $user_id, $booking_id;
    public $cars;
    public $users;

    public function mount()
    {
        // Get all available cars and users with the driver role
        $this->cars = Car::all();
        $this->users = User::where('role', 'driver')->get();
    }

    public function assignCarToDriver()
    {
        $booking = Booking::find($this->booking_id);
        $car = Car::find($this->car_id);
        $user = User::find($this->user_id);

        if ($booking && $car && $user) {
            // If booking is not assigned, attach car and user (driver)
            if (!$booking->car_id) {
                $booking->car_id = $car->id;
                $booking->user_id = $user->id;
                $booking->save();

                // Use CarDriver model to create an entry in the pivot table
                CarDriver::create([
                    'car_id' => $car->id,
                    'user_id' => $user->id,
                ]);

                session()->flash('message', 'Car assigned to driver successfully!');
            } else {
                session()->flash('error', 'Booking already has an assigned car.');
            }
        } else {
            session()->flash('error', 'Please select valid car and driver.');
        }
    }

    // Delete a booking
    public function deleteBooking($booking_id)
    {
        $booking = Booking::find($booking_id);
        if ($booking) {
            $booking->delete();
            session()->flash('message', 'Booking deleted successfully.');
        }
    }

    public function render()
    {
        // Paginate bookings with car and user details using eager loading
        $this->bookings = Booking::with(['car', 'user'])->paginate(10); // Paginate bookings, 10 per page

        return view('livewire.manage-bookings');
    }
}
