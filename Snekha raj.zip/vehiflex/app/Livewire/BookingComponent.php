<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\Booking;
use App\Models\Car;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class BookingComponent extends Component
{
    public $car_id, $user_id, $booking_date, $pick_point, $drop_point;
    public $pick_lat, $pick_lng, $drop_lat, $drop_lng, $amount;
    public $payment_status = 'pending', $razorpay_payment_id;

    protected $rules = [
        'car_id' => 'required|exists:cars,id',
        'booking_date' => 'required|date',
        'pick_point' => 'required|string',
        'drop_point' => 'required|string',
        'amount' => 'required|numeric|min:1',
    ];

    public function bookCar()
    {
        $this->validate();

        // Check Car Availability
        if (!Booking::isCarAvailable($this->car_id, $this->booking_date)) {
            session()->flash('error', 'Car is not available for the selected date.');
            return;
        }

        // Store Booking
        $booking = Booking::create([
            'car_id' => $this->car_id,
            'user_id' => Auth::id(),
            'booking_date' => $this->booking_date,
            'pick_point' => $this->pick_point,
            'drop_point' => $this->drop_point,
            'pick_lat' => $this->pick_lat,
            'pick_lng' => $this->pick_lng,
            'drop_lat' => $this->drop_lat,
            'drop_lng' => $this->drop_lng,
            'amount' => $this->amount,
            'payment_status' => $this->payment_status,
        ]);

        // Store Booking ID in Session
        Session::put('booking_id', $booking->id);

        // Redirect to Payment
        return redirect()->route('razorpay.payment', $booking->id);
    }

    public function render()
    {
        $cars = Car::all();
        return view('livewire.booking-component', compact('cars'));
    }
}
