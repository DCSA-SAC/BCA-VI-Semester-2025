<?php

namespace App\Livewire;

use Livewire\Component;
use Livewire\WithFileUploads;
use App\Models\Car;

class CarManagement extends Component
{
    use WithFileUploads;

    public $car_id, $vehicle_name, $driver_name, $address, $vehicle_brand, $vehicle_registration_no, $vehicle_color;
    public $driver_phone, $driver_email, $aadhar_card, $car_registration_document, $price_per_km;
    public $thumb_image, $slide_images = [];
    public $isEditMode = false;

    protected $rules = [
        'vehicle_name' => 'required|string|max:255',
        'driver_name' => 'required|string|max:255',
        'address' => 'required|string|max:500',
        'vehicle_brand' => 'required|string|max:255',
        'vehicle_registration_no' => 'required|string|unique:cars,vehicle_registration_no',
        'vehicle_color' => 'required|string|max:50',
        'driver_phone' => 'required|string|max:15',
        'driver_email' => 'required|email|unique:cars,driver_email',
        'price_per_km' => 'required|numeric',
        'thumb_image' => 'nullable|image|max:2048',
        'slide_images.*' => 'nullable|image|max:2048',
        'aadhar_card' => 'nullable|file|max:2048',
        'car_registration_document' => 'nullable|file|max:2048',
    ];

    public function create()
    {
        $this->resetFields();
        $this->isEditMode = false;
    }

    public function edit($id)
    {
        $car = Car::findOrFail($id);
        $this->car_id = $car->id;
        $this->vehicle_name = $car->vehicle_name;
        $this->driver_name = $car->driver_name;
        $this->address = $car->address;
        $this->vehicle_brand = $car->vehicle_brand;
        $this->vehicle_registration_no = $car->vehicle_registration_no;
        $this->vehicle_color = $car->vehicle_color;
        $this->driver_phone = $car->driver_phone;
        $this->driver_email = $car->driver_email;
        $this->price_per_km = $car->price_per_km;
        $this->isEditMode = true;
    }

    public function save()
    {
        $this->validate();

        $carData = [
            'vehicle_name' => $this->vehicle_name,
            'driver_name' => $this->driver_name,
            'address' => $this->address,
            'vehicle_brand' => $this->vehicle_brand,
            'vehicle_registration_no' => $this->vehicle_registration_no,
            'vehicle_color' => $this->vehicle_color,
            'driver_phone' => $this->driver_phone,
            'driver_email' => $this->driver_email,
            'price_per_km' => $this->price_per_km,
        ];

        if ($this->thumb_image) {
            $carData['thumb_image'] = $this->thumb_image->store('cars', 'public');
        }

        if ($this->slide_images) {
            $carData['slide_images'] = json_encode(array_map(fn($img) => $img->store('cars', 'public'), $this->slide_images));
        }

        if ($this->aadhar_card) {
            $carData['aadhar_card'] = $this->aadhar_card->store('documents', 'public');
        }

        if ($this->car_registration_document) {
            $carData['car_registration_document'] = $this->car_registration_document->store('documents', 'public');
        }

        Car::updateOrCreate(['id' => $this->car_id], $carData);

        session()->flash('message', $this->car_id ? 'Car updated successfully.' : 'Car added successfully.');
        $this->resetFields();
    }

    public function delete($id)
    {
        Car::findOrFail($id)->delete();
        session()->flash('message', 'Car deleted successfully.');
    }

    public function resetFields()
    {
        $this->car_id = null;
        $this->vehicle_name = '';
        $this->driver_name = '';
        $this->address = '';
        $this->vehicle_brand = '';
        $this->vehicle_registration_no = '';
        $this->vehicle_color = '';
        $this->driver_phone = '';
        $this->driver_email = '';
        $this->price_per_km = '';
        $this->thumb_image = null;
        $this->slide_images = [];
        $this->aadhar_card = null;
        $this->car_registration_document = null;
    }

    public function render()
    {
        return view('livewire.car-management', ['cars' => Car::all()]);
    }
}
