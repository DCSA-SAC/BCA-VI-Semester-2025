<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\Car;
use App\Models\User;
use App\Models\CarDriver;

class AssignCarToDriver extends Component
{
    public $car_id;
    public $user_id;
    public $car_driver_id;
    public $cars;
    public $users;
    public $carDrivers;

    public function mount()
    {
        // Get available cars and users with the 'driver' role
        $this->cars = Car::all();
        $this->users = User::where('role', 'driver')->get();
        $this->carDrivers = CarDriver::with('car', 'user')->get();  // Fetch all car-driver assignments
    }

    public function loadCarDriver($car_driver_id)
    {
        $carDriver = CarDriver::find($car_driver_id);

        if ($carDriver) {
            $this->car_id = $carDriver->car_id;
            $this->user_id = $carDriver->user_id;
            $this->car_driver_id = $carDriver->id;  // Set the assignment ID
        }
    }

    public function assignCar()
    {
        if (!$this->car_id || !$this->user_id) {
            session()->flash('error', 'Please select both a car and a driver.');
            return;
        }

        // Check if we are updating an existing assignment or creating a new one
        if ($this->car_driver_id) {
            // Update the existing car-driver assignment
            $carDriver = CarDriver::find($this->car_driver_id);
            if ($carDriver) {
                $carDriver->update([
                    'car_id' => $this->car_id,
                    'user_id' => $this->user_id,
                ]);
                session()->flash('message', 'Car-driver assignment updated successfully!');
            } else {
                session()->flash('error', 'Assignment not found.');
            }
        } else {
            // Check if the car is already assigned to another driver
            $existingAssignment = CarDriver::where('car_id', $this->car_id)->first();
            if ($existingAssignment) {
                session()->flash('error', 'This car is already assigned to another driver.');
                return;
            }

            // Create a new car-driver assignment
            CarDriver::create([
                'car_id' => $this->car_id,
                'user_id' => $this->user_id,
            ]);
            session()->flash('message', 'Car assigned to driver successfully!');
        }

        // Refresh the list of assignments after the action
        $this->carDrivers = CarDriver::with('car', 'user')->get();
    }

    public function render()
    {
        return view('livewire.assign-car-to-driver');
    }
}
