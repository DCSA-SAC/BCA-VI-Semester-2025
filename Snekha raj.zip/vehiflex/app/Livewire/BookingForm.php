<?php

namespace App\Livewire;

use App\Models\Car;
use App\Models\User;
use App\Models\CarDriver;
use Livewire\Component;
use App\Models\Booking;
use Illuminate\Support\Facades\Auth;

class BookingForm extends Component
{
    public $user_id;
    public $car_driver_id;
    public $pickup_date;
    public $pickup_location;
    public $drop_location;
    public $car_id;  // Property to hold selected car ID

    public function mount()
    {
        // Automatically assign the authenticated user's ID
        $this->user_id = Auth::id();

        // Automatically set the first car and its driver from the user's car relationship
        $user = Auth::user();

        if ($user && $user->cars()->exists()) {
            $car = $user->cars()->first(); // Get the first car associated with the user
            $this->car_id = $car->id;

            // Fetch the car's driver using the CarDriver model
            $carDriver = $car->carDrivers()->where('role', 'driver')->first();
            $this->car_driver_id = $carDriver ? $carDriver->user->id : null;
        }
    }

    public function render()
    {
        // Fetch available cars (this will be filtered based on user's relationship with cars)
        $cars = Auth::user()->cars; // Only show cars that the authenticated user is associated with
        return view('livewire.booking-form', compact('cars'));
    }

    public function updatedCarId($carId)
    {
        // When the car is updated, auto-fill the driver based on the selected car using the CarDriver model
        $car = Car::find($carId);

        if ($car) {
            // Get the car's driver via the CarDriver model
            $carDriver = $car->carDrivers()->where('role', 'driver')->first();
            $this->car_driver_id = $carDriver ? $carDriver->user->id : null;
        }
    }

    public function submitBooking()
    {
        // Validate the form inputs
        $this->validate([
            'user_id' => 'required|exists:users,id',
            'car_driver_id' => 'required|exists:users,id', // Validate against User model for the driver
            'pickup_date' => 'required|date',
            'pickup_location' => 'required|string|max:255',
            'drop_location' => 'required|string|max:255',
        ]);

        // Ensure car has an assigned driver
        $car = Car::find($this->car_id);
        if (!$car) {
            session()->flash('error', 'Selected car not found.');
            return;
        }

        $carDriver = $car->carDrivers()->where('role', 'driver')->first();
        if (!$carDriver) {
            session()->flash('error', 'No driver assigned to this car.');
            return;
        }

        // Create a new booking
        Booking::create([
            'user_id' => $this->user_id,
            'car_driver_id' => $this->car_driver_id,  // Driver from car relation
            'pickup_date' => $this->pickup_date,
            'pickup_location' => $this->pickup_location,
            'drop_location' => $this->drop_location,
        ]);

        // Flash success message
        session()->flash('message', 'Booking created successfully!');
    }
}
