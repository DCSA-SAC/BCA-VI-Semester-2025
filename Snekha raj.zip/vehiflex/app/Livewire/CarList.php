<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\Car;

class CarList extends Component
{
    public function render()
    {
        // Fetch cars from the database
        $cars = Car::all();

        return view('livewire.car-list', compact('cars'));
    }
}
