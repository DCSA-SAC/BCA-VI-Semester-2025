<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\Booking;
use App\Models\Car;
use Illuminate\Support\Facades\Auth;
use Razorpay\Api\Api;

class CarBooking extends Component
{
    public $carId;
    public $pickPoint, $dropPoint;
    public $pickLat, $pickLng, $dropLat, $dropLng;
    public $bookingDate;
    public $amount = 0, $fareAmount = 0;
    public $paymentStatus = 'Pending', $razorpayOrderId, $razorpayPaymentId;
    public $price_per_km = 15;

    protected $listeners = ['paymentSuccess' => 'handlePaymentSuccess'];


    public function paymentSuccess($paymentId)
    {
        // Logic to handle payment success, e.g., mark booking as paid
        $this->emit('paymentVerified', $paymentId);
    }


    public function boot()
    {
        $this->dispatch('livewireLoaded');

    }

    public function mount($carId)
    {
        $this->carId = $carId;
        $this->pickLat = 0;
        $this->pickLng = 0;
        $this->dropLat = 0;
        $this->dropLng = 0;
        $this->fareAmount = 0;
    }

    public function bookCar()
    {
        $this->validate([
            'pickPoint' => 'required|string',
            'dropPoint' => 'required|string',
            'bookingDate' => 'required|date|after_or_equal:today',
            'fareAmount' => 'required|numeric|min:1',
        ]);

        if (!Booking::isCarAvailable($this->carId, $this->bookingDate)) {
            session()->flash('error', 'This car is not available on the selected date.');
            return;
        }

        try {
            $api = new Api(env('RAZORPAY_KEY'), env('RAZORPAY_SECRET'));
            $order = $api->order->create([
                'amount' => $this->fareAmount * 100,
                'currency' => 'INR',
                'payment_capture' => 1,
            ]);

            $this->razorpayOrderId = $order['id'];

            // Use dispatch instead of dispatchBrowserEvent for Livewire v3
            $this->dispatch('initiatePayment', [
                'order_id' => $this->razorpayOrderId,
                'amount' => $this->fareAmount * 100,
                'key' => env('RAZORPAY_KEY'),
                'name' => Auth::user()->name,
                'email' => Auth::user()->email,
            ]);
        } catch (\Exception $e) {
            session()->flash('error', 'Payment gateway error: ' . $e->getMessage());
        }
    }


    public function handlePaymentSuccess($paymentId)
    {
        if (!$paymentId) {
            session()->flash('error', 'Payment failed. Try again.');
            return;
        }

        $this->razorpayPaymentId = $paymentId;
        $this->paymentStatus = 'Paid';

        Booking::create([
            'car_id' => $this->carId,
            'user_id' => Auth::id(),
            'booking_date' => $this->bookingDate,
            'pick_point' => $this->pickPoint,
            'drop_point' => $this->dropPoint,
            'pick_lat' => $this->pickLat,
            'pick_lng' => $this->pickLng,
            'drop_lat' => $this->dropLat,
            'drop_lng' => $this->dropLng,
            'amount' => $this->fareAmount,
            'payment_status' => $this->paymentStatus,
            'razorpay_payment_id' => $this->razorpayPaymentId,
        ]);

        session()->flash('success', 'Car booked successfully!');
    }

    public function bookWithoutPayment()
    {
        Booking::create([
            'car_id' => $this->carId,
            'user_id' => Auth::id(),
            'booking_date' => $this->bookingDate,
            'pick_point' => $this->pickPoint,
            'drop_point' => $this->dropPoint,
            'pick_lat' => $this->pickLat,
            'pick_lng' => $this->pickLng,
            'drop_lat' => $this->dropLat,
            'drop_lng' => $this->dropLng,
            'amount' => $this->fareAmount,
            'payment_status' => 'Pending',
            'razorpay_payment_id' => null,
        ]);

        session()->flash('success', 'Car booked successfully! Payment is pending.');
    }

    public function updateFare($distanceKm)
    {
        $this->fareAmount = max($distanceKm * 15, 1); // Ensures minimum fare is 1
    }
    public function saveBooking()
    {
        // Logic to save the booking with the coordinates
        Booking::create([
            'pick_lat' => $this->pickLat,
            'pick_lng' => $this->pickLng,
            'drop_lat' => $this->dropLat,
            'drop_lng' => $this->dropLng,
            'fare_amount' => $this->fareAmount,
            'pick_point' => $this->pickPoint,
            'drop_point' => $this->dropPoint,
            'booking_date' => $this->bookingDate,
        ]);

        session()->flash('success', 'Booking successfully created!');
    }

    public function render()
    {
        return view('livewire.car-booking', [
            'car' => Car::findOrFail($this->carId),
        ]);
    }
}
