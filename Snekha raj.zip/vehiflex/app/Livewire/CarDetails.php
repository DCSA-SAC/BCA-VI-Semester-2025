<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\Car;

class CarDetails extends Component
{
    public $car; // To hold the car data

    // Load car details based on the car ID
    public function mount($carId)
    {
        $this->car = Car::findOrFail($carId);
    }

    public function render()
    {
        return view('livewire.car-details');
    }
}
