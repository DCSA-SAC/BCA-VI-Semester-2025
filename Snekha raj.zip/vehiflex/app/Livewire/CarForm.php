<?php

namespace App\Livewire;

use App\Models\Car;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Livewire\Component;
use Livewire\WithFileUploads;

class CarForm extends Component
{
    use WithFileUploads;

    public $carId, $vehicle_name, $driver_name, $address, $vehicle_brand, $vehicle_registration_no, $vehicle_color;
    public $driver_phone, $driver_email, $aadhar_card, $car_registration_document;
    public $thumb_image, $slide_images = [], $price_per_km;

    protected $rules = [
        'vehicle_name' => 'required|string|max:255',
        'driver_name' => 'required|string|max:255',
        'address' => 'required|string',
        'vehicle_brand' => 'required|string|max:255',
        'vehicle_registration_no' => 'required|string|unique:cars,vehicle_registration_no',
        'vehicle_color' => 'required|string|max:50',
        'driver_phone' => 'required|string|max:15',
        'driver_email' => 'required|email|unique:cars,driver_email|unique:users,email',
        'aadhar_card' => 'nullable|file|mimes:pdf,jpg,png|max:2048',
        'car_registration_document' => 'nullable|file|mimes:pdf,jpg,png|max:2048',
        'thumb_image' => 'nullable|file|mimes:jpg,png|max:2048',
        'slide_images.*' => 'nullable|file|mimes:jpg,png|max:2048',
        'price_per_km' => 'required|numeric|min:0',
    ];

    public function mount()
    {
        // Initialize properties if required. The mount method doesn't need to do anything specific now.
    }

    public function editCar($carId)
    {
        $car = Car::find($carId);
        if ($car) {
            $this->carId = $car->id;
            $this->vehicle_name = $car->vehicle_name;
            $this->driver_name = $car->driver_name;
            $this->address = $car->address;
            $this->vehicle_brand = $car->vehicle_brand;
            $this->vehicle_registration_no = $car->vehicle_registration_no;
            $this->vehicle_color = $car->vehicle_color;
            $this->driver_phone = $car->driver_phone;
            $this->driver_email = $car->driver_email;
            $this->price_per_km = $car->price_per_km;
        }
    }

    public function submit()
    {
        // Check if we're updating an existing car
        if ($this->carId) {
            // Fetch the existing car
            $car = Car::find($this->carId);

            // If updating, don't revalidate the existing email and vehicle registration number
            $this->rules['driver_email'] = 'required|email|unique:cars,driver_email,' . $car->id . '|unique:users,email,' . $car->user_id;
            $this->rules['vehicle_registration_no'] = 'required|string|unique:cars,vehicle_registration_no,' . $car->id;
        } else {
            // For new car, apply the default rules
            $this->rules['driver_email'] = 'required|email|unique:cars,driver_email|unique:users,email';
            $this->rules['vehicle_registration_no'] = 'required|string|unique:cars,vehicle_registration_no';
        }

        // Validate the input data
        $this->validate();

        // Prepare the data array for saving
        $data = [
            'vehicle_name' => $this->vehicle_name,
            'driver_name' => $this->driver_name,
            'address' => $this->address,
            'vehicle_brand' => $this->vehicle_brand,
            'vehicle_registration_no' => $this->vehicle_registration_no,
            'vehicle_color' => $this->vehicle_color,
            'driver_phone' => $this->driver_phone,
            'driver_email' => $this->driver_email,
            'price_per_km' => $this->price_per_km,
        ];

        // Handle file uploads only if they are provided
        if ($this->aadhar_card) {
            $data['aadhar_card'] = $this->aadhar_card->store('documents', 'public');
        }

        if ($this->car_registration_document) {
            $data['car_registration_document'] = $this->car_registration_document->store('documents', 'public');
        }

        if ($this->thumb_image) {
            $data['thumb_image'] = $this->thumb_image->store('images', 'public');
        }

        if ($this->slide_images) {
            $slidePaths = [];
            foreach ($this->slide_images as $slide) {
                $slidePaths[] = $slide->store('images/slides', 'public');
            }
            $data['slide_images'] = $slidePaths;
        }

        // If we are updating an existing car
        if ($this->carId) {
            $car = Car::find($this->carId);

            // Only update fields that are different
            foreach ($data as $key => $value) {
                if ($car->$key !== $value) {
                    $car->$key = $value;
                }
            }

            $car->save(); // Save the updated car
            session()->flash('success', 'Car updated successfully.');
        } else {
            // For a new car, create a new record
            $car = Car::create($data);

            // Create a driver user account if it's a new car
            $password = Str::random(8);
            $user = User::create([
                'name' => $this->driver_name,
                'email' => $this->driver_email,
                'password' => Hash::make($password),
                'role' => 'driver',
            ]);

            // Send an email with the generated password
            Mail::to($this->driver_email)->send(new \App\Mail\DriverPasswordMail($password));

            session()->flash('success', 'Car and driver registered successfully.');
        }

        // After the form is submitted, the page will automatically refresh and show the success message.
        $this->reset();  // Reset the form fields to clear the form after submission
    }



    public function deleteCar($carId)
    {
        $car = Car::find($carId);
        if ($car) {
            $car->delete();
            session()->flash('success', 'Car deleted successfully.');
        }
    }

    public function render()
    {
        $cars = Car::all();
        return view('livewire.car-form', compact('cars'));
    }
}

