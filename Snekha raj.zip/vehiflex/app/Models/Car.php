<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Car extends Model
{
    use HasFactory;

    protected $fillable = [
        'vehicle_name',
        'driver_name',
        'address',
        'vehicle_brand',
        'vehicle_registration_no',
        'vehicle_color',
        'thumb_image',
        'slide_images',
        'driver_phone',
        'driver_email',
        'aadhar_card',
        'car_registration_document',
        'price_per_km'
    ];

    protected $casts = [
        'slide_images' => 'array',
    ];
     public function users()
    {
        return $this->belongsToMany(User::class, 'car_driver');
    }
     // Define the relationship with CarDriver
     public function carDrivers()
     {
         return $this->hasMany(CarDriver::class);
     }

     // Define the relationship with User (driver) filtered by role
     public function driver()
     {
         return $this->belongsToMany(User::class, 'car_driver')->wherePivot('role', 'driver')->first();
     }

// Car.php
public function drivers()
{
    return $this->belongsToMany(User::class, 'car_driver', 'car_id', 'user_id');
}


}
