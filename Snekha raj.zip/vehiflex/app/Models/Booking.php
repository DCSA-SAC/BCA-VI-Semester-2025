<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    use HasFactory;

    // Specify the table name if it's not plural of the model name
    protected $table = 'bookings';

    // Specify the fillable fields for mass assignment
    protected $fillable = [
        'car_id', 'user_id', 'booking_date', 'pick_point', 'drop_point',
        'pick_lat', 'pick_lng', 'drop_lat', 'drop_lng', 'amount',
        'payment_status', 'razorpay_payment_id'
    ];

    // Relationships
   // Booking.php
public function car()
{
    return $this->belongsTo(Car::class);
}

public function user()
{
    return $this->belongsTo(User::class, 'user_id');
}


    // Check if a car is available for the given date
    public static function isCarAvailable($carId, $bookingDate)
    {
        return !self::where('car_id', $carId)
            ->where('booking_date', $bookingDate)
            ->exists();
    }
}
