<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CarDriver extends Model
{
    // Table associated with the model
    protected $table = 'car_driver';

    // The attributes that are mass assignable
    protected $fillable = [
        'car_id',
        'user_id',
    ];

    // Define the relationship between CarDriver and Car
    public function car()
    {
        return $this->belongsTo(Car::class);
    }

    // Define the relationship between CarDriver and User (driver)
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
