@extends('layouts.main')

@section('content')
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

<script>
    var options = {
        "key": "{{ $razorpayKey }}",
        "amount": "{{ $booking->amount * 100 }}",
        "currency": "INR",
        "name": "Car Rental Service",
        "description": "Car Booking Payment",
        "handler": function(response) {
            var form = document.createElement('form');
            form.method = 'POST';
            form.action = "{{ route('payment.success') }}";
            form.innerHTML = `
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <input type="hidden" name="razorpay_payment_id" value="${response.razorpay_payment_id}">
            `;
            document.body.appendChild(form);
            form.submit();
        },
        "prefill": {
            "name": "{{ Auth::user()->name }}",
            "email": "{{ Auth::user()->email }}"
        },
        "theme": {
            "color": "#007bff"
        }
    };

    var rzp1 = new Razorpay(options);
    rzp1.open();
</script>
@endsection
