@extends('layouts.main')
@section('content')
   @livewire('booking-component')
@endsection
