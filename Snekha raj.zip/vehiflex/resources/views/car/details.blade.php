@extends('layouts.main')
@section('content')
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            @foreach ($car->slide_images as $index => $image)
                                <div class="carousel-item {{ $index == 0 ? 'active' : '' }}">
                                    <img src="{{ asset($image) }}" class="d-block w-100" alt="{{ $car->vehicle_name }}">
                                </div>
                            @endforeach
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
                            data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
                            data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
                <div class="col-lg-6">
                    <h2>{{ $car->vehicle_name }}</h2>
                    <p><strong>Brand:</strong> {{ $car->vehicle_brand }}</p>
                    <p><strong>Color:</strong> {{ $car->vehicle_color }}</p>
                    <p><strong>Registration No:</strong> {{ $car->vehicle_registration_no }}</p>
                    <p><strong>Driver Name:</strong> {{ $car->driver_name }}</p>
                    <p><strong>Address:</strong> {{ $car->address }}</p>
                    <p><strong>Phone:</strong> {{ $car->driver_phone }}</p>
                    <p><strong>Email:</strong> {{ $car->driver_email }}</p>

                    <!-- Pickup and Drop Location Form -->
                    <div class="mb-3">
                        <label for="pickup" class="form-label">Pickup Location</label>
                        <input type="text" id="pickup" class="form-control" placeholder="Enter pickup location">
                    </div>
                    <div class="mb-3">
                        <label for="drop" class="form-label">Drop Location</label>
                        <input type="text" id="drop" class="form-control" placeholder="Enter drop location">
                    </div>
                    <p><strong>Estimated Fare:</strong> ₹<span id="fare">0</span></p>

                    <button id="pay-btn" class="btn btn-success" disabled>Pay & Book</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key={{ env('GOOGLE_MAPS_API_KEY') }}&libraries=places"></script>
    <script>
        let pickupInput = document.getElementById("pickup");
        let dropInput = document.getElementById("drop");
        let fareElement = document.getElementById("fare");
        let payBtn = document.getElementById("pay-btn");

        let pickupLocation, dropLocation;
        let ratePerKm = 10; // ₹10 per km

        function initAutocomplete() {
            let pickupAutocomplete = new google.maps.places.Autocomplete(pickupInput);
            let dropAutocomplete = new google.maps.places.Autocomplete(dropInput);

            pickupAutocomplete.addListener('place_changed', function() {
                let place = pickupAutocomplete.getPlace();
                if (!place.geometry) return;
                pickupLocation = place.geometry.location;
                calculateDistance();
            });

            dropAutocomplete.addListener('place_changed', function() {
                let place = dropAutocomplete.getPlace();
                if (!place.geometry) return;
                dropLocation = place.geometry.location;
                calculateDistance();
            });
        }

        function calculateDistance() {
            if (!pickupLocation || !dropLocation) return;

            let service = new google.maps.DistanceMatrixService();
            service.getDistanceMatrix({
                    origins: [pickupLocation],
                    destinations: [dropLocation],
                    travelMode: 'DRIVING'
                },
                function(response, status) {
                    if (status !== 'OK') {
                        console.error('Error with Distance Matrix API:', status);
                        return;
                    }

                    let distanceText = response.rows[0].elements[0].distance.text;
                    let distance = parseFloat(distanceText.replace(/[^\d.]/g, ''));
                    let estimatedFare = distance * ratePerKm;

                    fareElement.innerText = estimatedFare.toFixed(2);
                    payBtn.disabled = false;
                }
            );
        }

        document.getElementById('pay-btn').addEventListener('click', function(e) {
            e.preventDefault();

            fetch("{{ route('car.book') }}", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRF-TOKEN": "{{ csrf_token() }}"
                    },
                    body: JSON.stringify({
                        car_id: "{{ $car->id }}",
                        pick_point: pickupInput.value,
                        drop_point: dropInput.value,
                        pick_lat: pickupLocation.lat(),
                        pick_lng: pickupLocation.lng(),
                        drop_lat: dropLocation.lat(),
                        drop_lng: dropLocation.lng(),
                        amount: fareElement.innerText
                    })
                })
                .then(response => response.json())
                .then(data => {
                    let options = {
                        key: data.key,
                        amount: data.amount * 100,
                        currency: "INR",
                        name: "Car Booking",
                        description: "Book a ride",
                        order_id: data.order_id,
                        handler: function(response) {
                            fetch("{{ route('payment.success') }}", {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json",
                                        "X-CSRF-TOKEN": "{{ csrf_token() }}"
                                    },
                                    body: JSON.stringify({
                                        booking_id: data.booking_id,
                                        razorpay_payment_id: response
                                            .razorpay_payment_id // Ensure this is correctly passed
                                    })
                                })
                                .then(res => res.json())
                                .then(res => {
                                    if (res.status === "success") {
                                        alert("Payment Successful! Booking Confirmed.");
                                        window.location.reload();
                                    }
                                });
                        }

                    };
                    let rzp = new Razorpay(options);
                    rzp.open();
                });
        });

        window.onload = initAutocomplete;
    </script>
@endsection
