<div>
    <h2 class="text-lg font-bold mb-4">Your Bookings</h2>
    <table class="table-auto w-full border-collapse border border-gray-300">
        <thead>
            <tr class="bg-gray-200">
                <th class="border p-2">Car</th>
                <th class="border p-2">Booking Date</th>
                <th class="border p-2">Pick Point</th>
                <th class="border p-2">Drop Point</th>
                <th class="border p-2">Amount</th>
                <th class="border p-2">Status</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($bookings as $booking)
                <tr>
                    <td class="border p-2">{{ $booking->car->name ?? 'N/A' }}</td>
                    <td class="border p-2">{{ $booking->booking_date }}</td>
                    <td class="border p-2">{{ $booking->pick_point }}</td>
                    <td class="border p-2">{{ $booking->drop_point }}</td>
                    <td class="border p-2">{{ $booking->amount }}</td>
                    <td class="border p-2">{{ $booking->payment_status }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
