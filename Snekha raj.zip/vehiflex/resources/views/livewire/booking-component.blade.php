<div>
    <h2 class="text-2xl font-bold mb-4">Car Booking</h2>

    @if (session()->has('error'))
        <div class="bg-red-500 text-white p-2 mb-4">{{ session('error') }}</div>
    @endif

    <form wire:submit.prevent="bookCar">
        <div class="mb-3">
            <label class="block">Select Car</label>
            <select wire:model="car_id" class="w-full p-2 border rounded">
                <option value="">Choose a car</option>
                @foreach ($cars as $car)
                    <option value="{{ $car->id }}">{{ $car->name }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label class="block">Booking Date</label>
            <input type="date" wire:model="booking_date" class="w-full p-2 border rounded">
        </div>

        <div class="mb-3">
            <label class="block">Pick-up Point</label>
            <input type="text" wire:model="pick_point" class="w-full p-2 border rounded">
        </div>

        <div class="mb-3">
            <label class="block">Drop-off Point</label>
            <input type="text" wire:model="drop_point" class="w-full p-2 border rounded">
        </div>

        <div class="mb-3">
            <label class="block">Fare Amount (INR)</label>
            <input type="number" wire:model="amount" class="w-full p-2 border rounded">
        </div>

        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">
            Proceed to Payment
        </button>
    </form>
</div>
