<div class="container mt-4">
    <h2 class="mb-4">Car Management</h2>

    @if (session()->has('message'))
        <div class="alert alert-success">{{ session('message') }}</div>
    @endif

    <button class="btn btn-primary mb-3" wire:click="create">Add New Car</button>

    @if ($isEditMode)
        <div class="card mb-4">
            <div class="card-header">
                {{ $car_id ? 'Edit Car' : 'Add New Car' }}
            </div>
            <div class="card-body">
                <form wire:submit.prevent="save">
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label">Vehicle Name</label>
                            <input type="text" class="form-control" wire:model="vehicle_name">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Driver Name</label>
                            <input type="text" class="form-control" wire:model="driver_name">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Vehicle Brand</label>
                            <input type="text" class="form-control" wire:model="vehicle_brand">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Vehicle Color</label>
                            <input type="text" class="form-control" wire:model="vehicle_color">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Driver Phone</label>
                            <input type="text" class="form-control" wire:model="driver_phone">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Price Per KM</label>
                            <input type="number" class="form-control" wire:model="price_per_km">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Thumb Image</label>
                            <input type="file" class="form-control" wire:model="thumb_image">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Slide Images</label>
                            <input type="file" class="form-control" wire:model="slide_images" multiple>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success mt-3">{{ $car_id ? 'Update' : 'Save' }}</button>
                    <button type="button" class="btn btn-secondary mt-3" wire:click="resetFields">Cancel</button>
                </form>
            </div>
        </div>
    @endif

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Vehicle Name</th>
                <th>Driver</th>
                <th>Brand</th>
                <th>Color</th>
                <th>Price/KM</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($cars as $car)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $car->vehicle_name }}</td>
                    <td>{{ $car->driver_name }}</td>
                    <td>{{ $car->vehicle_brand }}</td>
                    <td>{{ $car->vehicle_color }}</td>
                    <td>{{ $car->price_per_km }}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" wire:click="edit({{ $car->id }})">Edit</button>
                        <button class="btn btn-danger btn-sm" wire:click="delete({{ $car->id }})">Delete</button>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
