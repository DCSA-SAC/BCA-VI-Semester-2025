<div class="container mt-5">
    @if (session()->has('message'))
        <div class="alert alert-success">
            {{ session('message') }}
        </div>
    @elseif (session()->has('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif

    <h2>Booking Form</h2>

    <form wire:submit.prevent="submitBooking">
        <div class="form-group">
            <label for="car_id">Select Car</label>
            <select class="form-control" id="car_id" wire:model="car_id" wire:change="updatedCarId($event.target.value)">
                <option value="">Select a car</option>
                @foreach($cars as $car)
                    <option value="{{ $car->id }}">{{ $car->model }} ({{ $car->license_plate }})</option>
                @endforeach
            </select>
            @error('car_id') <small class="text-danger">{{ $message }}</small> @enderror
        </div>

        @if($car_driver_id)
            <div class="form-group">
                <label for="car_driver_id">Assigned Driver</label>
                <input type="text" class="form-control" id="car_driver_id" value="{{ $car_driver_id }}" readonly>
            </div>
        @endif

        <div class="form-group">
            <label for="pickup_date">Pickup Date</label>
            <input type="date" class="form-control" id="pickup_date" wire:model="pickup_date">
            @error('pickup_date') <small class="text-danger">{{ $message }}</small> @enderror
        </div>

        <div class="form-group">
            <label for="pickup_location">Pickup Location</label>
            <input type="text" class="form-control" id="pickup_location" wire:model="pickup_location">
            @error('pickup_location') <small class="text-danger">{{ $message }}</small> @enderror
        </div>

        <div class="form-group">
            <label for="drop_location">Drop Location</label>
            <input type="text" class="form-control" id="drop_location" wire:model="drop_location">
            @error('drop_location') <small class="text-danger">{{ $message }}</small> @enderror
        </div>

        <button type="submit" class="btn btn-primary mt-3">Submit Booking</button>
    </form>
</div>
