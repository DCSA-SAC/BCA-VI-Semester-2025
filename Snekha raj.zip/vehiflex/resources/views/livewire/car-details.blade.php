<div class="container-xxl py-5">
    <div class="container">
        <div class="row">
            <!-- Left Section: Image Slider -->
            <div class="col-lg-6">
                <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        @foreach(json_decode($car->slide_images) as $index => $image)
                            <div class="carousel-item @if($index === 0) active @endif">
                                <img src="{{ asset('storage/'.$image) }}" class="d-block w-100" alt="{{ $car->vehicle_name }}">
                            </div>
                        @endforeach
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>

            <!-- Right Section: Car Details -->
            <div class="col-lg-6">
                <h2>{{ $car->vehicle_name }}</h2>
                <p><strong>Driver:</strong> {{ $car->driver_name }}</p>
                <p><strong>Address:</strong> {{ $car->address }}</p>
                <p><strong>Vehicle Brand:</strong> {{ $car->vehicle_brand }}</p>
                <p><strong>Registration No.:</strong> {{ $car->vehicle_registration_no }}</p>
                <p><strong>Color:</strong> {{ $car->vehicle_color }}</p>

                <p><strong>Driver Phone:</strong> {{ $car->driver_phone }}</p>
                <p><strong>Driver Email:</strong> <a href="mailto:{{ $car->driver_email }}">{{ $car->driver_email }}</a></p>

                <div class="mt-4">
                    <h5>Documents</h5>
                    <p><strong>Aadhar Card:</strong> <a href="{{ asset('storage/'.$car->aadhar_card) }}" target="_blank">View Aadhar</a></p>
                    <p><strong>Car Registration:</strong> <a href="{{ asset('storage/'.$car->car_registration_document) }}" target="_blank">View Registration</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
