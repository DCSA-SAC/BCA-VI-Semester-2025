<div>
    <table class="table">
        <thead>
            <tr>
                <th>Booking ID</th>
                <th>Car</th>
                <th>User</th>
                <th>Pick Point</th>
                <th>Drop Point</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Driver</th> <!-- New column for driver -->
            </tr>
        </thead>
        <tbody>
            @foreach($bookings as $booking)
                <tr>
                    <td>{{ $booking->id }}</td>
                    <td>{{ $booking->car->vehicle_name }}</td>
                    <td>{{ $booking->user->name }}</td>
                    <td>{{ $booking->pick_point }}</td>
                    <td>{{ $booking->drop_point }}</td>
                    <td>{{ $booking->amount }}</td>
                    <td>{{ $booking->payment_status }}</td>
                    <td>
                        <!-- Display the driver's name if it exists, otherwise show a fallback message -->
                        @if($booking->car && $booking->car->driver_name)
                            {{ $booking->car->driver_name }}
                        @else
                            Driver not assigned
                        @endif
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <!-- Pagination links -->
    <div class="d-flex justify-content-center">
        {{ $bookings->links() }}
    </div>
</div>
