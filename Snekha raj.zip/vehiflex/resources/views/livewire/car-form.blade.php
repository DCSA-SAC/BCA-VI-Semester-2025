<div class="container mt-5">
    <div class="row">
        <!-- Form Section (Left) -->
        <div class="col-md-6">
            <h3>{{ $carId ? 'Edit Car' : 'Register New Car' }}</h3>
            <form wire:submit.prevent="submit">
                @if(session()->has('success'))
                    <div class="alert alert-success">{{ session('success') }}</div>
                @endif

                <!-- Vehicle Name -->
                <div class="mb-3">
                    <label for="vehicle_name" class="form-label">Vehicle Name</label>
                    <input type="text" id="vehicle_name" wire:model="vehicle_name" class="form-control @error('vehicle_name') is-invalid @enderror">
                    @error('vehicle_name') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <!-- Driver Name -->
                <div class="mb-3">
                    <label for="driver_name" class="form-label">Driver Name</label>
                    <input type="text" id="driver_name" wire:model="driver_name" class="form-control @error('driver_name') is-invalid @enderror">
                    @error('driver_name') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <!-- Address -->
                <div class="mb-3">
                    <label for="address" class="form-label">Address</label>
                    <textarea id="address" wire:model="address" class="form-control @error('address') is-invalid @enderror"></textarea>
                    @error('address') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <!-- Vehicle Brand -->
                <div class="mb-3">
                    <label for="vehicle_brand" class="form-label">Vehicle Brand</label>
                    <input type="text" id="vehicle_brand" wire:model="vehicle_brand" class="form-control @error('vehicle_brand') is-invalid @enderror">
                    @error('vehicle_brand') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <!-- Vehicle Registration No -->
                <div class="mb-3">
                    <label for="vehicle_registration_no" class="form-label">Vehicle Registration No</label>
                    <input type="text" id="vehicle_registration_no" wire:model="vehicle_registration_no" class="form-control @error('vehicle_registration_no') is-invalid @enderror">
                    @error('vehicle_registration_no') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <!-- Vehicle Color -->
                <div class="mb-3">
                    <label for="vehicle_color" class="form-label">Vehicle Color</label>
                    <input type="text" id="vehicle_color" wire:model="vehicle_color" class="form-control @error('vehicle_color') is-invalid @enderror">
                    @error('vehicle_color') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <!-- Driver Phone -->
                <div class="mb-3">
                    <label for="driver_phone" class="form-label">Driver Phone</label>
                    <input type="text" id="driver_phone" wire:model="driver_phone" class="form-control @error('driver_phone') is-invalid @enderror">
                    @error('driver_phone') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <!-- Driver Email -->
                <div class="mb-3">
                    <label for="driver_email" class="form-label">Driver Email</label>
                    <input type="email" id="driver_email" wire:model="driver_email" class="form-control @error('driver_email') is-invalid @enderror">
                    @error('driver_email') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <!-- Aadhar Card -->
                <div class="mb-3">
                    <label for="aadhar_card" class="form-label">Aadhar Card</label>
                    <input type="file" id="aadhar_card" wire:model="aadhar_card" class="form-control @error('aadhar_card') is-invalid @enderror">
                    @error('aadhar_card') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <!-- Car Registration Document -->
                <div class="mb-3">
                    <label for="car_registration_document" class="form-label">Car Registration Document</label>
                    <input type="file" id="car_registration_document" wire:model="car_registration_document" class="form-control @error('car_registration_document') is-invalid @enderror">
                    @error('car_registration_document') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <!-- Thumbnail Image -->
                <div class="mb-3">
                    <label for="thumb_image" class="form-label">Thumbnail Image</label>
                    <input type="file" id="thumb_image" wire:model="thumb_image" class="form-control @error('thumb_image') is-invalid @enderror">
                    @error('thumb_image') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <!-- Slide Images -->
                <div class="mb-3">
                    <label for="slide_images" class="form-label">Slide Images</label>
                    <input type="file" id="slide_images" wire:model="slide_images" class="form-control @error('slide_images.*') is-invalid @enderror" multiple>
                    @error('slide_images.*') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <!-- Price Per Km -->
                <div class="mb-3">
                    <label for="price_per_km" class="form-label">Price Per Km</label>
                    <input type="text" id="price_per_km" wire:model="price_per_km" class="form-control @error('price_per_km') is-invalid @enderror">
                    @error('price_per_km') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <!-- Submit Button -->
                <div class="mb-3">
                    <button type="submit" class="btn btn-primary">{{ $carId ? 'Update' : 'Submit' }}</button>
                </div>
            </form>
        </div>

        <!-- Cars List Section (Right) -->
        <div class="col-md-6">
            <h3>List of Cars</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Vehicle Name</th>
                        <th>Driver Name</th>
                        <th>Vehicle Registration No</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($cars as $car)
                        <tr>
                            <td>{{ $car->vehicle_name }}</td>
                            <td>{{ $car->driver_name }}</td>
                            <td>{{ $car->vehicle_registration_no }}</td>
                            <td>
                                <button wire:click="deleteCar({{ $car->id }})" class="btn btn-danger">Delete</button>
                                <button wire:click="editCar({{ $car->id }})" class="btn btn-warning">Edit</button>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
