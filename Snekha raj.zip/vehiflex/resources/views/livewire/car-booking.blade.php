<div>
    <div class="container mt-4">
        <h2 class="text-center">Car Booking</h2>

        @if (session()->has('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        @if (session()->has('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif

        <div class="card p-4">
            <h4>Car: {{ $car->vehicle_name }}</h4>
            <p>Price per KM: ₹{{ $price_per_km }}</p>

            <!-- Pickup Point -->
            <div class="mb-3">
                <label for="pickPoint" class="form-label">Pickup Location</label>
                <input type="text" id="pickPoint" class="form-control" wire:model="pickPoint">
            </div>

            <!-- Drop Point -->
            <div class="mb-3">
                <label for="dropPoint" class="form-label">Drop Location</label>
                <input type="text" id="dropPoint" class="form-control" wire:model="dropPoint">
            </div>

            <!-- Booking Date -->
            <div class="mb-3">
                <label for="bookingDate" class="form-label">Booking Date</label>
                <input type="date" id="bookingDate" class="form-control" wire:model="bookingDate">
            </div>

            <!-- Fare Amount -->
            <div class="mb-3">
                <label class="form-label">Estimated Fare</label>
                <h5>₹<span id="fareAmount">{{ number_format($fareAmount, 2) }}</span></h5>
            </div>

            <!-- Payment Buttons -->
            <button class="btn btn-primary w-100" id="payNow" {{ $fareAmount == 0 ? 'disabled' : '' }}>Pay
                Now</button>
            <button class="btn btn-secondary w-100 mt-2" wire:click="bookWithoutPayment">Book Without Payment</button>
        </div>
    </div>

    <!-- Include Razorpay Script -->
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <!-- Google Maps API -->
    <script src="https://maps.googleapis.com/maps/api/js?key={{ env('GOOGLE_MAPS_API_KEY') }}&libraries=places"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let pickInput = document.getElementById('pickPoint');
            let dropInput = document.getElementById('dropPoint');
            let fareAmountElement = document.getElementById('fareAmount');
            let price_per_km = {{ $price_per_km }};

            let autocompletePick = new google.maps.places.Autocomplete(pickInput);
            let autocompleteDrop = new google.maps.places.Autocomplete(dropInput);

            let pickLat, pickLng, dropLat, dropLng;

            autocompletePick.addListener('place_changed', function() {
                let place = autocompletePick.getPlace();
                if (place.geometry) {
                    pickLat = place.geometry.location.lat();
                    pickLng = place.geometry.location.lng();
                    // Emit coordinates to Livewire
                    @this.set('pickLat', pickLat);
                    @this.set('pickLng', pickLng);
                }
            });

            autocompleteDrop.addListener('place_changed', function() {
                let place = autocompleteDrop.getPlace();
                if (place.geometry) {
                    dropLat = place.geometry.location.lat();
                    dropLng = place.geometry.location.lng();
                    // Emit coordinates to Livewire
                    @this.set('dropLat', dropLat);
                    @this.set('dropLng', dropLng);

                    if (pickLat && pickLng && dropLat && dropLng) {
                        calculateDistance();
                    }
                }
            });

            function calculateDistance() {
                let origin = new google.maps.LatLng(pickLat, pickLng);
                let destination = new google.maps.LatLng(dropLat, dropLng);

                let service = new google.maps.DistanceMatrixService();
                service.getDistanceMatrix({
                    origins: [origin],
                    destinations: [destination],
                    travelMode: google.maps.TravelMode.DRIVING,
                }, function(response, status) {
                    if (status === google.maps.DistanceMatrixStatus.OK) {
                        let distance = response.rows[0].elements[0].distance.value /
                            1000; // Convert meters to KM
                        let totalFare = Math.round(distance * price_per_km); // Round to nearest integer
                        fareAmountElement.innerText = totalFare.toFixed(2);
                        @this.set('fareAmount', totalFare); // Livewire binding
                    }
                });
            }

            // Razorpay Payment Event


        });
    </script>
</div>
