<div class="container mt-5">
    <div class="alert alert-info">
        <h4>Manage Bookings</h4>
    </div>

    @if (session()->has('message'))
        <div class="alert alert-success">
            {{ session('message') }}
        </div>
    @elseif (session()->has('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif

    <!-- Table to display bookings -->
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Booking ID</th>
                <th>Car</th>
                <th>Driver</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($bookings as $booking)
                <tr>
                    <td>{{ $booking->id }}</td>
                    <td>{{ $booking->car ? $booking->car->name : 'Not Assigned' }}</td>
                    <td>{{ $booking->user ? $booking->user->name : 'Not Assigned' }}</td>
                    <td>{{ $booking->amount }}</td>
                    <td>{{ $booking->payment_status }}</td>
                    <td>
                        <!-- Assign car and driver -->
                        @if (!$booking->car_id)
                            <button wire:click="assignCarToDriver" class="btn btn-primary btn-sm"
                                data-toggle="modal" data-target="#assignCarModal"
                                wire:click="$set('booking_id', {{ $booking->id }})">
                                Assign Car
                            </button>
                        @else
                            <span class="badge badge-success">Assigned</span>
                        @endif

                        <!-- Delete booking -->
                        <button wire:click="deleteBooking({{ $booking->id }})" class="btn btn-danger btn-sm">
                            Delete
                        </button>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <!-- Pagination -->
    <div class="d-flex justify-content-center">
        {{ $bookings->links() }} <!-- Display pagination links -->
    </div>
</div>

<!-- Modal to Assign Car to Driver -->
<div class="modal fade" id="assignCarModal" tabindex="-1" aria-labelledby="assignCarModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="assignCarModalLabel">Assign Car to Driver</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="car_id">Select Car</label>
                    <select wire:model="car_id" id="car_id" class="form-control">
                        <option value="">Select Car</option>
                        @foreach ($cars as $car)
                            <option value="{{ $car->id }}">{{ $car->name }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="form-group">
                    <label for="user_id">Select Driver</label>
                    <select wire:model="user_id" id="user_id" class="form-control">
                        <option value="">Select Driver</option>
                        @foreach ($users as $user)
                            <option value="{{ $user->id }}">{{ $user->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button wire:click="assignCarToDriver" class="btn btn-primary">Assign</button>
            </div>
        </div>
    </div>
</div>

<!-- Include Bootstrap JS and Popper.js -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.5/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
