<div>
    <form wire:submit.prevent="assignCar">
        <div class="form-group">
            <label for="car_id">Car</label>
            <select id="car_id" wire:model="car_id" class="form-control">
                <option value="">Select Car</option>
                @foreach($cars as $car)
                    <option value="{{ $car->id }}">{{ $car->vehicle_name }}</option>
                @endforeach
            </select>
        </div>

        <div class="form-group">
            <label for="user_id">Driver</label>
            <select id="user_id" wire:model="user_id" class="form-control">
                <option value="">Select Driver</option>
                @foreach($users as $user)
                    <option value="{{ $user->id }}">{{ $user->name }}</option>
                @endforeach
            </select>
        </div>

        <button type="submit" class="btn btn-primary">
            @if($car_driver_id)
                Update Assignment
            @else
                Assign Car
            @endif
        </button>
    </form>

    @if (session()->has('message'))
        <div class="alert alert-success mt-3">
            {{ session('message') }}
        </div>
    @elseif (session()->has('error'))
        <div class="alert alert-danger mt-3">
            {{ session('error') }}
        </div>
    @endif

    <!-- List of Car-Driver Assignments -->
    <h3 class="mt-5">Existing Car-Driver Assignments</h3>
    <table class="table mt-3">
        <thead>
            <tr>
                <th>Car</th>
                <th>Driver</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($carDrivers as $carDriver)
                <tr>
                    <td>{{ $carDriver->car->vehicle_name }}</td>
                    <td>{{ $carDriver->user->name }}</td>
                    <td>
                        <!-- This will call the loadCarDriver method with the car_driver_id -->
                        <button wire:click="loadCarDriver({{ $carDriver->id }})" class="btn btn-warning btn-sm">Edit</button>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
