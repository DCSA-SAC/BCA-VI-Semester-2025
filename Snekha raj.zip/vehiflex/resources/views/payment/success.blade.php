@extends('layouts.app')

@section('content')
    <div class="container">
        <h2>Payment Successful!</h2>
        <p>Thank you for your payment. Your booking is confirmed.</p>
    </div>
@endsection
