<!DOCTYPE html>
<html>
<head>
    <title>Your Account Details</title>
</head>
<body>
    <h1>Welcome to Our System</h1>
    <p>Your account has been created as a driver. Here is your login password:</p>
    <p><strong>{{ $password }}</strong></p>
    <p>Please change your password after logging in for the first time.</p>
</body>
</html>
