@extends('layouts.admin-layouts')
@section('content')
@livewire('booking-list')
<script>
    Livewire.on('refreshComponent', () => {
        // This will refresh the component when the event is emitted
        Livewire.emit('refresh');
    });
</script>
@endsection
