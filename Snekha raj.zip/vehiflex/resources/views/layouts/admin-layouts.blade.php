<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: #f8f9fa;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            background: #ffffff;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            overflow-y: auto;
            transform: translateX(-100%);
            transition: transform 0.3s ease;
        }
        .sidebar.active {
            transform: translateX(0);
        }
        .sidebar h4 {
            font-weight: 600;
            margin-bottom: 20px;
        }
        .nav-header {
            font-size: 14px;
            text-transform: uppercase;
            color: #adb5bd;
            margin-top: 20px;
            margin-bottom: 10px;
        }
        .sidebar a {
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 10px;
            color: #495057;
            border-radius: 8px;
            transition: background 0.3s;
        }
        .sidebar a:hover {
            background: #e9ecef;
        }
        .sidebar a i {
            font-size: 20px;
            margin-right: 10px;
        }
        .content {
            margin-left: 0;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }
        .content.active {
            margin-left: 250px;
        }
        #map {
            height: 400px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .footer {
            margin-top: 20px;
            text-align: center;
            color: #6c757d;
        }
        .footer a {
            color: #0d6efd;
            text-decoration: none;
        }
        .navbar {
            background: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .menu-toggle {
            cursor: pointer;
            font-size: 24px;
        }
        @media (max-width: 768px) {
            .sidebar {
                height: 100vh;
                position: fixed;
                z-index: 1050;
            }
            .content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
        <span class="menu-toggle material-icons" id="menuToggle">menu</span>
        <livewire:layout.navigation /> <!-- Livewire dynamic content for navigation -->
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <h4>Vehiflex</h4>
        <div class="nav-header">Main</div>
        <a href="#"><i class="material-icons">dashboard</i> Dashboard</a>
        <a href="{{ route('admin.booksmanagement') }}"><i class="material-icons">bar_chart</i> Bookings</a>

        <div class="nav-header">Cars</div>
        <a href="{{ route('admin.carmanagement') }}"><i class="material-icons">electric_car</i> Car Management</a>
        <a href="{{ route('admin.drivermanagement') }}"><i class="material-icons">local_taxi</i> Driver Manage</a>
        {{-- <a href="#"><i class="material-icons">history</i> Historial</a>
        <a href="#"><i class="material-icons">settings</i> Configuración</a> --}}
    </div>

    <!-- Main Content Area -->
    <div class="content" id="content">
        <div class="container">
            @yield('content') <!-- Dynamic content rendering -->
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js"></script>

    <script>
        const sidebar = document.getElementById('sidebar');
        const content = document.getElementById('content');
        const menuToggle = document.getElementById('menuToggle');

        // Sidebar toggle functionality
        menuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('active');
            content.classList.toggle('active');
        });

        // Leaflet map initialization
        var map = L.map('map').setView([-39.282, -71.978], 10);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: 'Map data © <a href="https://openstreetmap.org">OpenStreetMap</a> contributors'
        }).addTo(map);
        L.marker([-39.282, -71.978]).addTo(map)
            .bindPopup('Pucón')
            .openPopup();
    </script>
</body>
</html>
