<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CarController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\DriverController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\RazorpayWebhookController;
use App\Http\Controllers\CarBookingController;
use App\Http\Controllers\BookingController;

Route::post('/car/book', [BookingController::class, 'bookCar'])->name('car.book');
Route::post('/payment/success', [BookingController::class, 'paymentSuccess'])->name('payment.success');



Route::get('/razorpay/payment/{booking}', [PaymentController::class, 'initiatePayment'])->name('razorpay.payment');
Route::post('/razorpay-webhook', [RazorpayWebhookController::class, 'handleWebhook']);


Route::middleware(['auth', 'role:user'])->group(function () {
    Route::get('/user-dashboard', [UserController::class, 'index'])->name('dashboard');
});

Route::middleware(['auth', 'role:driver'])->group(function () {
    Route::get('/driver-dashboard', [DriverController::class, 'index'])->name('driver.dashboard');
});

Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/admin-dashboard', [AdminController::class, 'index'])->name('admin.dashboard');
    Route::get('/admin/car-management', [AdminController::class, 'CarManagement'])->name('admin.carmanagement');
    Route::get('/admin/management-driver', [AdminController::class, 'ManagementDriver'])->name('admin.drivermanagement');
    Route::get('/admin/management-bookings', [AdminController::class, 'ManagementBooking'])->name('admin.booksmanagement');
});




Route::middleware(['auth', 'role:user'])->group(function () {
    Route::get('/car/{carId}', [CarController::class, 'show'])->name('car.details');
    Route::get('/car/{carId}/book', [CarBookingController::class, 'book'])->name('car.booking');
    Route::post('/car/{carId}/book/without-payment', [CarBookingController::class, 'bookWithoutPayment'])->name('car.bookWithoutPayment');
    Route::post('/update-fare', [CarBookingController::class, 'updateFare'])->name('update.fare');
});
Route::view('/', 'index')->name('home');



Route::view('profile', 'profile')
    ->middleware(['auth'])
    ->name('profile');

require __DIR__ . '/auth.php';


