<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;
use Illuminate\Support\Str;

class CarSeeder extends Seeder
{
    public function run()
    {
        $faker = Faker::create();

        // Example vehicle brands
        $vehicleNames = ['Maruti Suzuki', 'Honda City', 'Hyundai Creta', 'Toyota Innova', 'Ford EcoSport'];

        for ($i = 0; $i < 4; $i++) {
            DB::table('cars')->insert([
                'vehicle_name' => $vehicleNames[array_rand($vehicleNames)], // Random vehicle name from predefined list
                'driver_name' => $faker->name, // Driver's name
                'address' => $faker->address, // Address
                'vehicle_brand' => $faker->company, // Vehicle brand
                'vehicle_registration_no' => strtoupper(Str::random(10)), // Random unique vehicle registration number
                'vehicle_color' => $faker->safeColorName, // Vehicle color
                'thumb_image' => $faker->imageUrl(640, 480, 'vehicles', true, 'car'), // Thumbnail image URL
                'slide_images' => json_encode([$faker->imageUrl(640, 480, 'vehicles', true, 'car'), $faker->imageUrl(640, 480, 'vehicles', true, 'car')]), // Additional images
                'driver_phone' => $faker->phoneNumber, // Driver's phone number
                'driver_email' => $faker->unique()->safeEmail, // Unique driver email
                'aadhar_card' => 'aadhar_card_' . Str::random(10) . '.pdf', // Aadhar card document path
                'car_registration_document' => 'car_registration_' . Str::random(10) . '.pdf', // Car registration document path
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
