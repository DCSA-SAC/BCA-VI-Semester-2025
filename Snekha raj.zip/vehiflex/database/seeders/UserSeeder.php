<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Faker\Factory as Faker;

class UserSeeder extends Seeder
{
    public function run()
    {
        $faker = Faker::create();

        // You can create multiple driver users or just one
        for ($i = 0; $i < 4; $i++) {
            // Generate a random password
            $password = Str::random(8);

            // Create a new driver user
            $user = User::create([
                'name' => $faker->name, // Driver's name
                'email' => $faker->unique()->safeEmail, // Unique email
                'password' => Hash::make($password), // Hashed password
                'role' => 'driver', // Assign the driver role
            ]);

            // Optional: You can output the password to keep track of it
            echo "Driver user created with email: {$user->email}, password: {$password}\n";
        }
    }
}
