<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBookingsTable extends Migration
{
    public function up()
    {
        Schema::create('bookings', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('car_id');
            $table->unsignedBigInteger('user_id');
            $table->date('booking_date');
            $table->string('pick_point'); // Pick-up address
            $table->string('drop_point'); // Drop-off address
            $table->decimal('pick_lat', 10, 8)->nullable(); // Pick-up latitude
            $table->decimal('pick_lng', 11, 8)->nullable(); // Pick-up longitude
            $table->decimal('drop_lat', 10, 8)->nullable(); // Drop-off latitude
            $table->decimal('drop_lng', 11, 8)->nullable(); // Drop-off longitude
            $table->timestamps();

            $table->foreign('car_id')->references('id')->on('cars')->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('bookings');
    }
}
