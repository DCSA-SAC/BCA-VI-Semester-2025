<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cars', function (Blueprint $table) {
            $table->id();
            $table->string('vehicle_name'); // Vehicle name
            $table->string('driver_name'); // Driver name
            $table->string('address'); // Address
            $table->string('vehicle_brand'); // Vehicle brand
            $table->string('vehicle_registration_no')->unique(); // Unique vehicle registration number
            $table->string('vehicle_color'); // Vehicle color
            $table->string('thumb_image')->nullable(); // Thumbnail image of the vehicle
            $table->json('slide_images')->nullable(); // Additional images of the vehicle
            $table->string('driver_phone')->nullable(); // Driver's phone number
            $table->string('driver_email')->unique(); // Driver's email address (unique for user registration)
            $table->string('aadhar_card')->nullable(); // Driver's Aadhar card document path
            $table->string('car_registration_document')->nullable(); // Car registration document path
            $table->timestamps(); // Timestamps for created_at and updated_at
        });


    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cars');
    }
};
