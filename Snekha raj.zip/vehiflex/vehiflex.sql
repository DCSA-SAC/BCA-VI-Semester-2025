-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2025 at 02:15 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vehiflex`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `car_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `booking_date` date NOT NULL,
  `pick_point` varchar(255) NOT NULL,
  `drop_point` varchar(255) NOT NULL,
  `pick_lat` decimal(10,8) DEFAULT NULL,
  `pick_lng` decimal(11,8) DEFAULT NULL,
  `drop_lat` decimal(10,8) DEFAULT NULL,
  `drop_lng` decimal(11,8) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `amount` decimal(8,2) DEFAULT NULL,
  `payment_status` varchar(255) NOT NULL DEFAULT 'Pending',
  `razorpay_payment_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `car_id`, `user_id`, `booking_date`, `pick_point`, `drop_point`, `pick_lat`, `pick_lng`, `drop_lat`, `drop_lng`, `created_at`, `updated_at`, `amount`, `payment_status`, `razorpay_payment_id`) VALUES
(53, 4, 6, '2025-02-01', 'Pickup Location', 'Drop Location', 22.71960000, 75.85770000, 23.25990000, 77.41260000, '2025-02-01 05:22:45', '2025-02-01 05:22:45', 500.00, 'pending', 'PAY-FRNBQGDVSD'),
(54, 4, 6, '2025-02-01', 'Pickup Location', 'Drop Location', 22.71960000, 75.85770000, 23.25990000, 77.41260000, '2025-02-01 05:31:12', '2025-02-01 05:31:12', 500.00, 'pending', 'PAY-NMDY9XFPBX'),
(55, 4, 6, '2025-02-01', 'Jabalpur, Madhya Pradesh, India', 'Jabalpur railway station, Madhya Pradesh State Highway 22, Tagore Railway Colony, South Civil Lines, Jabalpur, Madhya Pradesh, India', 23.16857860, 79.93387980, 23.16467840, 79.95165540, '2025-02-01 07:43:44', '2025-02-01 07:43:44', 29.00, 'pending', 'PAY-M7XYLJNXX5');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_name` varchar(255) NOT NULL,
  `driver_name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `vehicle_brand` varchar(255) NOT NULL,
  `vehicle_registration_no` varchar(255) NOT NULL,
  `vehicle_color` varchar(255) NOT NULL,
  `thumb_image` varchar(255) DEFAULT NULL,
  `slide_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`slide_images`)),
  `price_per_km` decimal(8,2) NOT NULL DEFAULT 10.00,
  `driver_phone` varchar(255) DEFAULT NULL,
  `driver_email` varchar(255) NOT NULL,
  `aadhar_card` varchar(255) DEFAULT NULL,
  `car_registration_document` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `vehicle_name`, `driver_name`, `address`, `vehicle_brand`, `vehicle_registration_no`, `vehicle_color`, `thumb_image`, `slide_images`, `price_per_km`, `driver_phone`, `driver_email`, `aadhar_card`, `car_registration_document`, `created_at`, `updated_at`) VALUES
(1, 'Ford EcoSport-1', 'Miss Audrey McCullough', '8633 Bogisich Islands\nSouth Dereckshire, CO 30309-1787', 'Kshlerin-Torphy', 'DN2BBHZ7J7', 'white', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRFG8zHud1LIgsyS4zJmLOG2JYn3ltImG8DUA&s', '[\"https:\\/\\/images.unsplash.com\\/640x480.png\\/009955?text=vehicles+car+quam\",\"https:\\/\\/images.unsplash.com\\/640x480.png\\/0055bb?text=vehicles+car+nostrum\"]', 10.00, '(574) 541-7229', 'peggie11@exa1ple.net', 'aadhar_card_9YLkXFtnGh.pdf', 'car_registration_sE8G4EHCr4.pdf', '2025-01-28 09:03:52', '2025-01-31 06:04:05'),
(2, 'Maruti Suzuki-1', 'Dr. Curtis Auer', '2411 Wisozk Brook Suite 917\nBobbietown, WA 41122-4212', 'Bayer Inc', 'VMRXF3FZJY', 'olive', 'https://stimg.cardekho.com/images/carexteriorimages/630x420/Maruti/Dzire/11387/1731318279714/front-left-side-47.jpg?impolicy=resize&imwidth=480', '[\"https:\\/\\/via.placeholder.com\\/640x480.png\\/000011?text=vehicles+car+iure\",\"https:\\/\\/via.placeholder.com\\/640x480.png\\/0055aa?text=vehicles+car+optio\"]', 10.00, '1-703-219-6204', 'lang.bernardo@example.net', 'aadhar_card_SJ6NzV0QXF.pdf', 'car_registration_PnUL2gmCuz.pdf', '2025-01-28 09:03:52', '2025-01-31 06:20:26'),
(3, 'Hyundai Creta-1', 'Rowena Doyle', '7892 Breitenberg Crescent\nJaskolskichester, PA 94583-3153', 'Kuhn-Oberbrunner', '8OHLCOTCTP', 'gray', 'https://stimg.cardekho.com/images/carexteriorimages/930x620/Hyundai/Creta/8667/1705465218824/front-left-side-47.jpg?imwidth=420&impolicy=resize', '[\"https:\\/\\/via.placeholder.com\\/640x480.png\\/006677?text=vehicles+car+eaque\",\"https:\\/\\/via.placeholder.com\\/640x480.png\\/00aabb?text=vehicles+car+corporis\"]', 10.00, '743-205-1988', 'holly16@example.org', 'aadhar_card_glJ7DZzgt1.pdf', 'car_registration_xcPd0RPa1u.pdf', '2025-01-28 09:03:52', '2025-01-31 06:20:46'),
(4, 'Ford EcoSport', 'Haleigh Welch', '453 Daugherty Rest Suite 248\nChamplinview, MD 07449', 'Hills LLC', 'RORT4IIGH0', 'teal', 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/2018_Ford_Ecosport_ST-Line_TDCi_1.5.jpg/800px-2018_Ford_Ecosport_ST-Line_TDCi_1.5.jpg', '[\"https:\\/\\/via.placeholder.com\\/640x480.png\\/009988?text=vehicles+car+totam\",\"https:\\/\\/via.placeholder.com\\/640x480.png\\/005522?text=vehicles+car+minus\"]', 10.00, '223.774.6209', 'urenner@example.com', 'aadhar_card_yxltHgt85K.pdf', 'car_registration_Umg8yCfMhh.pdf', '2025-01-28 09:03:52', '2025-01-31 06:24:14');

-- --------------------------------------------------------

--
-- Table structure for table `car_driver`
--

CREATE TABLE `car_driver` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `car_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `car_driver`
--

INSERT INTO `car_driver` (`id`, `car_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 3, NULL, '2025-01-31 07:35:04'),
(2, 4, 5, NULL, '2025-01-31 07:39:02'),
(3, 2, 4, NULL, '2025-01-31 07:35:17'),
(4, 3, 4, '2025-01-31 07:39:44', '2025-01-31 07:39:44');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_01_28_141512_create_cars_table', 2),
(5, '2025_01_28_143012_add_role_to_users_table', 3),
(6, '2025_01_28_150353_create_car_driver_table', 4),
(7, '2025_01_28_161042_create_bookings_table', 5),
(8, '2025_01_30_150152_add_payment_fields_to_bookings_table', 6),
(9, '2025_01_30_213332_add_price_per_km_to_cars_table', 7);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('mGjfl89fwV69lDganjDNGQwtkXHq1phaGMtgPA9V', 6, '127.0.0.1', 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoiRmhhVkZEQ2pkOEpZYmhJbE9jY1p6Q1Y3WEtuTEEzc1BNc0RKU3ZjaSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9jYXIvNCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6MzoidXJsIjthOjA6e31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTo2O3M6MTA6ImJvb2tpbmdfaWQiO2k6MzE7fQ==', 1738407723),
('SqzqUNSa8ugPgIBUrYheQ09c9Wit4qrrZXJeSV0W', 6, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiRzNsSUNFMm5lUnViQVZIWG5XaWpXZm51cjNJMkZHaUpDMGhkTDRncSI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjI3OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvY2FyLzQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTo2O30=', 1738415699);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `role`) VALUES
(1, 'admin', 'admin@vehiflex.com', NULL, '$2y$12$iAV6gVqKFX9cEjkbRiKWjufOqFTgt9Zr93GKKMUq8t5pgJVGADtUy', NULL, '2025-01-28 08:35:52', '2025-01-28 08:35:52', 'admin'),
(2, 'Efren Lueilwitz', 'corwin.eldon@example.com', NULL, '$2y$12$UC4G0S3.tyTedD2enljAgOWnIE5QN0PVtw8JaON48.Y2e19MAAlie', NULL, '2025-01-28 09:08:03', '2025-01-28 09:08:03', 'driver'),
(3, 'Junior Price', 'ryann50@example.org', NULL, '$2y$12$RzeZfTQO6.PltgXIH6f5kuwTO4JAgS2b5CdSeOz6dmdinOQzppEAm', NULL, '2025-01-28 09:08:03', '2025-01-28 09:08:03', 'driver'),
(4, 'Kenna Koelpin V', 'candida.johnston@example.net', NULL, '$2y$12$iqfHg29yqW/z6CSjeBRTCu.aHS.Dz7Z93SNg5wJIJsgNJtVadtnkS', NULL, '2025-01-28 09:08:03', '2025-01-28 09:08:03', 'driver'),
(5, 'Marlin Feil', 'ghammes@example.com', NULL, '$2y$12$7fKkpuvcWEOgRKMbjl.6fOa9l3ehCuQFWWQl.9xj28WVrCyXbFAhy', NULL, '2025-01-28 09:08:03', '2025-01-28 09:08:03', 'driver'),
(6, 'customer', 'customer@vehiflex.com', NULL, '$2y$12$/J1vhoq7uen8Oc.QYTX.OeDIm7s7Rv2TpzGwDckXTrZorIm4sk3fO', NULL, '2025-01-31 03:53:42', '2025-01-31 03:53:42', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bookings_car_id_foreign` (`car_id`),
  ADD KEY `bookings_user_id_foreign` (`user_id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cars_vehicle_registration_no_unique` (`vehicle_registration_no`),
  ADD UNIQUE KEY `cars_driver_email_unique` (`driver_email`);

--
-- Indexes for table `car_driver`
--
ALTER TABLE `car_driver`
  ADD PRIMARY KEY (`id`),
  ADD KEY `car_driver_car_id_foreign` (`car_id`),
  ADD KEY `car_driver_user_id_foreign` (`user_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `car_driver`
--
ALTER TABLE `car_driver`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_car_id_foreign` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `car_driver`
--
ALTER TABLE `car_driver`
  ADD CONSTRAINT `car_driver_car_id_foreign` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `car_driver_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
