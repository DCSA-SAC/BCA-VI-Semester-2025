from django.contrib import admin

# Register your models here.
from .models import Home,Product,Formal,Sports,Kids, ContactMessage, CartItem

admin.site.register(Home)
admin.site.register(Product)
admin.site.register(Formal)
admin.site.register(Sports)
admin.site.register(Kids)
admin.site.register(CartItem)

class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'submitted_at')
    search_fields = ('name', 'email', 'phone')

admin.site.register(ContactMessage, ContactMessageAdmin)