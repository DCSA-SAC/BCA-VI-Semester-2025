from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404
from .models import Home, Product, CartItem,ContactMessage
from .forms import UserRegistrationForm, HomeForm, ProductForm, ContactMessageForm
from django.contrib.auth import login,logout
from django.contrib.auth.decorators import login_required


def home(request):
    obj = Home.objects.all()
    return render(request, 'index.html', {'obj':obj})


def HomeViewEdit(request, id):
    home = get_object_or_404(Home, id=id)
    if request.method == 'POST':
        form = HomeForm(request.POST, request.FILES, instance=home)
        if form.is_valid():
            form.save()
            messages.success(request, "Home section updated successfully!")
            return redirect('home') 
        else:
            messages.error(request, "There was an error updating the home section.")
    else:
        form = HomeForm(instance=home)
    return render(request, 'forms/home_form.html', {'form': form})


def products(request):
    obj = Product.objects.all()
    return render(request,'products.html',{'obj':obj})


def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    return render(request, 'product_detail.html', {'product': product})


def productDelete(request,id):
    obj = get_object_or_404(Product,id=id)
    obj.delete()
    return redirect('product_details')


def ProductViewEdit(request, id):
    product = get_object_or_404(Product, id=id)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            messages.success(request, "Product section updated successfully!")
            return redirect('product_details')  
        else:
            messages.error(request, "There was an error updating the home section.")
    else:
        form = ProductForm(instance=product)
    return render(request, 'forms/product_form.html', {'form': form})



def contact(request):
    if request.method == 'POST':
        form = ContactMessageForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Your message has been sent successfully!")
            return redirect('contact')  # or wherever you want to redirect
    else:
        form = ContactMessageForm()
    
    return render(request, 'contact.html', {'form': form})


def about(request):
    return render(request, 'about.html')


def register(request):
    if request.method == "POST":
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password1'])
            user.save()
            login(request,user)
            return redirect('login')
    else:
        form = UserRegistrationForm()
    return render(request,'registration/register.html', {'form':form})    


# @login_required
# def add_to_cart(request, product_id):
#     product = get_object_or_404(Product, id=product_id)

#     cart = request.session.get('cart', {})  # Get cart from session (default: empty dict)

#     if str(product_id) in cart:
#         cart[str(product_id)]["quantity"] += 1  # Increase quantity if item exists
#     else:
#         cart[str(product_id)] = {"name": product.name, "price": product.price, "quantity": 1}

#     request.session['cart'] = cart  # Save updated cart in session
#     return redirect('products')


@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)

    #  Update or create CartItem in the database
    cart_item, created = CartItem.objects.get_or_create(user=request.user, product=product)
    if not created:
        cart_item.quantity += 1
        cart_item.save()

    #  Update session cart too
    cart = request.session.get('cart', {})
    if str(product_id) in cart:
        cart[str(product_id)]["quantity"] += 1
    else:
        cart[str(product_id)] = {
            "name": product.name,
            "price": product.price,
            "quantity": 1
        }
    request.session['cart'] = cart

    return redirect('products')


# @login_required
# def view_cart(request):
#     cart = request.session.get('cart', {})  # Retrieve cart from session
#     total_price = sum(item["price"] * item["quantity"] for item in cart.values())

#     return render(request, 'cart.html', {'cart': cart, 'total_price': total_price})


@login_required
def view_cart(request):
    cart = request.session.get('cart', {})

    # If session cart is empty, restore from DB
    if not cart:
        db_items = CartItem.objects.filter(user=request.user)
        cart = {
            str(item.product.id): {
                "name": item.product.name,
                "price": item.product.price,
                "quantity": item.quantity
            }
            for item in db_items
        }
        request.session['cart'] = cart  # update session

    total_price = sum(item["price"] * item["quantity"] for item in cart.values())
    return render(request, 'cart.html', {'cart': cart, 'total_price': total_price})


# @login_required
# def remove_from_cart(request, product_id):
#     cart = request.session.get('cart', {})

#     if str(product_id) in cart:
#         del cart[str(product_id)]  # Remove item from cart

#     request.session['cart'] = cart  # Save updated cart
#     return redirect('cart')


@login_required
def remove_from_cart(request, product_id):
    cart = request.session.get('cart', {})

    # Remove from session
    if str(product_id) in cart:
        del cart[str(product_id)]

    # Remove from DB
    CartItem.objects.filter(user=request.user, product_id=product_id).delete()

    request.session['cart'] = cart
    return redirect('cart')



# @login_required
# def clear_cart(request):
#     request.session['cart'] = {}  # Clear cart
#     return redirect('cart')


@login_required
def clear_cart(request):
    # Clear session
    request.session['cart'] = {}

    # Clear DB
    CartItem.objects.filter(user=request.user).delete()

    return redirect('cart')


def showContactDetails(req):
    obj = ContactMessage.objects.all()
    return render(req,'showContactDetails.html',{'obj':obj})
    