from django.db import models
from django.contrib.auth.models import User

class Home(models.Model):  
    img = models.ImageField(upload_to='images/')  
    description = models.CharField(max_length=200)
    price = models.IntegerField(default = 2000)
    
    def __str__(self):
        return str(self.id)
    
    
class Product(models.Model):
    productImg = models.ImageField(upload_to='products/',null=True)
    name= models.CharField(max_length=100,null=True)
    desc = models.CharField(max_length=400)
    price = models.IntegerField(default=200)
    mrp = models.IntegerField(default=200,null=True)
    
    def __str__(self):
       return str(self.id)
   

class ContactMessage(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    message = models.TextField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.email}"
   
    
class Formal(models.Model):
    productImg = models.ImageField(upload_to='Formal/',null=True)
    desc = models.CharField(max_length=100)
    price = models.IntegerField(default=200)
    
    
class Sports(models.Model):
    productImg = models.ImageField(upload_to='Sports/',null=True)
    desc = models.CharField(max_length=100)
    price = models.IntegerField(default=200)
    
class Kids(models.Model):
    productImg = models.ImageField(upload_to='Kids/',null=True)
    desc = models.CharField(max_length=100)
    price = models.IntegerField(default=200)
    


class CartItem(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.user.username} - {self.product.name} (x{self.quantity})"
    