from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Home, Product, ContactMessage



class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField()
    class Meta:
        model  = User
        fields = ('first_name','last_name','username','email','password1','password2')
    
    
class HomeForm(forms.ModelForm):
    class Meta:
        model = Home
        fields = '__all__'    
        
        
class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = '__all__'    
        

class ContactMessageForm(forms.ModelForm):
    class Meta:
        model = ContactMessage
        fields = ['name', 'email', 'phone', 'message']