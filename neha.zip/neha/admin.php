<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Score Up Jabalpur</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #1f2c58;
            --secondary-color: #4a6fa5;
            --accent-color: #ff5733;
            --light-accent: #ff9f43;
            --dark-color: #0d0d3e;
            --text-dark: #2d3748;
            --text-medium: #4a5568;
            --text-light: #718096;
            --bg-light: #f8fafc;
            --white: #ffffff;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.12);
            --shadow-md: 0 4px 6px rgba(0,0,0,0.1);
            --shadow-lg: 0 10px 25px rgba(0,0,0,0.1);
            --transition: all 0.3s ease;
            --border-radius: 8px;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            line-height: 1.6;
            color: var(--text-dark);
            background-color: var(--bg-light);
        }

        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, var(--dark-color), var(--primary-color));
            color: var(--white);
            padding: 1.5rem 0;
            position: fixed;
            height: 100vh;
            transition: var(--transition);
            z-index: 1000;
        }

        .sidebar-header {
            padding: 0 1.5rem 1.5rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-header h2 {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .sidebar-header h2 i {
            color: var(--accent-color);
        }

        .nav-menu {
            margin-top: 1.5rem;
        }

        .nav-menu ul {
            list-style: none;
        }

        .nav-menu li {
            position: relative;
        }

        .nav-menu a {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.8rem 1.5rem;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: var(--transition);
        }

        .nav-menu a:hover, .nav-menu a.active {
            color: var(--white);
            background: rgba(255,255,255,0.1);
        }

        .nav-menu a:hover::before, .nav-menu a.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 4px;
            background: var(--accent-color);
        }

        .nav-menu a i {
            width: 20px;
            text-align: center;
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 1.5rem;
            transition: var(--transition);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--white);
            padding: 1rem 1.5rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            margin-bottom: 1.5rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }

        .user-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }

        .logout-btn {
            background: var(--danger-color);
            color: var(--white);
            border: none;
            padding: 0.5rem 1rem;
            border-radius: var(--border-radius);
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logout-btn:hover {
            background: #c82333;
        }

        /* Section Styles */
        .section {
            background: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 0.8rem;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }

        .section-header h2 {
            color: var(--primary-color);
            font-size: 1.5rem;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.6rem 1.2rem;
            border-radius: var(--border-radius);
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            border: none;
            gap: 0.5rem;
        }

        .btn-primary {
            background: var(--primary-color);
            color: var(--white);
        }

        .btn-primary:hover {
            background: var(--secondary-color);
        }

        .btn-success {
            background: var(--success-color);
            color: var(--white);
        }

        .btn-success:hover {
            background: #218838;
        }

        .btn-danger {
            background: var(--danger-color);
            color: var(--white);
        }

        .btn-danger:hover {
            background: #c82333;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 1.2rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--text-dark);
        }

        .form-control {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-family: inherit;
            transition: var(--transition);
        }

        .form-control:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(31, 44, 88, 0.2);
        }

        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }

        /* Table Styles */
        .table-responsive {
            overflow-x: auto;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th, .table td {
            padding: 0.8rem;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .table th {
            background: var(--primary-color);
            color: var(--white);
            font-weight: 500;
        }

        .table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .table tr:hover {
            background-color: #f1f1f1;
        }

        .action-btns {
            display: flex;
            gap: 0.5rem;
        }

        /* Image Preview */
        .image-preview {
            width: 150px;
            height: 150px;
            border: 1px dashed #ddd;
            border-radius: var(--border-radius);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            margin-bottom: 1rem;
        }

        .image-preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            
            .sidebar-header h2 span, .nav-menu a span {
                display: none;
            }
            
            .sidebar-header h2 {
                justify-content: center;
            }
            
            .nav-menu a {
                justify-content: center;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding: 1rem 0;
            }
            
            .sidebar-header {
                padding: 0 1rem 1rem;
                text-align: center;
            }
            
            .nav-menu ul {
                display: flex;
                overflow-x: auto;
                padding-bottom: 1rem;
            }
            
            .nav-menu li {
                flex: 0 0 auto;
            }
            
            .nav-menu a {
                padding: 0.5rem 1rem;
            }
            
            .nav-menu a::before {
                display: none;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar Navigation -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>
                    <i class="fas fa-user-shield"></i>
                    <span>Admin Panel</span>
                </h2>
            </div>
            <nav class="nav-menu">
                <ul>
                    <li>
                        <a href="#dashboard" class="active">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="#course-management">
                            <i class="fas fa-book"></i>
                            <span>Manage Courses</span>
                        </a>
                    </li>
                    <li>
                        <a href="#gallery-management">
                            <i class="fas fa-images"></i>
                            <span>Manage Gallery</span>
                        </a>
                    </li>
                    <li>
                        <a href="#result-management">
                            <i class="fas fa-chart-line"></i>
                            <span>Manage Results</span>
                        </a>
                    </li>
                    <li>
                        <a href="#study-material-management">
                            <i class="fas fa-file-alt"></i>
                            <span>Study Materials</span>
                        </a>
                    </li>
                    <li>
                        <a href="#user-management">
                            <i class="fas fa-users"></i>
                            <span>User Management</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="main-content">
            <div class="header">
                <h1>Welcome, Admin</h1>
                <div class="user-info">
                    <img src="https://ui-avatars.com/api/?name=Admin&background=random" alt="Admin">
                    <a href="admin_logout.php" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </a>
                </div>
            </div>

            <!-- Dashboard Overview -->
            <section id="dashboard" class="section">
                <div class="section-header">
                    <h2>Dashboard Overview</h2>
                </div>
                <div class="stats-grid">
                    <!-- Statistics cards would go here -->
                </div>
            </section>

            <!-- Course Management Section -->
            <section id="course-management" class="section">
                <div class="section-header">
                    <h2>Manage Courses</h2>
                    <button class="btn btn-primary" id="addCourseBtn">
                        <i class="fas fa-plus"></i> Add Course
                    </button>
                </div>
                
                <!-- Add/Edit Course Form (Initially Hidden) -->
                <div id="course-form-container" style="display: none;">
                    <form id="course-form" action="manage_course.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="course_id" id="course_id">
                        
                        <div class="form-group">
                            <label for="course_title">Course Title</label>
                            <input type="text" class="form-control" id="course_title" name="course_title" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="course_class">Class</label>
                            <select class="form-control" id="course_class" name="course_class" required>
                                <option value="">Select Class</option>
                                <option value="6">Class 6</option>
                                <option value="7">Class 7</option>
                                <option value="8">Class 8</option>
                                <option value="9">Class 9</option>
                                <option value="10">Class 10</option>
                                <option value="11">Class 11</option>
                                <option value="12">Class 12</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="course_description">Description</label>
                            <textarea class="form-control" id="course_description" name="course_description" required></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="course_duration">Duration</label>
                            <input type="text" class="form-control" id="course_duration" name="course_duration" placeholder="e.g., 10 Months" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="course_price">Price</label>
                            <input type="number" class="form-control" id="course_price" name="course_price" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="course_discounted_price">Discounted Price (if any)</label>
                            <input type="number" class="form-control" id="course_discounted_price" name="course_discounted_price">
                        </div>
                        
                        <div class="form-group">
                            <label for="course_image">Course Image</label>
                            <div class="image-preview" id="imagePreview">
                                <i class="fas fa-image" style="font-size: 2rem; color: #ccc;"></i>
                            </div>
                            <input type="file" class="form-control" id="course_image" name="course_image" accept="image/*">
                        </div>
                        
                        <div class="form-group">
                            <label>Features (Add at least 3)</label>
                            <div id="course-features">
                                <div class="d-flex mb-2">
                                    <input type="text" class="form-control" name="course_features[]" placeholder="Feature 1" required>
                                    <button type="button" class="btn btn-danger ml-2 remove-feature" style="display: none;">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                            <button type="button" class="btn btn-sm btn-secondary" id="add-feature">
                                <i class="fas fa-plus"></i> Add Feature
                            </button>
                        </div>
                        
                        <div class="form-group">
                            <label for="course_status">Status</label>
                            <select class="form-control" id="course_status" name="course_status" required>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-success" name="save_course">
                                <i class="fas fa-save"></i> Save Course
                            </button>
                            <button type="button" class="btn btn-danger" id="cancel-course">
                                <i class="fas fa-times"></i> Cancel
                            </button>
                        </div>
                    </form>
                </div>
                
                <!-- Courses List -->
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Image</th>
                                <th>Title</th>
                                <th>Class</th>
                                <th>Price</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php include 'fetch_courses_admin.php'; ?>
                            <!-- Sample Row -->
                            <tr>
                                <td>1</td>
                                <td><img src="six.jpg" alt="Class 6" style="width: 50px; height: 50px; object-fit: cover;"></td>
                                <td>Class 6 Foundation Program</td>
                                <td>6</td>
                                <td>₹12,999</td>
                                <td><span class="badge badge-success">Active</span></td>
                                <td class="action-btns">
                                    <button class="btn btn-sm btn-primary edit-course" data-id="1">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger delete-course" data-id="1">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <!-- More rows would be generated from PHP -->
                        </tbody>
                    </table>
                </div>
            </section>

            <!-- Gallery Management Section -->
            <section id="gallery-management" class="section">
                <div class="section-header">
                    <h2>Manage Gallery</h2>
                    <button class="btn btn-primary">
                        <i class="fas fa-plus"></i> Add Image
                    </button>
                </div>
                <form id="gallery-form" action="upload.php" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="gallery-image">Upload Image:</label>
                        <input type="file" class="form-control" id="gallery-image" name="gallery-image" accept="image/*" required>
                    </div>
                    <button type="submit" class="btn btn-success" name="upload_gallery">
                        <i class="fas fa-upload"></i> Upload
                    </button>
                </form>
                <div id="gallery-list" class="mt-4">
                    <?php include 'fetch_gallery_admin.php'; ?>
                </div>
            </section>

            <!-- Results Management Section -->
            <section id="result-management" class="section">
                <div class="section-header">
                    <h2>Manage Results</h2>
                    <button class="btn btn-primary">
                        <i class="fas fa-plus"></i> Add Result
                    </button>
                </div>
                <form id="result-form" action="upload.php" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="result-file">Upload Result File:</label>
                        <input type="file" class="form-control" id="result-file" name="result-file" required>
                    </div>
                    <button type="submit" class="btn btn-success" name="upload_result">
                        <i class="fas fa-upload"></i> Upload
                    </button>
                </form>
                <div id="result-list" class="mt-4">
                    <?php include 'fetch_results_admin.php'; ?>
                </div>
            </section>

            <!-- Study Material Management Section -->
            <section id="study-material-management" class="section">
                <div class="section-header">
                    <h2>Manage Study Material</h2>
                    <button class="btn btn-primary">
                        <i class="fas fa-plus"></i> Add Material
                    </button>
                </div>
                <form id="study-material-form" action="upload.php" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="study-material-file">Upload Study Material:</label>
                        <input type="file" class="form-control" id="study-material-file" name="study-material-file" required>
                    </div>
                    <button type="submit" class="btn btn-success" name="upload_study_material">
                        <i class="fas fa-upload"></i> Upload
                    </button>
                </form>
                <div id="study-material-list" class="mt-4">
                    <?php include 'fetch_study_material_admin.php'; ?>
                </div>
            </section>
        </main>
    </div>

    <script>
        // Course Management Script
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle Course Form
            const addCourseBtn = document.getElementById('addCourseBtn');
            const courseFormContainer = document.getElementById('course-form-container');
            const cancelCourseBtn = document.getElementById('cancel-course');
            
            addCourseBtn.addEventListener('click', function() {
                courseFormContainer.style.display = 'block';
                window.scrollTo({
                    top: courseFormContainer.offsetTop - 20,
                    behavior: 'smooth'
                });
            });
            
            cancelCourseBtn.addEventListener('click', function() {
                courseFormContainer.style.display = 'none';
                document.getElementById('course-form').reset();
                document.getElementById('imagePreview').innerHTML = '<i class="fas fa-image" style="font-size: 2rem; color: #ccc;"></i>';
            });
            
            // Image Preview
            const courseImageInput = document.getElementById('course_image');
            const imagePreview = document.getElementById('imagePreview');
            
            courseImageInput.addEventListener('change', function() {
                const file = this.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        imagePreview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
                    }
                    reader.readAsDataURL(file);
                }
            });
            
            // Add/Remove Features
            const addFeatureBtn = document.getElementById('add-feature');
            const courseFeatures = document.getElementById('course-features');
            
            addFeatureBtn.addEventListener('click', function() {
                const featureCount = courseFeatures.querySelectorAll('input').length;
                const newFeature = document.createElement('div');
                newFeature.className = 'd-flex mb-2';
                newFeature.innerHTML = `
                    <input type="text" class="form-control" name="course_features[]" placeholder="Feature ${featureCount + 1}" required>
                    <button type="button" class="btn btn-danger ml-2 remove-feature">
                        <i class="fas fa-times"></i>
                    </button>
                `;
                courseFeatures.appendChild(newFeature);
                
                // Show remove buttons for all features if more than one
                if (featureCount > 0) {
                    const firstRemoveBtn = courseFeatures.querySelector('.remove-feature');
                    firstRemoveBtn.style.display = 'block';
                }
            });
            
            // Remove Feature
            courseFeatures.addEventListener('click', function(e) {
                if (e.target.classList.contains('remove-feature') || e.target.closest('.remove-feature')) {
                    const featureItem = e.target.closest('.d-flex');
                    if (courseFeatures.querySelectorAll('.d-flex').length > 1) {
                        featureItem.remove();
                    }
                    
                    // Hide remove button if only one feature left
                    if (courseFeatures.querySelectorAll('.d-flex').length === 1) {
                        courseFeatures.querySelector('.remove-feature').style.display = 'none';
                    }
                }
            });
            
            // Edit Course
            const editCourseBtns = document.querySelectorAll('.edit-course');
            editCourseBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const courseId = this.getAttribute('data-id');
                    // In a real application, you would fetch the course data via AJAX
                    // Here's a simulation:
                    const courseData = {
                        id: courseId,
                        title: "Class 6 Foundation Program",
                        class: "6",
                        description: "Build unshakable foundations in mathematics and science with our engaging Class 6 program designed by expert educators.",
                        duration: "10 Months",
                        price: "12999",
                        discounted_price: "11999",
                        status: "active",
                        features: [
                            "Comprehensive curriculum coverage",
                            "Interactive learning methods",
                            "Regular progress tracking"
                        ]
                    };
                    
                    // Fill the form with course data
                    document.getElementById('course_id').value = courseData.id;
                    document.getElementById('course_title').value = courseData.title;
                    document.getElementById('course_class').value = courseData.class;
                    document.getElementById('course_description').value = courseData.description;
                    document.getElementById('course_duration').value = courseData.duration;
                    document.getElementById('course_price').value = courseData.price;
                    document.getElementById('course_discounted_price').value = courseData.discounted_price;
                    document.getElementById('course_status').value = courseData.status;
                    
                    // Clear and add features
                    courseFeatures.innerHTML = '';
                    courseData.features.forEach((feature, index) => {
                        const featureDiv = document.createElement('div');
                        featureDiv.className = 'd-flex mb-2';
                        featureDiv.innerHTML = `
                            <input type="text" class="form-control" name="course_features[]" value="${feature}" required>
                            <button type="button" class="btn btn-danger ml-2 remove-feature" ${index === 0 ? 'style="display: none;"' : ''}>
                                <i class="fas fa-times"></i>
                            </button>
                        `;
                        courseFeatures.appendChild(featureDiv);
                    });
                    
                    // Show image preview (in real app, you'd fetch the image URL)
                    imagePreview.innerHTML = '<img src="six.jpg" alt="Course Image">';
                    
                    // Show form
                    courseFormContainer.style.display = 'block';
                    window.scrollTo({
                        top: courseFormContainer.offsetTop - 20,
                        behavior: 'smooth'
                    });
                });
            });
            
            // Delete Course
            const deleteCourseBtns = document.querySelectorAll('.delete-course');
            deleteCourseBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const courseId = this.getAttribute('data-id');
                    if (confirm('Are you sure you want to delete this course?')) {
                        // In a real application, you would send an AJAX request to delete the course
                        alert(`Course ${courseId} would be deleted in a real application`);
                        // Then you would remove the row from the table or refresh the page
                    }
                });
            });
        });
    </script>
</body>
</html>