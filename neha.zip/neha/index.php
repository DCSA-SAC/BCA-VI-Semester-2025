
<?php
    session_start(); // Start session to track user login status
    $title = "Score Up Institute - Home";
    $contact_email = "saiindiaclasses@yahoo.com";
    $contact_phone = "+8269630257, +9131339737";
    $address = "413/1, Plot No. 33, Mahakoushal Square, Near Aman Apartment & S.P. Bungalow, South Civil Line, Jabalpur";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Score Up Jabalpur - Premier Coaching Institute</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        /* Base Styles with Premium Color Palette */
        :root {
            --primary: #4361ee;
            --primary-light: #4895ef;
            --secondary: #f72585;
            --accent: #4cc9f0;
            --dark: #14213d;
            --light: #f8f9fa;
            --success: #38b000;
            --gradient: linear-gradient(135deg, var(--primary), var(--primary-light));
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background-color: #ffffff;
            color: #333;
            overflow-x: hidden;
            line-height: 1.6;
        }
        
        h1, h2, h3, h4 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
        }
        
        /* Premium Header with 3D Effect */
        header {
            background: var(--gradient);
            color: white;
            padding: 1.2rem 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            box-shadow: 0 10px 30px rgba(67, 97, 238, 0.3);
            transform: translateY(0);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border-bottom: 3px solid rgba(255,255,255,0.1);
        }
        
        header.scrolled {
            padding: 0.8rem 5%;
            backdrop-filter: blur(5px);
            background: rgba(67, 97, 238, 0.95);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
        }
        
        .logo h1 {
            font-size: 2rem;
            background: linear-gradient(to right, #fff, #e0f2fe);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: relative;
            padding-left: 15px;
        }
        
        .logo h1:before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            height: 70%;
            width: 4px;
            background: var(--secondary);
            border-radius: 2px;
        }
        
        /* Premium Navigation */
        nav ul {
            display: flex;
            list-style: none;
            align-items: center;
        }
        
        nav ul li {
            margin: 0 1.2rem;
            position: relative;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: 600;
            padding: 0.6rem 0;
            position: relative;
            transition: all 0.3s ease;
            font-size: 1.05rem;
        }
        
        nav ul li a:after {
            content: '';
            position: absolute;
            width: 0;
            height: 3px;
            background: var(--secondary);
            bottom: 0;
            left: 0;
            transition: width 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border-radius: 3px;
        }
        
        nav ul li a:hover:after {
            width: 100%;
        }
        
        /* Luxury Dropdown */
        .dropdown-content {
            display: none;
            position: absolute;
            background: white;
            min-width: 220px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
            border-radius: 8px;
            z-index: 1;
            opacity: 0;
            transform: translateY(10px);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            padding: 10px 0;
            border-top: 3px solid var(--secondary);
        }
        
        .dropdown:hover .dropdown-content {
            display: block;
            opacity: 1;
            transform: translateY(0);
            animation: fadeInDropdown 0.4s ease;
        }
        
        @keyframes fadeInDropdown {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .dropdown-content a {
            color: var(--dark);
            padding: 12px 20px;
            display: block;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            position: relative;
            overflow: hidden;
        }
        
        .dropdown-content a:before {
            content: '';
            position: absolute;
            left: -100%;
            top: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(67, 97, 238, 0.05), transparent);
            transition: 0.5s;
        }
        
        .dropdown-content a:hover {
            background: rgba(67, 97, 238, 0.03);
            color: var(--primary);
            padding-left: 25px;
        }
        
        .dropdown-content a:hover:before {
            left: 100%;
        }
        
        /* Premium Auth Buttons */
        .auth-btn {
            padding: 0.6rem 1.5rem;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            margin-left: 1.5rem;
            font-size: 0.95rem;
            letter-spacing: 0.5px;
            position: relative;
            overflow: hidden;
            border: none;
            cursor: pointer;
        }
        
        .login-btn {
            background: white;
            color: var(--primary);
            box-shadow: 0 5px 15px rgba(255,255,255,0.3);
        }
        
        .login-btn:hover {
            background: var(--secondary);
            color: white;
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(247, 37, 133, 0.4);
        }
        
        .logout-btn {
            background: var(--secondary);
            color: white;
            box-shadow: 0 5px 15px rgba(247, 37, 133, 0.3);
        }
        
        .logout-btn:hover {
            background: #e5177e;
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(247, 37, 133, 0.4);
        }
        
        /* Luxury Banner with Particle Animation */
        .banner {
            background: linear-gradient(rgba(20, 33, 61, 0.85), rgba(20, 33, 61, 0.9)), url('https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: white;
            position: relative;
            overflow: hidden;
        }
        
        .particles {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
        }
        
        .particle {
            position: absolute;
            background: rgba(255,255,255,0.6);
            border-radius: 50%;
            pointer-events: none;
        }
        
        .banner-content {
            position: relative;
            z-index: 1;
            max-width: 900px;
            padding: 0 2rem;
            animation: fadeInUp 1s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(80px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .banner h2 {
            font-size: 3.5rem;
            margin-bottom: 1.5rem;
            text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.3);
            line-height: 1.2;
            background: linear-gradient(to right, #fff, #e0f2fe);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .banner p {
            font-size: 1.3rem;
            margin-bottom: 2.5rem;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.3);
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }
        
        /* Premium CTA Button */
        .cta-button {
            display: inline-block;
            padding: 1rem 2.5rem;
            background: var(--gradient);
            color: white;
            text-decoration: none;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-shadow: 0 10px 30px rgba(67, 97, 238, 0.5);
            position: relative;
            overflow: hidden;
            border: none;
            font-size: 1.1rem;
            letter-spacing: 0.5px;
            cursor: pointer;
        }
        
        .cta-button:hover {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            transform: translateY(-5px) scale(1.05);
            box-shadow: 0 15px 40px rgba(67, 97, 238, 0.6);
        }
        
        .cta-button:active {
            transform: translateY(-2px);
        }
        
        .cta-button:after {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.6s;
        }
        
        .cta-button:hover:after {
            left: 100%;
        }
        
        /* Premium Success Stories */
        .success-stories {
            padding: 6rem 5%;
            text-align: center;
            background: #f9f9f9;
            position: relative;
            overflow: hidden;
        }
        
        .success-stories:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80') center/cover;
            opacity: 0.03;
            z-index: 0;
        }
        
        .success-stories h2 {
            font-size: 2.8rem;
            margin-bottom: 3rem;
            color: var(--dark);
            position: relative;
            display: inline-block;
            z-index: 1;
        }
        
        .success-stories h2:after {
            content: '';
            position: absolute;
            width: 60%;
            height: 4px;
            background: var(--gradient);
            bottom: -15px;
            left: 20%;
            border-radius: 2px;
        }
        
        .stories-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 2.5rem;
            margin-top: 3rem;
            position: relative;
            z-index: 1;
        }
        
        .story {
            background: white;
            padding: 2.5rem;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            width: 320px;
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            opacity: 0;
            transform: translateY(40px);
            position: relative;
            overflow: hidden;
            border: 1px solid rgba(67, 97, 238, 0.1);
        }
        
        .story:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
            background: var(--gradient);
            transition: all 0.4s ease;
        }
        
        .story.animated {
            opacity: 1;
            transform: translateY(0);
        }
        
        .story:nth-child(1) { transition-delay: 0.1s; }
        .story:nth-child(2) { transition-delay: 0.2s; }
        .story:nth-child(3) { transition-delay: 0.3s; }
        
        .story:hover {
            transform: translateY(-15px) scale(1.03);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }
        
        .story h3 {
            color: var(--primary);
            margin-bottom: 1.5rem;
            font-size: 1.4rem;
        }
        
        .story p {
            color: #555;
            font-style: italic;
            font-size: 1.05rem;
        }
        
        .story .quote-icon {
            color: rgba(67, 97, 238, 0.1);
            font-size: 3rem;
            position: absolute;
            right: 20px;
            bottom: 10px;
            line-height: 1;
        }
        
        /* Premium About Us Section */
        .about-us {
            padding: 6rem 5%;
            text-align: center;
            background: white;
            position: relative;
            overflow: hidden;
        }
        
        .about-us:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80') center/cover;
            opacity: 0.03;
            z-index: 0;
        }
        
        .about-us h2 {
            font-size: 2.8rem;
            margin-bottom: 1.5rem;
            color: var(--dark);
            position: relative;
            z-index: 1;
        }
        
        .about-us p {
            max-width: 750px;
            margin: 0 auto 3rem;
            font-size: 1.15rem;
            line-height: 1.8;
            color: #555;
            position: relative;
            z-index: 1;
        }
        
        /* Luxury Courses Section */
        .courses {
            padding: 6rem 5%;
            text-align: center;
            background: linear-gradient(135deg, #f5f7fa 0%, #e6e9f2 100%);
            position: relative;
            overflow: hidden;
        }
        
        .courses h2 {
            font-size: 2.8rem;
            margin-bottom: 3rem;
            color: var(--dark);
            position: relative;
            z-index: 1;
        }
        
        .course-list {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 2.5rem;
            margin-bottom: 3rem;
            position: relative;
            z-index: 1;
        }
        
        .course {
            background: white;
            padding: 2.5rem;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            width: 350px;
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
            border: 1px solid rgba(67, 97, 238, 0.1);
        }
        
        .course:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: var(--gradient);
            transition: all 0.4s ease;
        }
        
        .course:hover {
            transform: translateY(-15px) scale(1.03);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }
        
        .course h3 {
            color: var(--primary);
            margin-bottom: 1.5rem;
            font-size: 1.5rem;
        }
        
        .course p {
            color: #666;
            font-size: 1.05rem;
            margin-bottom: 1.5rem;
        }
        
        .course .course-icon {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 1.5rem;
            display: inline-block;
        }
        
        /* Premium Gallery Section */
        .gallery {
            padding: 6rem 5%;
            text-align: center;
            background: white;
            position: relative;
            overflow: hidden;
        }
        
        .gallery h2 {
            font-size: 2.8rem;
            margin-bottom: 3rem;
            color: var(--dark);
        }
        
        .gallery-preview {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 1.5rem;
            margin-bottom: 3rem;
        }
        
        .gallery-preview img {
            width: 350px;
            height: 280px;
            object-fit: cover;
            border-radius: 10px;
            cursor: pointer;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
        }
        
        .gallery-preview img:hover {
            transform: scale(1.05);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }
        
        .gallery-preview img:after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.3);
            opacity: 0;
            transition: all 0.3s ease;
            border-radius: 10px;
        }
        
        .gallery-preview img:hover:after {
            opacity: 1;
        }
        
        /* Luxury Lightbox */
        #lightbox {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.95);
            justify-content: center;
            align-items: center;
            z-index: 2000;
            opacity: 0;
            transition: opacity 0.4s ease;
        }
        
        #lightbox.show {
            display: flex;
            opacity: 1;
        }
        
        #lightbox-img {
            max-width: 85%;
            max-height: 85%;
            border-radius: 8px;
            animation: zoomIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-shadow: 0 20px 50px rgba(0,0,0,0.5);
        }
        
        @keyframes zoomIn {
            from { transform: scale(0.8); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        
        #lightbox span {
            position: absolute;
            top: 30px;
            right: 40px;
            font-size: 50px;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
            text-shadow: 0 2px 5px rgba(0,0,0,0.3);
        }
        
        #lightbox span:hover {
            transform: rotate(90deg);
            color: var(--secondary);
        }
        
        /* Premium Testimonials */
        .testimonials {
            padding: 6rem 5%;
            text-align: center;
            background: var(--gradient);
            color: white;
            position: relative;
            overflow: hidden;
        }
        
        .testimonials:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80') center/cover;
            opacity: 0.05;
            z-index: 0;
        }
        
        .testimonials h2 {
            font-size: 2.8rem;
            margin-bottom: 3rem;
            position: relative;
            z-index: 1;
        }
        
        blockquote {
            max-width: 800px;
            margin: 0 auto;
            font-size: 1.3rem;
            line-height: 1.8;
            position: relative;
            padding: 3rem;
            z-index: 1;
        }
        
        blockquote:before, blockquote:after {
            content: '"';
            font-size: 5rem;
            color: rgba(255, 255, 255, 0.1);
            position: absolute;
            font-family: Georgia, serif;
            line-height: 1;
        }
        
        blockquote:before {
            top: 0;
            left: 0;
        }
        
        blockquote:after {
            bottom: -40px;
            right: 0;
        }
        
        blockquote p {
            margin-bottom: 1.5rem;
            font-style: italic;
        }
        
        blockquote footer {
            font-weight: bold;
            color: var(--accent);
            font-size: 1.2rem;
        }
        
        /* Premium Contact Section */
        .contact {
            padding: 6rem 5%;
            text-align: center;
            background: white;
            position: relative;
            overflow: hidden;
        }
        
        .contact:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80') center/cover;
            opacity: 0.03;
            z-index: 0;
        }
        
        .contact h2 {
            font-size: 2.8rem;
            margin-bottom: 3rem;
            color: var(--dark);
            position: relative;
            z-index: 1;
        }
        
        .contact p {
            margin-bottom: 1rem;
            font-size: 1.15rem;
            color: #555;
            position: relative;
            z-index: 1;
        }
        
        .contact-info {
            max-width: 600px;
            margin: 0 auto 3rem;
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            position: relative;
            z-index: 1;
            border: 1px solid rgba(67, 97, 238, 0.1);
        }
        
        /* Luxury Footer */
        footer {
            background: var(--dark);
            color: white;
            text-align: center;
            padding: 3rem 5%;
            position: relative;
        }
        
        footer:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: var(--gradient);
        }
        
        footer p {
            margin-bottom: 1.5rem;
            font-size: 1rem;
        }
        
        .social-media {
            margin-top: 1.5rem;
        }
        
        .social-media a {
            color: white;
            margin: 0 15px;
            font-size: 1.3rem;
            transition: all 0.3s ease;
            display: inline-block;
        }
        
        .social-media a:hover {
            color: var(--accent);
            transform: translateY(-5px) scale(1.2);
        }
        
        .back-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 50px;
            height: 50px;
            background: var(--gradient);
            color: white;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 1.2rem;
            cursor: pointer;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.4);
            z-index: 999;
        }
        
        .back-to-top.active {
            opacity: 1;
            visibility: visible;
        }
        
        .back-to-top:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(67, 97, 238, 0.6);
        }
        
        /* Floating Animation */
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }
        
        .floating {
            animation: float 4s ease-in-out infinite;
        }
        
        /* Pulse Animation */
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .pulse {
            animation: pulse 3s ease infinite;
        }
        
        /* Responsive Design */
        @media (max-width: 992px) {
            .banner h2 {
                font-size: 2.8rem;
            }
            
            .banner p {
                font-size: 1.2rem;
            }
        }
        
        @media (max-width: 768px) {
            header {
                flex-direction: column;
                padding: 1rem;
            }
            
            nav ul {
                flex-direction: column;
                align-items: center;
                margin-top: 1rem;
            }
            
            nav ul li {
                margin: 0.8rem 0;
            }
            
            .auth-btn {
                margin-left: 0;
                margin-top: 1rem;
            }
            
            .banner h2 {
                font-size: 2.2rem;
            }
            
            .banner p {
                font-size: 1.1rem;
            }
            
            .stories-container, .course-list {
                flex-direction: column;
                align-items: center;
            }
            
            .story, .course {
                width: 100%;
                max-width: 400px;
            }
            
            .gallery-preview img {
                width: 100%;
                max-width: 400px;
                height: 250px;
            }
            
            blockquote {
                font-size: 1.1rem;
                padding: 2rem 1rem;
            }
        }
        
        @media (max-width: 576px) {
            .banner h2 {
                font-size: 1.8rem;
            }
            
            .cta-button {
                padding: 0.8rem 1.8rem;
                font-size: 1rem;
            }
            
            .success-stories h2, 
            .about-us h2, 
            .courses h2, 
            .gallery h2, 
            .testimonials h2, 
            .contact h2 {
                font-size: 2.2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Premium Header with 3D Effect -->
    <header id="main-header">
        <div class="logo">
            <h1>Score Up Jabalpur</h1>
        </div>
        <nav>
            <ul>
                <li><a href="about.html">About Us</a></li>
                <li><a href="courses.html">Courses</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">Student Corner</a>
                    <div class="dropdown-content">
                        <a href="#" onclick="redirectToLogin('results.php')">Result</a>
                        <a href="#" onclick="redirectToLogin('study_material.php')">Study Materials</a>
                    </div>
                </li>
                <?php if (isset($_SESSION['username'])): ?>
                    <a href="logout.php" class="auth-btn logout-btn">
                        Logout (<?php echo $_SESSION['username']; ?>)
                    </a>
                <?php else: ?>
                    <a href="login.html" class="auth-btn login-btn">
                        Login
                    </a>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <!-- Luxury Banner with Particle Animation -->
    <section class="banner">
        <div class="particles" id="particles-js"></div>
        <div class="banner-content">
            <h2 class="floating">Empowering Students to Achieve Excellence</h2>
            <p class="pulse">Join our premier institute to unlock your potential and achieve your academic dreams</p>
            <a href="login.html" class="cta-button pulse">Start Your Journey</a>
        </div>
    </section>

    <!-- Premium Success Stories -->
    <section class="success-stories">
        <h2>Student Success Stories</h2>
        <div class="stories-container">
            <div class="story">
                <h3>Rohit Sharma</h3>
                <p>"Thanks to Score Up Jabalpur, I aced my board exams with 95% and got into my dream college!"</p>
                <div class="quote-icon">
                    <i class="fas fa-quote-right"></i>
                </div>
            </div>
            <div class="story">
                <h3>Priya Verma</h3>
                <p>"The expert guidance and amazing resources helped me crack JEE with AIR 1500."</p>
                <div class="quote-icon">
                    <i class="fas fa-quote-right"></i>
                </div>
            </div>
            <div class="story">
                <h3>Amit Kumar</h3>
                <p>"This coaching changed my perspective on learning. My conceptual clarity improved dramatically!"</p>
                <div class="quote-icon">
                    <i class="fas fa-quote-right"></i>
                </div>
            </div>
        </div>
    </section>

    <!-- Premium About Us Section -->
    <section class="about-us">
        <h2>About Us</h2>
        <p>With over a decade of excellence in education, Score Up Jabalpur has established itself as a premier coaching institute. Our dedicated faculty, innovative teaching methods, and personalized attention create an environment where students thrive academically and personally.</p>
        <a href="about.html" class="cta-button">Discover More</a>
    </section>

    <!-- Luxury Courses Section -->
    <section class="courses">
        <h2>Our Courses</h2>
        <div class="course-list">
            <div class="course">
                <div class="course-icon">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <h3>Class 7-10</h3>
                <p>Comprehensive coaching for CBSE and MP Board students with regular tests and doubt sessions.</p>
            </div>
            <div class="course">
                <div class="course-icon">
                    <i class="fas fa-atom"></i>
                </div>
                <h3>Class 11-12</h3>
                <p>Specialized coaching for Science and Commerce streams with board exam preparation.</p>
            </div>
            <div class="course">
                <div class="course-icon">
                    <i class="fas fa-trophy"></i>
                </div>
                <h3>Competitive Exams</h3>
                <p>Preparation for JEE, NEET and other competitive exams with expert guidance.</p>
            </div>
        </div>
        <a href="courses.html" class="cta-button">Explore All Courses</a>
    </section>
    
    <!-- Premium Gallery Section -->
    <section class="gallery">
        <h2>Our Gallery</h2>
        <div class="gallery-preview">
            <?php
            include 'db.php';
            $query = "SELECT * FROM gallery ORDER BY id DESC LIMIT 3";
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '
                    <img src="'.$row['filepath'].'" alt="'.$row['caption'].'" 
                        onclick="openLightbox(this.src)">
                    ';
                }
            } else {
                echo '<p>No images available in the gallery.</p>';
            }
            ?>
        </div>
        <a href="gallery.php" class="cta-button">View Full Gallery</a>
    </section>

    <!-- Luxury Lightbox -->
    <div id="lightbox">
        <span onclick="closeLightbox()">&times;</span>
        <img id="lightbox-img">
    </div>

    <!-- Premium Testimonials -->
    <section class="testimonials">
        <h2>What Our Students Say</h2>
        <blockquote>
            <p>"Score Up Jabalpur transformed my academic journey completely. The teachers are incredibly supportive, the study materials are excellent, and the regular tests helped me identify my weak areas. I went from average to top performer in my school!"</p>
            <footer>- Neha Tiwari (96.4% in CBSE 12th Boards)</footer>
        </blockquote>
    </section>

    <!-- Premium Contact Section -->
    <section class="contact">
        <h2>Contact Us</h2>
        <div class="contact-info">
            <p><i class="fas fa-map-marker-alt"></i> 413/1, Plot No. 33, Mahakoushal Square, Near Aman Apartment & S.P. Bungalow, South Civil Line, Jabalpur</p>
            <p><i class="fas fa-envelope"></i> saiindiaclasses@yahoo.com</p>
            <p><i class="fas fa-phone"></i> +918269630257, +919131339737</p>
        </div>
        <a href="contact.html" class="cta-button">Get in Touch</a>
    </section>

    <!-- Luxury Footer -->
    <footer>
        <p>&copy; 2025 Score Up Jabalpur. All rights reserved.</p>
        <div class="social-media">
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <div class="back-to-top" id="backToTop">
        <i class="fas fa-arrow-up"></i>
    </div>

    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <script>
        

        // Header Scroll Animation
        window.addEventListener('scroll', function() {
            const header = document.getElementById('main-header');
            const backToTop = document.getElementById('backToTop');
            
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
            
            if (window.scrollY > 300) {
                backToTop.classList.add('active');
            } else {
                backToTop.classList.remove('active');
            }
        });

        // Back to Top Button
        document.getElementById('backToTop').addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });

        // Animate Elements on Scroll
        function animateOnScroll() {
            const elements = document.querySelectorAll('.story, .course');
            elements.forEach((el, index) => {
                const elementPosition = el.getBoundingClientRect().top;
                const screenPosition = window.innerHeight / 1.2;
                
                if (elementPosition < screenPosition) {
                    el.classList.add('animated');
                }
            });
        }

        window.addEventListener('scroll', animateOnScroll);
        window.addEventListener('load', animateOnScroll);

        // Lightbox Functionality
        function openLightbox(src) {
            const lightbox = document.getElementById('lightbox');
            const lightboxImg = document.getElementById('lightbox-img');
            
            lightboxImg.src = src;
            lightbox.classList.add('show');
            document.body.style.overflow = 'hidden';
        }

        function closeLightbox() {
            const lightbox = document.getElementById('lightbox');
            lightbox.classList.remove('show');
            document.body.style.overflow = 'auto';
        }

        // Redirect to Login Function
        function redirectToLogin(page) {
            <?php if (isset($_SESSION['username'])): ?>
                window.location.href = page;
            <?php else: ?>
                if(confirm('You need to login first. Go to login page?')) {
                    window.location.href = 'login.html?redirect=' + encodeURIComponent(page);
                }
            <?php endif; ?>
        }

        // Initialize Particle.js
        document.addEventListener('DOMContentLoaded', function() {
            if (document.getElementById('particles-js')) {
                particlesJS('particles-js', {
                    "particles": {
                        "number": {
                            "value": 80,
                            "density": {
                                "enable": true,
                                "value_area": 800
                            }
                        },
                        "color": {
                            "value": "#ffffff"
                        },
                        "shape": {
                            "type": "circle",
                            "stroke": {
                                "width": 0,
                                "color": "#000000"
                            },
                            "polygon": {
                                "nb_sides": 5
                            }
                        },
                        "opacity": {
                            "value": 0.5,
                            "random": true,
                            "anim": {
                                "enable": true,
                                "speed": 1,
                                "opacity_min": 0.1,
                                "sync": false
                            }
                        },
                        "size": {
                            "value": 3,
                            "random": true,
                            "anim": {
                                "enable": true,
                                "speed": 2,
                                "size_min": 0.1,
                                "sync": false
                            }
                        },
                        "line_linked": {
                            "enable": true,
                            "distance": 150,
                            "color": "#ffffff",
                            "opacity": 0.2,
                            "width": 1
                        },
                        "move": {
                            "enable": true,
                            "speed": 1,
                            "direction": "none",
                            "random": true,
                            "straight": false,
                            "out_mode": "out",
                            "bounce": false,
                            "attract": {
                                "enable": true,
                                "rotateX": 600,
                                "rotateY": 1200
                            }
                        }
                    },
                    "interactivity": {
                        "detect_on": "canvas",
                        "events": {
                            "onhover": {
                                "enable": true,
                                "mode": "grab"
                            },
                            "onclick": {
                                "enable": true,
                                "mode": "push"
                            },
                            "resize": true
                        },
                        "modes": {
                            "grab": {
                                "distance": 140,
                                "line_linked": {
                                    "opacity": 0.5
                                }
                            },
                            "bubble": {
                                "distance": 400,
                                "size": 40,
                                "duration": 2,
                                "opacity": 8,
                                "speed": 3
                            },
                            "repulse": {
                                "distance": 200,
                                "duration": 0.4
                            },
                            "push": {
                                "particles_nb": 4
                            },
                            "remove": {
                                "particles_nb": 2
                            }
                        }
                    },
                    "retina_detect": true
                });
            }
        });

        // Floating Animation for Elements
        document.querySelectorAll('.floating').forEach(el => {
            el.style.animationDelay = Math.random() * 2 + 's';
        });
    </script>
</body>
</html>
   