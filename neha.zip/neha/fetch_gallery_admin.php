<?php
$dir = "uploads/gallery/";
$images = array_diff(scandir($dir), array('..', '.'));

foreach ($images as $image) {
    if (preg_match('/\.(jpg|jpeg|png|gif)$/', $image)) {
        echo "<div style='display: inline-block; margin: 10px; text-align: center;'>
                <img src='$dir$image' alt='$image' style='width: 150px; height: auto;'>
                <form action='upload.php' method='post' style='display: inline;'>
                    <input type='hidden' name='file' value='$image'>
                    <button type='submit' name='delete_gallery'>Delete</button>
                </form>
              </div>";
    }
}
?>