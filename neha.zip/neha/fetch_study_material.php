<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Materials</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            background: linear-gradient(to right, #ffecd2, #fcb69f);
            color: #333;
            font-family: 'Poppins', sans-serif;
            text-align: center;
            margin: 0;
            padding: 20px;
        }
        h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            color: #ff5733;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
            animation: fadeIn 1s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        #study-material {
            display: flex;
            justify-content: center;
            padding: 20px;
            max-width: 1300px;
            margin: auto;
            animation: slideUp 1s ease-in-out;
        }
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(50px); }
            to { opacity: 1; transform: translateY(0); }
        }
        table {
            width: 90%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
        }
        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #ff5733;
            color: #fff;
            font-size: 1.2rem;
            text-transform: uppercase;
        }
        tr:hover {
            background-color: #fcb69f;
            color: #fff;
            transition: 0.3s ease-in-out;
        }
        a {
            text-decoration: none;
            color: #ff5733;
            font-weight: 600;
        }
        a:hover {
            color: #c70039;
        }
    </style>
</head>
<body>
    <h1></h1>
    <div id="study-material">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>File Name</th>
                    <th>Download</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $dir = "uploads/study_material/";
                $files = array_diff(scandir($dir), array('..', '.'));
                $id = 1;
                
                foreach ($files as $file) {
                    if (!preg_match('/\.(jpg|jpeg|png|gif)$/', $file)) {
                        echo "<tr>
                                <td>" . $id . "</td>
                                <td>" . htmlspecialchars($file) . "</td>
                                <td><a href='" . $dir . $file . "' download>Download</a></td>
                              </tr>";
                        $id++;
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
