<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

require_once 'db.php';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $course_id = $_POST['course_id'] ?? 0;
    $title = $_POST['course_title'];
    $class = $_POST['course_class'];
    $description = $_POST['course_description'];
    $duration = $_POST['course_duration'];
    $price = $_POST['course_price'];
    $discounted_price = $_POST['course_discounted_price'] ?? null;
    $status = $_POST['course_status'];
    
    // Process features if they exist
    $features = isset($_POST['course_features']) ? implode('|', $_POST['course_features']) : null;
    
    // Handle file upload
    $image_path = '';
    if (isset($_FILES['course_image']) && $_FILES['course_image']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "uploads/courses/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $file_ext = pathinfo($_FILES['course_image']['name'], PATHINFO_EXTENSION);
        $filename = "course_" . time() . "." . $file_ext;
        $target_file = $target_dir . $filename;
        
        if (move_uploaded_file($_FILES['course_image']['tmp_name'], $target_file)) {
            $image_path = $target_file;
            
            // Delete old image if updating
            if ($course_id > 0) {
                $sql = "SELECT image_path FROM courses WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $course_id);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($row = $result->fetch_assoc()) {
                    if (!empty($row['image_path']) && file_exists($row['image_path'])) {
                        unlink($row['image_path']);
                    }
                }
                $stmt->close();
            }
        }
    }
    
    try {
        if ($course_id > 0) {
            // Update existing course
            $sql = "UPDATE courses SET 
                    title = ?, 
                    class = ?, 
                    description = ?, 
                    duration = ?, 
                    price = ?, 
                    discounted_price = ?, 
                    status = ?";
            
            // Add features if column exists
            $check_column = $conn->query("SHOW COLUMNS FROM courses LIKE 'features'");
            if ($check_column->num_rows > 0) {
                $sql .= ", features = ?";
            }
            
            // Add image path if new image was uploaded
            if (!empty($image_path)) {
                $sql .= ", image_path = ?";
            }
            
            $sql .= " WHERE id = ?";
            
            $stmt = $conn->prepare($sql);
            
            // Bind parameters based on what we're updating
            $bind_types = "sisssds";
            $bind_params = [&$title, &$class, &$description, &$duration, &$price, &$discounted_price, &$status];
            
            if ($check_column->num_rows > 0) {
                $bind_types .= "s";
                $bind_params[] = &$features;
            }
            
            if (!empty($image_path)) {
                $bind_types .= "s";
                $bind_params[] = &$image_path;
            }
            
            $bind_types .= "i";
            $bind_params[] = &$course_id;
            
            $stmt->bind_param($bind_types, ...$bind_params);
        } else {
            // Insert new course
            $sql = "INSERT INTO courses (title, class, description, duration, price, discounted_price, status";
            $values = "VALUES (?, ?, ?, ?, ?, ?, ?";
            
            // Add features if column exists
            $check_column = $conn->query("SHOW COLUMNS FROM courses LIKE 'features'");
            if ($check_column->num_rows > 0) {
                $sql .= ", features";
                $values .= ", ?";
            }
            
            // Add image path if provided
            if (!empty($image_path)) {
                $sql .= ", image_path";
                $values .= ", ?";
            }
            
            $sql .= ") " . $values . ")";
            
            $stmt = $conn->prepare($sql);
            
            // Bind parameters based on what we're inserting
            $bind_types = "sisssds";
            $bind_params = [&$title, &$class, &$description, &$duration, &$price, &$discounted_price, &$status];
            
            if ($check_column->num_rows > 0) {
                $bind_types .= "s";
                $bind_params[] = &$features;
            }
            
            if (!empty($image_path)) {
                $bind_types .= "s";
                $bind_params[] = &$image_path;
            }
            
            $stmt->bind_param($bind_types, ...$bind_params);
        }
        
        if ($stmt->execute()) {
            $_SESSION['message'] = "Course " . ($course_id > 0 ? "updated" : "added") . " successfully";
        } else {
            $_SESSION['error'] = "Error: " . $stmt->error;
        }
        
        $stmt->close();
    } catch (mysqli_sql_exception $e) {
        $_SESSION['error'] = "Database error: " . $e->getMessage();
    }
    
    $conn->close();
    
    header('Location: admin.php');
    exit();
}
?>