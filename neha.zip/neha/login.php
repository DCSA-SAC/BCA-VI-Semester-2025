<?php
session_start(); // Start session

$servername = "localhost";
$username = "root";
$password = "";
$database = "coching";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user input
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Fetch the user from the database
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verify hashed password
        if (password_verify($password, $row['password'])) {
            $_SESSION['username'] = $username; // Store session
            echo "<script>alert('Login successful! Redirecting to home page...'); window.location.href = 'index.php';</script>";
        } else {
            echo "<script>alert('Invalid username or password!'); window.location.href = 'login.html';</script>";
        }
    } else {
        echo "<script>alert('User not found! Please sign up.'); window.location.href = 'signup.html';</script>";
    }
}

$conn->close();
?>
