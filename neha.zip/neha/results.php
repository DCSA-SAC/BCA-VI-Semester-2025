<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            background: linear-gradient(to right, #ffecd2, #fcb69f);
            color: #333;
            font-family: 'Poppins', sans-serif;
            text-align: center;
            margin: 0;
            padding: 20px;
        }
        h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            color: #ff5733;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
            animation: fadeIn 1s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        #results {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            padding: 20px;
            max-width: 1300px;
            margin: auto;
            animation: slideUp 1s ease-in-out;
        }
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(50px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .result-item {
            width: 80%;
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
            padding: 15px;
            transition: transform 0.4s ease, box-shadow 0.4s ease;
            cursor: pointer;
        }
        .result-item:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
        }
        .result-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #ff5733;
            margin-bottom: 10px;
        }
        .result-description {
            font-size: 1rem;
            color: #555;
        }
    </style>
</head>
<body>
    <div id="results">
        <?php include 'fetch_results.php'; ?>
    </div>
</body>
</html>
