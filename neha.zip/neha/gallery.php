<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1></h1>
    <div id="gallery">
        <?php include 'fetch_gallery.php'; ?>
    </div>
</body>
</html>