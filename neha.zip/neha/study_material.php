<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Material</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Study Material</h1>
    <div id="study-material">
        <?php include 'fetch_study_material.php'; ?>
    </div>
</body>
</html>