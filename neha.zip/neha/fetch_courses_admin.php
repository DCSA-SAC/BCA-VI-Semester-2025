<?php
// Database connection
require_once 'db.php';

// Fetch courses from database
$sql = "SELECT * FROM courses ORDER BY class ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo '<tr>
                <td>'.$row['id'].'</td>
                <td><img src="'.$row['image_path'].'" alt="'.$row['title'].'" style="width: 50px; height: 50px; object-fit: cover;"></td>
                <td>'.$row['title'].'</td>
                <td>'.$row['class'].'</td>
                <td>₹'.number_format($row['price'], 2).'</td>
                <td><span class="badge '.($row['status'] == 'active' ? 'badge-success' : 'badge-secondary').'">'.ucfirst($row['status']).'</span></td>
                <td class="action-btns">
                    <button class="btn btn-sm btn-primary edit-course" data-id="'.$row['id'].'">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-danger delete-course" data-id="'.$row['id'].'">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>';
    }
} else {
    echo '<tr><td colspan="7" class="text-center">No courses found</td></tr>';
}

$conn->close();
?>