<?php
$dir = "uploads/results/";
$files = array_diff(scandir($dir), array('..', '.'));

foreach ($files as $file) {
    if (!preg_match('/\.(jpg|jpeg|png|gif)$/', $file)) {
        echo "<div style='margin: 10px;'>
                <a href='$dir$file' download>$file</a>
                <form action='upload.php' method='post' style='display: inline;'>
                    <input type='hidden' name='file' value='$file'>
                    <button type='submit' name='delete_result'>Delete</button>
                </form>
              </div>";
    }
}
?>