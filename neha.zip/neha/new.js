import React from 'react';
import './App.css'; // Include your styles in an external CSS file

const Header = () => (
  <header className="header">
    <div className="logo">
      <h1>Score Up Jabalpur</h1>
    </div>
    <nav>
      <ul>
        <li><a href="about.html">About Us</a></li>
        <li><a href="courses.html">Courses</a></li>
        <li><a href="gallery.html">Gallery</a></li>
        <li><a href="contact.html">Contact</a></li>
        <li className="dropdown">
          <span className="dropbtn">Student Corner</span>
          <div className="dropdown-content">
            <a href="result.html">Result</a>
            <a href="attendance.html">Attendance</a>
            <a href="study-materials.html">Study Materials</a>
          </div>
        </li>
      </ul>
    </nav>
  </header>
)



const Banner = () => (
  <section className="banner">
    <div className="banner-content">
      <h2>Empowering Students to Achieve Excellence</h2>
      <p>Join our institute to unlock your potential and achieve your dreams.</p>
      <a href="login.html" className="cta-button">Start Your Journey</a>
    </div>
  </section>
);

const AboutUs = () => (
  <section className="about-us">
    <h2>About Us</h2>
    <p>Our coaching institute has been dedicated to helping students achieve academic success for over a decade. We offer expert guidance and comprehensive resources to ensure every student excels.</p>
    <a href="about.html" className="cta-button">Read More</a>
  </section>
);

const Courses = () => (
  <section className="courses">
    <h2>Courses</h2>
    <div className="course-list">
      <div className="course">
        <h3>Class 7</h3>
        <p>We provide the best education quality</p>
      </div>
      <div className="course">
        <h3>Course 2</h3>
        <p>Brief description of Course 2.</p>
      </div>
      <div className="course">
        <h3>Course 3</h3>
        <p>Brief description of Course 3.</p>
      </div>
    </div>
    <a href="courses.html" className="cta-button">View All Courses</a>
  </section>
);

const Gallery = () => (
  <section className="gallery">
    <h2>Our Gallery</h2>
    <div className="gallery-preview">
      <img src="coach.jpg" alt="Gallery Image 1" />
      <img src="coachi.jpg" alt="Gallery Image 2" />
      <img src="coaching.jpg" alt="Gallery Image 3" />
    </div>
    <a href="gallery.html" className="cta-button">View Gallery</a>
  </section>
);

const Testimonials = () => (
  <section className="testimonials">
    <h2>What Our Students Say</h2>
    <blockquote>
      <p>"This institute has transformed my academic journey. Highly recommended!"</p>
      <footer>- Neha Tiwari</footer>
    </blockquote>
  </section>
);

const Contact = () => (
  <section className="contact">
    <h2>Contact Us</h2>
    <p>Address: 413/1, Plot No. 33, Mahakoushal Square, Near Aman Apartment & S.P. Bungalow, South Civil Line, Jabalpur</p>
    <p>Email: saiindiaclasses@yahoo.com</p>
    <p>Phone: +918269630257, +919131339737</p>
    <a href="contact.html" className="cta-button">Get in Touch</a>
  </section>
);

const Footer = () => (
  <footer>
    <p>&copy; 2025 Coaching Institute. All rights reserved.</p>
    <div className="social-media">
      <a href="#">Instagram: scoreup_jabalpur</a>
    </div>
  </footer>
);

const App = () => (
  <div>
    <Header />
    <Banner />
    <AboutUs />
    <Courses />
    <Gallery />
    <Testimonials />
    <Contact />
    <Footer />
  </div>
);

export default App;


