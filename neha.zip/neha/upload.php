<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

$target_dir = "uploads/";

if (isset($_POST['upload_gallery'])) {
    $target_dir .= "gallery/";
    $target_file = $target_dir . basename($_FILES["gallery-image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $check = getimagesize($_FILES["gallery-image"]["tmp_name"]);

    if ($check !== false && in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
        move_uploaded_file($_FILES["gallery-image"]["tmp_name"], $target_file);
    }
    header("Location: admin.php");
    exit();
}

if (isset($_POST['upload_result'])) {
    $target_dir .= "results/";
    $target_file = $target_dir . basename($_FILES["result-file"]["name"]);
    move_uploaded_file($_FILES["result-file"]["tmp_name"], $target_file);
    header("Location: admin.php");
    exit();
}

if (isset($_POST['upload_study_material'])) {
    $target_dir .= "study_material/";
    $target_file = $target_dir . basename($_FILES["study-material-file"]["name"]);
    move_uploaded_file($_FILES["study-material-file"]["tmp_name"], $target_file);
    header("Location: admin.php");
    exit();
}

if (isset($_POST['delete_gallery'])) {
    $file = $target_dir . "gallery/" . basename($_POST['file']);
    if (file_exists($file)) {
        unlink($file);
    }
    header("Location: admin.php");
    exit();
}

if (isset($_POST['delete_result'])) {
    $file = $target_dir . "results/" . basename($_POST['file']);
    if (file_exists($file)) {
        unlink($file);
    }
    header("Location: admin.php");
    exit();
}

if (isset($_POST['delete_study_material'])) {
    $file = $target_dir . "study_material/" . basename($_POST['file']);
    if (file_exists($file)) {
        unlink($file);
    }
    header("Location: admin.php");
    exit();
}
?>